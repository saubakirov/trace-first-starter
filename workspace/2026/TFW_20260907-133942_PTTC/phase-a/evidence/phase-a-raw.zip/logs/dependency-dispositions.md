# Complete baseline function disposition

Baseline `099d37d21ddfada2ca72c576055f0a26029c7205` → Candidate `8c72c4c25aa7dde461cfee23b11f90db5f09e220`. Static identity evidence is combined with observations 02/03/04/06; it is not execution proof by itself.

| Baseline function and lines | Disposition | Candidate target |
|---|---|---|
| `build_site` 21–36 | KEEP | `docs/scripts/test_integration.py:18` |
| `test_static_pages_generated` 40–48 | KEEP | `docs/scripts/test_integration.py:36` |
| `test_knowledge_index_generated` 51–57 | KEEP | `docs/scripts/test_integration.py:47` |
| `test_task_pages_generated` 60–67 | KEEP | `docs/scripts/test_integration.py:56` |
| `test_knowledge_topic_pages_generated` 70–76 | KEEP | `docs/scripts/test_integration.py:66` |
| `test_workflow_pages_generated` 79–85 | KEEP | `docs/scripts/test_integration.py:75` |
| `test_template_pages_generated` 88–94 | KEEP | `docs/scripts/test_integration.py:84` |
| `test_frontmatter_in_generated_pages` 97–105 | KEEP | `docs/scripts/test_integration.py:93` |
| `test_decision_refs_resolved_in_knowledge_index` 112–121 | KEEP | `docs/scripts/test_integration.py:104` |
| `test_artifact_refs_resolved_in_knowledge_topics` 124–138 | KEEP | `docs/scripts/test_integration.py:116` |
| `test_td_refs_resolved_in_output` 141–156 | KEEP | `docs/scripts/test_integration.py:133` |
| `test_no_page_renders_its_own_frontmatter_as_body_text` 159–179 | KEEP | `docs/scripts/test_integration.py:151` |
| `test_index_override_used` 182–192 | KEEP | `docs/scripts/test_integration.py:174` |
| `test_no_board_shaped_regex_survives_in_the_generators` 195–217 | REWORK | `docs/scripts/test_repository_contracts.py:20` |
| `test_generators_do_not_read_the_root_readme_for_task_state` 220–231 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:45` |
| `test_the_board_is_gone_from_the_root_readme` 234–242 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:59` |
| `test_section_index_pages_generated` 245–253 | KEEP | `docs/scripts/test_integration.py:187` |
| `test_every_recognized_task_has_an_unlisted_landing_and_nav_has_no_tasks_entry` 256–270 | KEEP | `docs/scripts/test_integration.py:198` |
| `test_status_snapshot_is_explicit_finite_non_gating_and_outside_site` 273–283 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:70` |
| `test_resolved_links_use_directory_urls` 286–297 | KEEP | `docs/scripts/test_integration.py:215` |
| `_scan_for_control_chars` 314–335 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:93` |
| `test_the_control_character_scanner_actually_detects_one` 338–359 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:117` |
| `test_no_shipped_text_carries_a_control_character` 362–383 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:141` |
| `_unresolved_tfw_paths` 408–423 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:187` |
| `test_every_path_an_adapter_source_names_resolves` 426–441 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:205` |
| `test_every_path_an_installed_adapter_copy_names_resolves` 444–453 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:223` |
| `test_the_adapter_path_check_actually_fires` 456–478 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:235` |
| `_managed_block` 486–494 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:265` |
| `_sync_block` 497–503 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:276` |
| `test_installed_adapter_copies_match_their_sources` 506–533 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:285` |
| `test_a_marker_bounded_sync_leaves_project_text_untouched` 536–557 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:315` |
| `test_a_file_without_markers_is_reported_and_left_untouched` 560–572 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:339` |
| `test_no_adapter_template_requires_a_version_substitution` 575–586 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:354` |
| `_adapter_manifest` 623–626 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:402` |
| `_expand` 629–630 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:408` |
| `_manifest_errors` 633–668 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:412` |
| `_install_from_manifest` 671–687 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:450` |
| `_sync_from_manifest` 690–718 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:469` |
| `test_adapter_manifest_is_one_exact_four_by_eleven_contract` 721–724 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:500` |
| `test_empty_receiver_gets_exact_vendor_root_and_eleven_commands` 728–744 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:507` |
| `test_primary_manifest_routes_and_installed_copies_are_exact` 747–757 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:526` |
| `test_secondary_manifest_routes_and_installed_copies_are_exact` 760–771 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:539` |
| `test_manifest_sync_is_idempotent_repairs_commands_and_preserves_unrelated_files` 775–795 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:554` |
| `test_managed_root_sync_preserves_project_text_and_never_duplicates_an_unmarked_root` 799–816 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:578` |
| `test_persistent_runtime_roots_delegate_without_a_common_library_preload` 819–832 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:598` |
| `test_primary_runtime_routes_do_not_read_the_tooling_manifest` 835–839 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:614` |
| `_codex_entry_errors` 842–859 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:621` |
| `test_rtpsn_exact_eleven_codex_entries_reach_one_role_workflow_and_installed_copy` 862–874 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:641` |
| `test_rtpsn_clean_receivers_preserve_full_copy_or_thin_router_contract` 878–890 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:657` |
| `test_rtpsn_codex_entry_mutants_fail_at_their_own_boundary` 902–910 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:681` |
| `test_rtpsn_source_copy_and_generated_input_mutants_fail_independently` 913–921 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:692` |
| `_revise_consumer_errors` 948–955 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:727` |
| `test_revision_2_revise_consumers_and_tracked_copies_share_one_route` 958–973 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:737` |
| `test_revision_2_revise_consumer_contradiction_detector_fires` 976–982 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:755` |
| `_cratm_authority_consumer_errors` 985–1003 | REMOVE orphan of superseded bodies | `No live caller; helper used only by superseded bodies` |
| `_cratm_live_owner_reader_errors` 1006–1023 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:764` |
| `test_cratm_phase_c_authority_consumers_and_six_copies_are_coherent` 1026–1033 | REMOVE shadowed body; surviving effective predicate retained | `docs/scripts/test_repository_contracts.py:2506` |
| `test_cratm_phase_c_owner_only_consumer_mutant_is_rejected` 1036–1048 | REMOVE shadowed body; surviving effective predicate retained | `docs/scripts/test_repository_contracts.py:2532` |
| `test_adapter_manifest_check_rejects_a_missing_command_and_wrong_role` 1051–1064 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:784` |
| `test_managed_block_check_rejects_duplicate_authority` 1067–1072 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:800` |
| `resolve_markdown_heading` 1075–1094 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:808` |
| `_antigravity_surface_errors` 1097–1118 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:830` |
| `test_antigravity_authority_is_plural_across_every_runtime_surface` 1121–1146 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:854` |
| `test_every_project_owned_payload_file_is_excluded_from_the_copy` 1156–1176 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:889` |
| `_bare_file_targets` 1267–1272 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1000` |
| `payload_path_findings` 1275–1305 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1008` |
| `test_every_path_a_payload_file_names_resolves` 1316–1326 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1049` |
| `test_the_payload_path_check_fires_in_all_three_forms` 1329–1345 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1062` |
| `test_no_normative_file_states_a_retired_rule` 1348–1377 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1081` |
| `test_no_adapter_file_states_a_retired_rule` 1387–1413 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1120` |
| `test_the_retired_rule_check_actually_fires` 1416–1426 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1149` |
| `test_the_adapter_retired_term_check_actually_fires` 1429–1441 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1162` |
| `test_the_status_template_examples_parse_and_validate` 1444–1470 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1177` |
| `test_every_runtime_message_is_ascii` 1473–1500 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1206` |
| `test_the_windows_binding_path_is_the_literal_one` 1503–1521 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1236` |
| `_canonical_surface` 1564–1574 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1297` |
| `_offenders` 1577–1584 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1310` |
| `test_the_naming_detectors_actually_fire` 1587–1607 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1320` |
| `test_no_canonical_example_uses_a_bare_identifier_as_a_name` 1610–1613 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1343` |
| `test_no_canonical_example_doubles_the_slug` 1616–1620 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1349` |
| `test_no_canonical_event_example_is_actorless` 1623–1626 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1356` |
| `test_the_canonical_surface_is_actually_being_scanned` 1629–1634 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1362` |
| `_git_bytes` 1646–1649 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1379` |
| `_current_adapter_path` 1652–1655 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1385` |
| `_vbsa_update_mapping` 1658–1665 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1391` |
| `_apply_vbsa_mapping` 1668–1671 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1401` |
| `test_vbsa_config_has_exact_three_key_contract_in_live_and_starter_files` 1674–1677 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1407` |
| `test_vbsa_migration_preserves_values_and_removes_only_retired_keys` 1680–1695 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1413` |
| `test_vbsa_migration_mutant_changes_result_before_rejection` 1698–1709 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1431` |
| `_vbsa_north_star_policy` 1712–1720 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1445` |
| `_vbsa_north_star_policies` 1723–1724 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1456` |
| `_validate_vbsa_north_star_policies` 1727–1745 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1460` |
| `_execute_vbsa_north_star_policy` 1748–1769 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1481` |
| `_vbsa_receiver_fixture` 1772–1793 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1505` |
| `test_vbsa_update_and_init_execute_receiver_north_star_preservation` 1796–1807 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1529` |
| `test_vbsa_receiver_overwrite_mutant_changes_bytes_before_rejection` 1810–1820 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1543` |
| `test_vbsa_saint_principle_is_local_and_not_injected_into_foreign_north_stars` 1823–1833 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1556` |
| `_vbsa_release_entry` 1836–1856 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1569` |
| `test_vbsa_release_preserves_migration_before_and_after_publication` 1859–1873 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1592` |
| `test_vbsa_release_entry_accepts_both_lifecycle_locations` 1877–1881 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1610` |
| `test_vbsa_release_entry_rejects_lost_or_ambiguous_migration` 1885–1900 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1618` |
| `_current_release_metadata` 1903–1923 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1636` |
| `test_release_versions_migration_and_onboarding_support_receiver_update` 1926–1937 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1659` |
| `test_current_release_metadata_accepts_successors_and_rejects_mixed_inputs` 1944–1992 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1677` |
| `test_vbsa_adapter_copy_is_exact` 1996–1999 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1729` |
| `test_vbsa_adapter_manifest_topology_is_unchanged_from_baseline` 2002–2004 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1735` |
| `_rtpsn_identity_route_errors` 2032–2039 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1765` |
| `_rtpsn_git_paths` 2042–2047 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1775` |
| `test_rtpsn_phase_b_manifest_census_classifies_all_eleven_routes_once` 2050–2061 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1783` |
| `test_rtpsn_phase_b_identity_checkpoints_follow_resolution_and_precede_work` 2064–2069 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1797` |
| `test_rtpsn_phase_b_deleted_and_reordered_checkpoint_mutants_fail_locally` 2072–2081 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1805` |
| `test_rtpsn_phase_b_clean_receivers_have_exact_identity_classification` 2085–2102 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1818` |
| `test_rtpsn_phase_b_all_eleven_tracked_full_copy_routes_are_byte_exact` 2105–2110 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1838` |
| `test_rtpsn_phase_b_codex_manifest_roots_phase_a_cratm_and_project_routes_are_protected` 2113–2142 | REMOVE shadowed body; surviving effective predicate retained | `docs/scripts/test_repository_contracts.py:2828` |
| `test_rtpsn_phase_b_runtime_sources_never_consume_task_spec_or_generated_evidence` 2145–2158 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1846` |
| `_phase_d_git_paths` 2184–2188 | REMOVE orphan of superseded bodies | `No live caller; helper used only by superseded bodies` |
| `test_phase_d_literal_value_assurance_and_trace_boundary_is_complete` 2191–2199 | REMOVE shadowed body; surviving effective predicate retained | `docs/scripts/test_repository_contracts.py:2017` |
| `test_phase_d_workflow_copies_and_codex_managed_receiver_are_exact` 2202–2214 | REMOVE shadowed body; surviving effective predicate retained | `docs/scripts/test_repository_contracts.py:2048` |
| `test_phase_d_claude_release_config_history_and_prior_phases_are_byte_exact` 2217–2230 | REMOVE shadowed body; surviving effective predicate retained | `test_phase_d_approval_epoch_protects_history_inputs_and_cumulative_prefixes` |
| `test_phase_d_added_product_lines_do_not_leak_provider_names_or_apis` 2233–2244 | REMOVE shadowed body; surviving effective predicate retained | `test_phase_d_added_product_provider_terms_are_confined_to_adapter_and_named_exception` |
| `_phase_d_tree_paths` 2305–2308 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1943` |
| `_phase_d_changed` 2311–2318 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1949` |
| `_phase_d_allowed_continuation` 2321–2327 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1959` |
| `test_phase_d_continuation_guard_is_finite_and_covers_rev3_plus_round4_sequence` 2330–2376 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:1968` |
| `test_phase_d_literal_value_assurance_and_trace_boundary_is_complete` 2379–2395 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2017` |
| `test_phase_d_baseline_numstat_is_numeric_for_exact_twenty_one_value_paths` 2398–2407 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2036` |
| `test_phase_d_workflow_copies_and_codex_managed_receiver_are_exact` 2410–2428 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2048` |
| `test_phase_d_approval_epoch_protects_history_inputs_and_cumulative_prefixes` 2431–2450 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2069` |
| `test_phase_d_final_trace_is_byte_exact_in_the_integrated_tree` 2453–2469 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2091` |
| `test_phase_d_closure_visible_knowledge_uses_approval_epoch_not_product_baseline` 2472–2486 | REWORK | `docs/scripts/test_repository_contracts.py:2110` |
| `test_phase_d_release_config_migrations_and_original_d_history_are_protected` 2489–2505 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2129` |
| `test_phase_d_added_product_provider_terms_are_confined_to_adapter_and_named_exception` 2508–2523 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2148` |
| `test_phase_d_a7_freeze_and_historical_denominator_are_immutable_anchors` 2526–2536 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2166` |
| `test_phase_d_resume_copy_parity_and_unaffected_session_consumers_are_protected` 2539–2558 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2179` |
| `test_phase_d_claude_release_config_history_and_prior_phases_are_byte_exact` 2562–2563 | REMOVE redundant alias | `test_phase_d_approval_epoch_protects_history_inputs_and_cumulative_prefixes` |
| `_phase_e_merge_head` 2613–2618 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2251` |
| `_phase_e_candidate` 2621–2635 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2259` |
| `_phase_e_diff_command` 2638–2644 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2276` |
| `test_phase_e_candidate_has_exact_lineage_or_open_merge_heads` 2647–2674 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2285` |
| `test_phase_e_value_accounting_is_exact_and_within_budget` 2677–2694 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2315` |
| `test_phase_e_integrated_workflows_have_exact_copy_parity` 2697–2701 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2335` |
| `test_phase_e_preserves_rtbo_phase_d_and_protected_boundaries` 2704–2712 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2342` |
| `test_phase_e_knowledge_keeps_exact_rtbo_and_final_cratm_decisions` 2715–2789 | REWORK | `docs/scripts/test_repository_contracts.py:2456` |
| `test_phase_e_selected_product_and_assurance_files_have_no_conflict_markers` 2792–2797 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2498` |
| `test_phase_d_added_product_lines_do_not_leak_provider_names_or_apis` 2800–2801 | REMOVE redundant alias | `test_phase_d_added_product_provider_terms_are_confined_to_adapter_and_named_exception` |
| `test_cratm_phase_c_authority_consumers_and_six_copies_are_coherent` 2804–2827 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2506` |
| `test_cratm_phase_c_owner_only_consumer_mutant_is_rejected` 2830–2840 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2532` |
| `_phase_e_ii_package_patch` 2895–2903 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2597` |
| `_phase_e_ii_release_state` 2906–2916 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2608` |
| `_phase_e_ii_replay_package` 2919–2993 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2621` |
| `test_phase_e_ii_writer_rule_is_bounded_and_copy_identical` 2996–3009 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2698` |
| `test_phase_e_ii_glossary_routers_and_b9_anchor_are_exact` 3012–3038 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2714` |
| `test_phase_e_ii_release_destinations_are_protected_and_package_replays` 3041–3076 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2743` |
| `test_phase_e_ii_package_mutants_are_rejected` 3079–3094 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2781` |
| `test_phase_e_ii_value_and_assurance_selectors_are_exact_and_within_budget` 3097–3123 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2799` |
| `test_rtpsn_phase_b_codex_manifest_roots_phase_a_cratm_and_project_routes_are_protected` 3126–3156 | MOVE unchanged | `docs/scripts/test_repository_contracts.py:2828` |

Seven earlier definitions were overwritten at module import in the baseline. Their latest effective forms survive unchanged, or (for the two thin aliases) their already-collected substantive targets survive. No protective meaning is inferred from a lower collected count.

The board guard REWORK only follows its actual containing filename for self-exclusion; migrate_board.py remains the narrow migration exclusion. The old integration filename is no longer excluded. The two other existing REWORK functions remove live whole-row locking while retaining finite historical claims at their immutable epochs. New knowledge helpers and one bounded case test supply structural cases and explicit semantic-review inputs.

Imports and direct/transitive module symbols, decorators and local imports for all 150 current functions/helpers are in dependency-map.json. Pure imports are ordinary library modules; tfw_state is imported locally for source-template parsing. Output consumers and build_site stay together. Literal assignments/regex construction/parametrization do not start a build. Static inspection is supported by zero observed MkDocs starts with absent/stale site and fresh-build ordinary output runs.
