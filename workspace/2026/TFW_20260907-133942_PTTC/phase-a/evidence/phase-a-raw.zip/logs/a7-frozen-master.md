# HL — TFW_20260902-111644_CRATM: Contextual Roles and Agent Team Mode

> **Date**: 2026-09-02
> **Author**: Coordinator (Claude Code)
> **Refreshed**: 2026-09-06 by Main Coordinator (Codex), applying owner-approved A7
> **Title**: Contextual Roles and Agent Team Mode
> **Abbreviation**: CRATM
> **Status**: 🧩 PHASES — master contract frozen; each phase owns its live state
> **Contract**: 🔒 FROZEN — approved by saubakirov 2026-09-06 (A7; original approval 2026-09-02)
> **Frozen**: §1 · §3 · §4 · §5 · §6 · §7 — locked on owner approval
> **Free**: §2 · §7.2 · §8 · §9 · §10 · §11 — research updates these directly
> **Append-only**: §12 Amendment Log — the only channel for changing a frozen section
> **Baseline**: freeze commits — recovery form in `conventions.md` §3 rule 15

> **Project North Star**: `.tfw/README.md` [#ns1](../../../.tfw/README.md#ns1) · [#ns2](../../../.tfw/README.md#ns2) · [#ns3](../../../.tfw/README.md#ns3)

> **Historical source**: [`TFW-54`](../../../tasks/TFW-54__agent_team_mode/HL-TFW-54__agent_team_mode.md), sealed
> `REJECTED` — superseded, not failed. Its proposal and draft HL are read-only input, classified
> through the transfer ledger in this task's [PROPOSAL](PROPOSAL__TFW_20260902-111644_CRATM.md) §4.
> Nothing in that directory is reopened, renamed or updated in place.

> **Every phase carries its own HL**, by owner ruling 2026-09-02. Those are **derivation-only**
> (`conventions.md` §3 rules 20–21): execution context, files, sequencing, phase-local risks — never
> their own §1, §5, §6 or §7. Acceptance lives once, here.

---

## 1. Vision 🔒 FROZEN

A project declares its people and stable named agent principals. After approving the HL, the human
owner chooses manual work or bounded autonomy and, for autonomy, selects one named LEAD. That LEAD
creates and manages the necessary working sessions in isolated working trees; those sessions need
roles and addresses, not separate personal profiles. Amendments return through their recorded
initiation chain to the authorised LEAD or the human owner, with their true origin preserved. The
owner can leave routine coordination to the LEAD and return to an inspectable finished result;
ultimate authority and accountability remain with the human who initiated the mandate.

This completes what three tasks left standing one step apart. TFW-53 froze the goals and gave them a
defender. TFW-60 gave every task its own state, its own immutable journal, and a place where
participants are declared. Neither of them named who acts, and the canon says so in eleven places:
*"a writer is not named yet."* Until it is, `type: agent` is admitted by the schema and consumed by
nothing, delegation has no addressee, and a coordinator running a team is a practice with no contract.

**Impact:** The owner stops being the router. Ten blocking gates per research iteration become one
approval plus the amendments the work genuinely raises. Two sessions stop contending for one git index,
because they stop sharing one. A verdict on a frozen claim carries the name of who signed it and the
authority they were given, so a reader six months later can check both. And the framework stops
promising a deliverable from a task that no longer exists.

> "I approved the purpose, selected my LEAD and how far it could go, and left. It created the working
> sessions itself. What came back was the work and the decisions only I could make; I could still see
> which session produced and checked each piece."

## 2. Current State (As-Is) 🟢 FREE

### The substrate is built and the last step is missing

Measured against the working tree at `c38f87a`, framework version 2.1.0.

| Carrier | State | What it cannot do |
|---|---|---|
| Frozen HL contract, §12 amendment log, freeze baseline | ✅ TFW-53 (D63) | Nothing — it works. But nobody walks away from it, so it is cost without return |
| Purpose Check, north-star locus, materiality bar | ✅ TFW-53 (D64), NS1–NS3 now designated | — |
| Task-local `status.md`, immutable `journal/`, derived index | ✅ TFW-60 (D68) | — |
| `team/{handle}.md` participant profiles | ✅ four keys: `handle`, `name`, `type`, `since` | Carry no role. Context lives in `team/README.md` prose, which no parser reads |
| `type: agent` | ✅ admitted by the schema | **Consumed by nothing.** The template says so in capitals |
| Journal identity fields | ✅ `on_behalf_of` (a human, accountable) · `via` (tool text) | **Cannot name the writer.** `actor` was removed at `2.0.0-dirty.3` |
| `kind: dispatch` — *"work was handed to a named participant"* | ✅ in the closed vocabulary | Names the participant it went **to**, never the one it came **from** |
| `~/.tfw/bindings.yaml` — which handle a machine acts as | ✅ specified | Selects a human handle only. **Does not exist on this machine** — the mechanism has never been used here |
| Execution modes, `conventions.md` §7 | ✅ CL and AG, six lines | No mode where a coordinator runs a team under one frozen HL |
| Per-task Role Assignment | ❌ absent | `grep -rn "Role Assignment" .tfw/` → 0 |
| Staging and landing discipline | ❌ absent | `Commit Attribution` is one paragraph, unchanged since TFW-50 |

### The canon has eleven live forward references to a sealed task

`.tfw/` names **TFW-54** as the task that will deliver a named agent principal. TFW-54 is now
`REJECTED — superseded`. Every one of these promises now points at a task that will deliver nothing:

| Site | What is promised |
|---|---|
| `conventions.md`:362 | *"Naming a writer needs a principal that delegates and answers to someone — and TFW does not have one until **TFW-54**"* |
| `glossary.md`:318 | `type: agent` *"is admitted by the schema and consumed by nothing until TFW-54"* |
| `templates/team/profile.md`:34 | *"that is TFW-54; until it lands, `team/` holds people"* |
| `templates/journal/event.md`:56 | the same, for the removed `actor` field |
| `workflows/handoff.md`:48 · `init.md`:86 · `init.md`:131 · `release.md`:31 · `research/base.md`:40 · `resume.md`:31 · `review.md`:53 | *"A writer is not named yet — that is TFW-54"* |

Eleven sites in ten files. This is the same shape as the eleven `/tfw-task` references that
[RTMW](../TFW_20260902-153617_RTMW/status.md) retired on 2026-09-02, and it is not cosmetic: the
promise and the blocker are the same sentence, so whoever lands the principal must land the sweep.

### Two sessions, one index — measured three times

| # | Occurrence | Record |
|---|---|---|
| 1 | A broad `git add` in the TFW-53/B session swept three of TFW-56's already-staged deletions into `fbdf443` | TD-144, **High**; `tasks/DEBT-SNAPSHOT.md`:91 |
| 2 | TFW-53/E's board rows landed inside `8d9432b` `[claude-code/TFW-58/proposal/coordinator]`, whose body never mentions TFW-53 | TD-178; `git log -- README.md` shows no TFW-53/E commit for that phase's deliverable |
| 3 | TFW-60/A's own release: *"broad staging temporarily committed TFW-54/TFW-55 files… the release has not structurally prevented the recurring TD-144 failure"* | `TFW-60/phase-a/review/judge.md` row 10, ❌ |

`knowledge/risk.md` F1 measured the discipline that was supposed to prevent it: **a verbal staging
directive survived 0 of 1** against a broad `git add`, and three consecutive phases of one task
produced three different ad-hoc answers, none written down. Under D55 the commit subject is the only
record of which task a change belongs to, and TFW-53's baseline recovery is a subject filter — so a
misattributed staging degrades the mechanism TFW-53 shipped.

**A fourth occurrence, in a class no worktree isolates.** Research iteration 2, while measuring the
crossings, followed up a dispatch with `resume --last` instead of the returned session id. It attached
to the **owner's own live Codex thread** — 2.8 MB of transcript, 264 K tokens — answered out of that
thread's context, and left a turn in its rollout file permanently. Read-only mode, the obvious
command. The three defects above share a git index; this one shares the **vendor's session store**,
which Phase A's isolation does not touch. The rule it produces is small and belongs in the dispatch
protocol: capture the session id and follow up by id, never `--last`.

### Isolation already exists on this machine, and nobody designed it

```
$ git worktree list
D:/projects/research/steps-framework                  c38f87a [master]
C:/Users/c0rpa/.codex/worktrees/ac4b/steps-framework  30f8fee (detached HEAD)
```

Codex creates git worktrees unprompted, under a vendor-owned path, named by an opaque token, at a
detached HEAD. Separate worktrees have **separate indexes**, which is exactly what defect 1 needs and
exactly what no rule delivered in three attempts. What they do not fix is defect 2 — attribution is
not isolation — and what they add is a merge, plus git's constraint that one branch cannot be checked
out in two worktrees at once.

Measured by research iteration 2: `~/.codex/worktrees/` holds **15 entries, 3 of them already
readably named** (`kz-intake-phase-a`, `-review`, `-smoke`), so a task-shaped name is not something
the protocol has to win from the vendor. Six token-named directories hold an **empty**
`steps-framework/` shell with no `.git`, while `.git/worktrees/` holds one admin entry — so a
finished run's measured residue is litter, not a dangling tree. Iteration 1 adds the mechanics that
bound Phase A: an app-managed worktree is normally detached and tied to one chat, shares the
repository's git metadata, and **nested subagents share the parent task's checkout unless another
boundary is created explicitly** — a child relationship is not worktree evidence.

Measured Codex environment, iteration 1: `codex-cli 0.151.0-alpha.7.2`, `multi_agent` stable and
enabled, `multi_agent_v2` disabled. One controlled read-only nested trial produced three sequentially
named children with correct parent paths and role recognition, a common working directory, and
neither a descendant nor a hang. Sample size one, read-only scope — mechanics, not a reliability rate.

### A dated capability fact needs a narrower replacement

`knowledge/constraint.md` F11, marked *measured 2026-08-08*: *"Fully independent agent sessions are a
**Codex-only** capability. Claude Code can spawn subagents but not peers."*

Research iteration 2 replaced the coordinator's first reading with measurement. **Eight owner-opened
peers listed twice, twenty minutes apart**, six of them three days old; one peer in another project
answered a delegation-shaped message. The same installed surface created and resumed a headless
session through `claude -p`. Those are two measured route families, not a universal Claude topology.

Iteration 3 added the current documented split: a lead-created native team, owner-opened peers,
headless resumable sessions, background peers, and two-level hybrids are distinct candidates. The
installed workstation build `2.1.109` does not prove the newer native-Windows route, and documentation
does not prove that any candidate can carry TFW. A nested subagent or an agent-definition file remains
a bounded helper or configuration, never the holder of a long-lived Role Assignment row.

**Both fresh crossings work, with no TFW-side mechanism.** Codex → a fresh Claude is one command.
Claude → a fresh Codex was one command too after the owner upgraded the CLI. What has not been
measured is an in-scope route from either provider to the other's **existing long-lived role task**.
Claude channels and Codex app-server/SDK are plausible bridge ingredients, but composing them would
add the runtime, credential, liveness and security surface frozen out of this task. First release
therefore does not promise a mixed long-lived chain.

Two cost facts survive the upgrade, and they point in opposite directions. A cold call is cheap —
whole-workflow delegation near 5 K rather than 40 K. But **a resume costs more than a cold call**,
18,623 against 5,030, because it replays the thread: a long correspondence gets progressively more
expensive per turn, which prices granularity for Phase D rather than the other way round.

And the general finding outlives both numbers: route behaviour is checked at dispatch against the
actual surface, tools, version and OS. These are diagnostic evidence, never stable identity fields in
a Role Assignment, participant profile or live registry → §9 R15 and R17.

F11's correction is Phase E's to write, and this is the text it needs.

### Intervening baseline — RCFR and VBSA landed

The original Phase A draft was written before RCFR. RCFR is `DONE`; D73–D75 replaced universal
context loading with workflow-owned ordered reads and one adapter manifest. VBSA is also `DONE` and
landed at `125ec27`; its value-bearing accounting now governs Phase A's TS and review. Neither task
added a worktree, staging or landing rule, so the frozen Phase A outcome remains unspent.

| File | Phase A draft | RCFR landing | current after VBSA | Consequence |
|---|---:|---:|---:|---|
| `.tfw/conventions.md` | 11,269 words | 9,269 | 9,791 | Reference owner remains suitable; add each rule once |
| `.tfw/workflows/handoff.md` | 1,727 | 1,751 | 2,013 | The inherited file is above F2; no duplicate rule body |
| `.tfw/workflows/review.md` | 1,699 | 1,894 | 2,102 | Same; the role consumes a short addressed enforcement edge |

This changes execution context, not the frozen Phase A outcome. The obsolete shared-preamble
assumption is gone: current workflows carry unique Read Contracts, and a rule placed only in
`conventions.md` is invisible unless the consuming workflow names or states it.

### Field practice this task has to describe rather than invent

Owner, 2026-09-02: Codex manages its own sessions through threads — the coordinator creates a phase
coordinator, and the phase coordinator creates the others and controls them down the chain. The owner
can see, message and stop each one. *"Правда иногда тупит, форкает себя зачем-то"* — so the behaviour
is real but not reliable, and what makes it reliable is instructions, which is this task's medium.

The first two research iterations later closed the crossing question narrowly: both tools can start a
fresh run of the other, but neither can address the other's **existing** session. That is send-and-wait,
not a team conversation, and a worktree changes none of it.

### A second field run exposed the missing topology decision

The owner's 2026-09-05 Helpdesk run supplied evidence the original research did not have. Its
`SESSIONS.md` records a coordinator-of-coordinators plus separately opened Claude sessions. Three
attempted role holders were actually nested subagents behind parent-session relays: none appeared in
`ListAgents`, none was directly addressable cross-session, and replies returned to the parent. The
owner had to open real peer sessions. One instruction to *create an agent* was first interpreted as a
request to write an agent-definition file rather than to establish a session. The live roster then
fell a day behind the actual reviewer and phase assignments before an executor detected the drift.

That file is evidence, not a proposed CRATM carrier. Frozen DoF 3 and 7 deliberately forbid a live
session registry and a new per-task artifact. The field result therefore opens a design question the
current provider-neutral wording hides: a team role needs an independently addressable **session or
task**, not a nested subagent, and each provider reaches that result through different native
operations. A Codex coordinator can create and control user-visible tasks. The Helpdesk run required
the owner to provision Claude peers, but iteration 3 found that this is evidence for that route and
build, not a universal Claude premise: current documentation exposes several native candidates. Each
candidate must pass the same behavioural gate without a roster or relay before it becomes a profile.

### Owner-approved model correction — 2026-09-06

A–C and release 2.2.0 are historical delivery facts, not drafts to rewrite. Phase D's latest
[REVIEW revision 2](phase-d/REVIEW__phase-d__team_mode_and_role_assignment__rev2.md) returned its
admission rule for correction. Independently, the owner clarified the intended delegation model:
one named LEAD, with working sessions created beneath it. A7 corrects the master contract; D must
derive a revised TS before implementation. The existing Phase D Coordinator, Executor and Reviewer
are reused. No new stable principal is created for this Main Coordinator by that product decision.

## 3. Target State (To-Be) 🔒 FROZEN

### What changes

1. **Concurrent work is isolated by a declared worktree protocol** built on `git worktree` — where a
   worktree lives, a name a person can read back to its task and principal, who may create one, when
   it merges, who deletes it, and what happens to one whose session died. TFW owns the protocol; git
   owns the mechanism.
2. **Attribution survives isolation.** A deliverable landed by a session other than its producer goes
   in its own commit, whose subject names the producer's task and phase. Isolation does not fix this
   and a rule must.
3. **Participants carry structured context.** `team/{handle}.md` gains organisation and project role
   as declared descriptive context, with a migration that does not break existing four-key profiles.
4. **A named agent principal exists**, activating `type: agent`: a stable name that can be assigned,
   delegated to, and held in an accountability chain — never a provider, never a model, never a
   session. Each agent principal names the human accountable for it. One selected principal serves
   as LEAD for an autonomous mandate; its subordinate working sessions need no additional profiles.
5. **A durable write can name its principal writer** without losing the actual producing unit.
   Existing dispatch and role artifacts distinguish source, destination, scope and proposal origin;
   sharing the LEAD's attribution does not merge units. Legacy `actor` remains untouched.
6. **A binding selects a principal for attribution**, never a delegation grant. The owner's explicit
   LEAD selection and bounded dispatch govern subordinate units, rather than a new machine binding
   or profile for every session. No start command, liveness file or process lock is introduced.
7. **Verdict authority is a property of the name.** A principal that may rule on a frozen-section
   amendment is a distinct declared principal from one that may not. The grant is visible in the §12
   row because it is visible in the signature.
8. **A human-rooted initiation chain distinguishes units from principals.** Only Coordinator units
   create children. Subordinate proposals route upward to the selected LEAD with an eligible grant,
   otherwise to the owner. Shared attribution confers no ruling rights on a child. A proposal
   originating with the LEAD returns to the owner even if a child transcribes or forwards it.
9. **A third execution mode** in `conventions.md` §7 — a coordinator running a team under one frozen
   HL — records the owner's post-approval mode choice, one selected LEAD and bounded reach. Role
   Assignment separates protected role/scope/control commitments from working-unit instantiation;
   dispatch records the actual units. A full named roster is not required before HL freeze.
   The owner-return list remains exhaustive, and each unit has an explicit autonomy boundary.
   In the first release every long-lived execution chain is provider-homogeneous and uses a
   field-proven native route. Mixed-provider fresh runs may be bounded helpers returning results to a
   role holder, never long-lived role rows. Codex may proceed on current evidence; a Claude profile is
   admitted only after the Phase D native acceptance gate passes.
10. **The canon stops promising a deliverable from a sealed task.** Eleven sites are swept, F11 is
    corrected, and the vocabulary lands in the glossary and the adapters.

### Explicitly out of scope

| Not built here | Why | Where it goes |
|---|---|---|
| Any runtime, orchestrator, spawner, scheduler, lock server, daemon or database | NS3 non-goal: *"a vendor-bound tool, runtime, model, interface, or memory feature."* TFW-49 died of exactly this — 5,910 lines of Python discarded, 149 files and 27,103 lines reverted in six days | — |
| **A worktree implementation of our own** | `git worktree` is git, not a vendor, and TFW already stands on git for attribution (D55) and baseline recovery. Writing our own means either code in the repository or reinventing what git does correctly | — |
| A liveness registry, a process lock, or a `tfw-agent-start` command | State that must agree with a running process is the two-files-must-agree problem D68 removed on purpose: the process dies and the file lies. And a lock is a runtime | — |
| Branch policy and merge strategy for shared work | One transport must not be assumed here | [TFW-61](../../../tasks/TFW-61__collaboration_transport_modes/PROPOSAL__TFW-61__collaboration_transport_modes.md) |
| The revise loop — who is in it, termination, re-entry | Only the agent-freshness question touches this task, and it is a hypothesis here | [TFW-58](../../../tasks/TFW-58__revise_protocol/PROPOSAL__TFW-58__revise_protocol.md) |
| Stage-level swarm inside one workflow | Different granularity; merging blurs the vocabulary this task introduces | [TFW-45](../../../tasks/TFW-45__multi_agent_workflows/HL-TFW-45__multi_agent_workflows.md), ❄️ frozen |
| Permissions or authentication derived from a profile role | D59: declared attribution ≠ authentication. A role is context; authority comes from the owner, the contract and the Role Lock | — |
| One profile per session, model, provider family or event | The failure that removed `actor`: events are immutable, profiles are not | — |
| A mixed-provider chain of long-lived Role Assignment rows in the first release | No in-scope route addresses the other provider's existing role task; a bridge would add runtime, credentials, liveness and security outside this task | Separate future task, only if mixing gains independent value |
| Unifying Full and Assisted profile or binding schemas | A shared noun does not make two schemas one (S4) | — |
| Any edit to Assisted, FA15ES, or sealed `tasks/` beyond a terminal state already recorded | — | — |

### The autonomy boundary is a declared scope, not a moment

The owner asked when autonomy begins, and reports wanting it sometimes before research and sometimes
after. Both are already **after the freeze** — rule 13 puts the freeze commit before iteration 1 — so
the contract boundary is identical in both, and what actually differs is how many open hypotheses the
coordinator may close alone.

After the approved HL has a committed freeze baseline, the Coordinator asks whether to continue
manually or autonomously. Manual work retains CL and separately explicit AG. For AT, the owner
selects an existing stable agent principal as LEAD and approves its scope, reach and reserved returns
in the existing HL/dispatch traces. This first bounded choice may be made after research; it does
not require thawing the approved purpose or inventing a new artifact. No choice means no AT.

Role Assignment's protected mandate is distinct from its instantiation. The LEAD creates directly
addressable units as needed inside the approved role coverage and scope; it need not obtain new
profiles or a new HL amendment for each ordinary unit creation. `Autonomous from` uses the existing
lifecycle vocabulary, but reaching a state is not approval: exact governing gates still apply.
Once authorised, widening scope or autonomy, changing the selected principal, dropping a control or
replacing an unavailable role holder requires the applicable explicit ruling; it is not ordinary
instantiation. The default remains post-research; earlier autonomy needs the owner's bounded choice
for a small, familiar task with closed uncertainty.

Principal identity, a session's operational role and its native address are three different facts.
Selecting LEAD confers the recorded mandate, not a new profile or self-issued grant. Child units act
under it with their own Role Locks and traceable origin; their functional titles need no personal names.

### 3.1 Result Visualization

> Rendering of §3–§5 as already approved. No claim here that is not a DoD item.

**Every file that changes, and which phase touches it.** No new artifact class, no new per-task file.

```
.tfw/
├─ conventions.md      [A] §4 → worktree protocol · exact-path staging · landing commit
│                      [B] §4 → profile schema opens · principal · writer field · binding selects
│                      [C] §3 → rule 8 rewritten: who may rule · initiation chain · termination
│                      [D] §7 → ★ THIRD MODE · §3 → principal/unit routing and mandate granularity
│                      [A][C][D] §14 → anti-patterns
├─ templates/
│  ├─ team/profile.md  [B] organization_role · project_role · agent principal · accountable human
│  │                       · optional mentality · the two-grant-levels pattern
│  ├─ journal/event.md [B] the writer field returns; legacy actor still tolerated
│  ├─ bindings.yaml    [B] a binding may select a principal, not only a human handle
│  └─ HL.md            [D] Role Assignment section, incl. the "Autonomous from" column
├─ workflows/
│  ├─ handoff.md       [A] executor side of staging · [D] delegate obligations
│  ├─ review.md        [A] reviewer side of staging · [C] where a verdict request goes
│  ├─ plan.md          [C] amendment routing · [D] post-HL mode choice and bounded unit dispatch
│  └─ research/base.md [D] researcher as a delegate
├─ glossary.md         [E] principal · initiation chain · worktree protocol · landing commit · AT
└─ VERSION · CHANGELOG [E]

knowledge/constraint.md  [E] F11 corrected — peers are no longer Codex-only
eleven sites, ten files  [E] the "that is TFW-54" promise is swept
```

**What each phase buys, stated as what stops happening.**

| Phase | Changes | What stops |
|---|---|---|
| **A** 🔴 | `conventions.md` §4, `handoff.md`, `review.md` | Two sessions stop sharing one index — structurally, not by a directive that survived 0 of 1. And a deliverable stops landing under another task's name |
| **B** 🔴 | three templates, `conventions.md` §4 | `type: agent` stops being a schema entry consumed by nothing. A dispatch stops being unable to say who handed the work |
| **C** 🔴 | `conventions.md` §3, `plan.md`, `review.md` | "Ask the owner" stops being the only answer to *who rules this*. An executor stops being able to initiate anyone, so a cycle stops being possible |
| **D** 🔴 | `conventions.md` §7 and §3, `templates/HL.md`, three workflows | The owner stops being the router. And "you are free from here" becomes sayable with a declared reach |
| **E** 🟡 | glossary, eleven sites, F11, adapters, version | The canon stops promising a deliverable from a sealed task, and the debt the four reviews captured stops outliving them |

```
A ──► B ──► C ──► D ──► E
│
└─ A is independent and runs first because this task's own later phases need it
```

**What the owner sees after HL approval** — illustrative names and unit references, not a grant
to any current session:

```text
HL approved and frozen
    └─ Coordinator: "Continue manually or autonomously?"
         ├─ Manual → ordinary CL / separately explicit AG
         └─ Autonomous → owner selects method-lead and bounded reach
              └─ method-lead creates and manages its working sessions

team/
├─ saubakirov.md     human owner — ultimate authority and accountability
└─ method-lead.md    stable agent principal — accountable_to: saubakirov
                    immutable may_rule_amendments: true
```

A project may keep other owner-declared principals with different immutable grants; this run selects
one. It does not create `team/` files for the following working units.

**Role Assignment after bounded dispatch** — human-approved mandate, then traceable instantiation:

| Workflow role | Scope | Working unit | Reports to | Autonomous from | Direct channel |
|---|---|---|---|---|---|
| LEAD / Coordinator | approved task | root unit, principal `method-lead` | saubakirov | TS_DRAFT | owner task |
| Phase Coordinator | approved phase D | phase-D unit | root unit | TS_DRAFT | parent task |
| Executor | approved D TS | execution unit | phase-D unit | TS_DRAFT | parent task |
| Reviewer | D RF and evidence | separate review unit | phase-D unit | TS_DRAFT | parent task |

The example uses post-research autonomy. `TS_DRAFT` still needs exact TS approval; it is not an
automatic grant. `HL_DRAFT` can mean post-freeze research autonomy only by the owner's explicit
choice, and `—` means report and wait. A Researcher unit is created only when scoped research is
needed. Actual native addresses belong in the immutable dispatch trace; descriptive labels above
are not substitute addresses or permanent personal names.

```text
saubakirov — initiates and bounds the mandate, keeps ultimate responsibility
    └─ method-lead / root Coordinator unit — selects work and rules only within its grant
         └─ phase-D Coordinator unit — plans and coordinates D, no inherited amendment grant
              ├─ Executor unit — /tfw-handoff, own worktree, cannot create children
              └─ Reviewer unit — /tfw-review, separate unit and worktree, cannot repair its finding

All units: principal attribution method-lead; distinct source, parent, role and work evidence.
Subordinate-origin amendment → parent routing → eligible LEAD → signed §12 ruling
LEAD-origin / owner-reserved / no eligible grant → human owner
```

An amendment's proposer includes its originating unit and principal context, preserved through
forwarding and session continuation. A shared `writer` does not erase the origin; a fresh unit does
not make a LEAD-origin proposal eligible for the LEAD's own ruling. Missing or contradictory origin
blocks a delegated ruling rather than allowing the signer to guess it. Only Coordinator units may add
new children to a validated human-rooted prefix; no ancestor or competing-parent edge is admitted.

**Before and after, one five-phase task:**

```
TODAY                                        AFTER
──────────────────────────────────────       ──────────────────────────────────────
approve HL                          🛑       approve HL; choose LEAD and reach    🛑
research iter1: 9 gates          🛑×9        ── coordinator answers ──
research iter2: 9 gates          🛑×9        ── coordinator answers ──
  amendment arrives                 🛑       amendment → nearest ruler; owner only
                                             when the ruler is the proposer      🛑
TS · ONB · RF · REVIEW × 5 phases 🛑×~25     ── the team carries it ──
                                             Purpose Check hits a contract defect 🛑
close                               🛑       finished result                     🛑
──────────────────────────────────────       ──────────────────────────────────────
~45 blocking stops                           3 + 1 per amendment the owner must rule
one shared index, 3 measured corruptions      one worktree per autonomous run
"who rules this?" → only "the owner"          → a named principal, in the signature
```

**What returns the owner, exhaustively** — this list is a DoD item, not a summary:

| Trigger | Channel |
|---|---|
| An amendment originating with its otherwise authorised LEAD ruler | §12 to the human; forwarding cannot change the proposer |
| An amendment against a claim the owner reserved to themselves | §12 directly |
| Purpose Check finds the reference set self-contradictory | `judge.md` → owner, contract defect |
| ❌ REJECT verdict | `review.md` → owner |
| The selected LEAD or an assigned role holder is unavailable | §12 `SUPERSEDE`; the task waits — no silent substitution |
| Scope growth reaches owner authority under the approved VALUE plan or changes a reserved boundary | §6 accounting plus rule 19 → owner before work; no retrospective waiver |
| An initiation chain that does not terminate at a human | refused; the work does not start |

### 3.2 Value Flow

| Step | Input | Transformation | Value created |
|---|---|---|---|
| Declare participants | who is in this project, and what each is here | `team/{handle}.md` gains role context; agent principals become declarable | Roles stop living in prose no parser reads, and `type: agent` stops being decorative |
| Declare the grant | the owner's judgement about which principal may rule | select one stable LEAD with an immutable grant | No permanent profiles are needed for its working sessions |
| Bind attribution | which principal a unit acts under | binding for identity; owner mandate and scoped dispatch for authority | Shared attribution does not hide the actual producing unit |
| Freeze and choose | approved HL, then manual/AT choice and bounded reach | committed contract plus explicit owner mandate in existing traces | The purpose stays fixed while the owner chooses when to delegate |
| Isolate | concurrent work | a worktree per autonomous run, named readably | Index contention ends structurally; the trace stops being corrupted by a neighbour |
| Dispatch | bounded work under the selected LEAD | `kind: dispatch` distinguishes principal and actual source/destination units | The LEAD provisions work without making the owner maintain a named roster |
| Route | pressure on a frozen claim with preserved origin | parent units return to eligible LEAD or owner | Operational delegation cannot launder self-ruling or create grants |
| Land | a deliverable crossing a session boundary | its own commit, subject naming the producer | `git log -- <path>` answers which task delivered it |
| Defend | the finished result | Purpose Check against baseline + NS1–NS3 | Verified, complete and beside the point stays rejectable |

## 4. Phases 🔒 FROZEN

Each phase carries **its own derivation-only HL** (`conventions.md` §3 rules 20–21) plus TS → ONB →
RF → REVIEW and its own `status.md` and `journal/`.

### Phase Dependencies

```mermaid
graph LR
  A[Phase A: isolation and attribution] --> B[Phase B: named principals]
  B --> C[Phase C: authority routing]
  C --> D[Phase D: team mode and Role Assignment]
  D --> E[Phase E: sweep, correction, release]
```

| Phase | Depends on | Shared files | Can run in parallel with |
|-------|-----------|--------------|-------------------------|
| A | Independent | `conventions.md` §4 · `handoff.md` · `review.md` | — |
| B | A | `conventions.md` §4 | — |
| C | B | `conventions.md` §3 · `review.md` · `plan.md` | — |
| D | C | `conventions.md` §3, §7 · `plan.md` · `review.md` | — |
| E | A + B + C + D | glossary, adapters, version | — |

Strictly sequential, and deliberately so: four of the five touch `conventions.md`, and this task's
subject is what happens when concurrent sessions write one thing. Phase A ships the isolation that
makes later parallelism safe; running the phases in parallel before it exists would be the
anti-pattern demonstrating itself.

### Phase A: Isolation and attribution for concurrent work 🔴

> **Requires:** Independent
>
> **⚠️ Shared files with Phase B:** `.tfw/conventions.md` §4 — A owns Commit Attribution and the
> worktree protocol; B opens the profile schema and the identity fields. Sequential.
>
> **Context for coordinator:** 1. `conventions.md` §4 Commit Attribution and "Which handle a machine
> acts as" · 2. `knowledge/risk.md` F1 · 3. `tasks/DEBT-SNAPSHOT.md` TD-144, TD-178 ·
> 4. `TFW-60/phase-a/review/judge.md` row 10 — the third occurrence, inside a release ·
> 5. `git worktree list` on this machine, and `~/.codex/worktrees/` as the vendor's answer ·
> 6. `knowledge/environment.md` F3, F4 — the shell rewrites a leading `/`, and `--grep` cannot be made
> subject-only · 7. NS3 non-goals · 8. this HL §3, §7
>
> **Key decisions:** D55 (the commit subject is the only record of task ownership) · D68 (task-local
> state; no shared write) · D59 (recoverability ≠ locking — a worktree is isolation, not a lock)
>
> **⚠️ Cascade dependency:** `handoff.md` and `review.md` both carry the seven-workflow identity
> preamble; edits must not orphan it. The landing-commit rule must stay subject-based, or it
> reintroduces the `--grep` defect TFW-53 already paid for.
>
> **Deliverables:**
> 1. A worktree protocol in `conventions.md` §4: where a worktree lives, a name that reads back to its
>    task and principal, who may create one, when it merges, who deletes it, and the disposition of one
>    whose session died. Built on `git worktree`; no implementation of our own.
> 2. Exact-path staging: `git add -A`, `git add .` and `commit -a` named and forbidden; audit the
>    cached diff before every commit; never commit a sibling's hunk because it is already staged;
>    preserve unrelated dirty work and report the overlap instead of normalising it.
> 3. The landing-commit rule: a deliverable committed by a session other than its producer goes in its
>    own commit, subject naming the producer's task and phase, `role` the acting role. Worked example
>    from TD-178.
> 4. Both role surfaces: `handoff.md` for the executor, `review.md` for the reviewer.
> 5. `conventions.md` §14 anti-patterns for both failures, each naming its measured occurrence.

### Phase B: Named principals 🔴

> **Requires:** Phase A ✅
>
> **Context for coordinator:** 1. `templates/team/profile.md` in full — the four-key schema and the
> agent deferral · 2. `templates/journal/event.md` — the two identity fields and why `actor` went ·
> 3. `templates/bindings.yaml` · 4. `conventions.md` §4 "Which handle a machine acts as" ·
> 5. `FA15ES` HL for the five field-tested distinctions, as evidence and never as authority ·
> 6. D59 · 7. `knowledge/constraint.md` F12 — obligations belong in files, never in a tool's memory
>
> **Key decisions:** D59 (declared attribution ≠ authentication) · D68 (an event name ends in an
> opaque token, not an actor) · D45 (a schema addition needs a payload argument, not convenience)
>
> **⚠️ Cascade dependency:** the writer field must compose with immutable legacy events that already
> carry a tolerated `actor`. Nothing existing is rewritten, and no validator may start failing on it.
>
> **Deliverables:**
> 1. `organization_role` and `project_role` as declared descriptive context, with stated semantics for
>    absence, and a migration under which existing four-key profiles stay valid.
> 2. The agent principal: what makes a name a principal rather than a provider, a model or a session;
>    the human it is accountable to, named in its own profile.
> 3. A writer field for new events, so an initiation edge can be recorded; legacy `actor` untouched.
> 4. A binding may select a principal alongside a human handle.
> 5. Optional mentality in the profile — identity and style, never authority.
> 6. The two-grant-levels pattern: authority carried by the name, one principal per level.

### Phase C: Authority routing 🔴

> **Requires:** Phase B ✅
>
> **A7 approval epoch:** retain C's completed RF/REVIEW and 2.2.0 history. Phase D revises its live
> routing consumers to distinguish the selected principal from subordinate units; it does not
> retroactively claim that C delivered this later owner-approved model.
>
> **Context for coordinator:** 1. `conventions.md` §3 rules 8, 9, 12, 17–19 · 2. `templates/HL.md` §12
> in full · 3. `workflows/review.md` verdict routing · 4. `workflows/plan.md` Step 6c–6d ·
> 5. `philosophy.md` F37 — a mandate that justifies its own extension is the root cause ·
> 6. D59's fifth boundary — a separate agent session ≠ an independent person
>
> **Key decisions:** D63 (the contract and its amendment channel) · F37 · D59
>
> **⚠️ Cascade dependency:** rule 8 is cited from `plan.md`, `review.md`, `research/base.md` and the
> HL template. Changing what "owner verdict" means changes all of them at once.
>
> **Deliverables:**
> 1. The initiation chain as a rule: what an edge is, how it is recorded, and that it terminates at a
>    human by construction — a chain that does not is refused before work starts.
> 2. Who rules a §12 proposal: the selected LEAD, only with its immutable grant and a distinct
>    originating proposer, otherwise the owner. Unit parentage routes the proposal; it does not
>    multiply principal grants or erase origin through forwarding.
> 3. `conventions.md` §3 rule 8 rewritten deliberately, stating what the guarantee now is and what it
>    was, so the weakening is legible rather than discovered.
> 4. The coordinator invariant: every edge of the chain starts at a coordinator; an executor initiates
>    nobody; a phase coordinator may not initiate the task coordinator.
> 5. `conventions.md` §14: self-ruling including through another unit; shared writer mistaken for
>    node identity or grant; a chain not rooted in a human; an executor dispatching work.

### Phase D: Team mode and Role Assignment 🔴

> **Requires:** Phase C ✅
>
> **Context for coordinator:** 1. `conventions.md` §7 in full · 2. §3 rules 5–9 for
> freeze granularity · 3. §5 for the lifecycle vocabulary the "Autonomous from" column reuses ·
> 4. `templates/journal/event.md` `kind: dispatch` · 5. `templates/HL.md` §4 and its subsection
> inheritance note · 6. research iterations 1–3 for measured routes, observable role gates and the
> Claude-native acceptance gate · 7. this HL §3.1 and A7 · 8. D's latest REVIEW revision and C's
> delivered RF/REVIEW, not C's old plan as evidence of the new semantics
>
> **Key decisions:** D31 (durable artifacts carry state, not session memory) · D54
> (parity is behavioural) · D62 (defaults follow observed practice) · research iter3 D1–D10
> (observable role contract, provider-homogeneous first release, dispatch-time diagnostics)
>
> **⚠️ Cascade dependency:** A7 separates approved HL, post-approval owner mode/LEAD choice and
> bounded unit instantiation. Update every live consumer of pre-freeze roster/handle-as-node
> assumptions together. The root principal, unit provenance and no-self-ruling checks must compose;
> a template-only change or identical `writer` values everywhere cannot satisfy the outcome.
>
> **Deliverables:**
> 1. `conventions.md` §7: the third mode — entry condition, what the coordinator owes the owner, what
>    a delegate owes the coordinator, the exhaustive return list from §3.1, and degradation stated as
>    behaviour rather than mechanism.
> 2. `templates/HL.md` Role Assignment separates one owner-selected `team/` LEAD from subordinate
>    working units, scope, reports-to, direct channel and **"Autonomous from"**. Mode selection may
>    follow HL approval; no full unit roster or per-role profile is a pre-freeze prerequisite.
> 3. `conventions.md` §3: mandate commitments freeze; ordinary unit instantiation within them is not
>    an amendment. Widening approved coverage/reach, replacing the principal or an unavailable role
>    holder, and removing a control retain explicit amendment authority. Historical rows/dispatches
>    are preserved; dropping a control is never `RESTRICT`.
> 4. Existing `dispatch` and role artifacts record principal attribution, actual source/destination
>    units, scope, role, human-rooted parentage and originating-proposal provenance. No new carrier.
> 5. `plan.md`, `handoff.md`, `review.md`, `research/base.md`: declare, receive, report.
> 6. First-release profiles preserve one provider across every long-lived Role Assignment chain.
>    Mixed fresh runs are bounded helpers only. Before a Claude profile is specified or dispatched,
>    one native route must pass iteration 3's eight-step gate in a complete TFW unit; documentation or
>    the Helpdesk relay topology is not acceptance evidence.
> 7. Resolve the latest REVIEW's supplied-profile admission contradiction in the same TS revision:
>    the initial supplied profile may proceed at its explicitly limited evidence level; an additional
>    profile needs the complete native gate. Verify the combined canon/adapter outcome, not just
>    separate gate labels. No G8 reliability claim is created by this exception.

### Phase E: Sweep, correction, release 🟡

> **Requires:** Phases A ✅ B ✅ C ✅ D ✅
>
> **Context for coordinator:** 1. the eleven sites listed in §2 · 2. `knowledge/constraint.md` F11 ·
> 3. RF TFW-53/D for the adapter-sync procedure and the drift check · 4. `workflows/config.md` drift
> check · 5. `stakeholder.md` F8 — a check that keeps printing known failures stops being read ·
> 6. every REVIEW produced by phases A–D
>
> **Key decisions:** D54 (adapter parity) · F8
>
> **Deliverables:**
> 1. All eleven "that is TFW-54" sites swept to name this task or the shipped mechanism.
> 2. `knowledge/constraint.md` F11 corrected with what was measured and when, through `/tfw-knowledge`.
> 3. Glossary: principal · initiation chain · worktree protocol · landing commit · the mode's name.
> 4. Adapter copies re-synced; the `config.md` drift check runs silent afterwards.
> 5. Version and `CHANGELOG.md`.
> 6. Every debt item captured by the reviews of A–D disposed of before this task closes.

## 5. Definition of Done (DoD) 🔒 FROZEN

Each item states a phase's outcome, not its implementation. How a phase meets its outcome is
refinement inside an approved phase (`conventions.md` §3 rule 6) and stays discussable.

- ✅ 1. A worktree protocol exists in the canon, built on `git worktree`, and answers all six
  questions: location, a name that reads back to task and principal, who creates, when it merges, who
  deletes, and the disposition of a dead session's worktree.
- ✅ 2. Broad staging is named and forbidden, staging by exact path is required, and both role
  surfaces carry the rule — not a directive in one place.
- ✅ 3. A deliverable that crosses a session boundary is recoverable from `git log -- <path>` by the
  task that produced it, and the rule that makes it so carries the TD-178 worked example.
- ✅ 4. `team/` profiles carry organisation and project role, and every existing four-key profile
  stays valid without an edit.
- ✅ 5. `type: agent` is consumed: one stable agent principal can be selected as LEAD and named as
  writer for its bounded mandate. Its subordinate units can be dispatched and assigned roles
  without creating additional personal profiles.
- ✅ 6. Every agent principal names the human accountable for it, and no chain of initiation can be
  written that does not terminate at a human.
- ✅ 7. A new event can name its writer; every event written before this change is still valid,
  unedited, and fails no check.
- ✅ 8. Bindings select attribution, while explicit owner selection and dispatch establish the
  LEAD mandate and each unit's authority. Neither shared attribution nor a new session creates a
  grant. No liveness file, process lock or start command is introduced.
- ✅ 9. Verdict authority is carried by the principal's name, so a §12 row identifies both the signer
  and the authority it held, with no lookup into a mutable grant. The actual originating unit is
  retained, so distinct subordinate work remains distinguishable from forwarded LEAD proposals.
- ✅ 10. `conventions.md` §3 rule 8 states the current guarantee and the one it replaced, so the
  change from "the owner rules" to "the authorised LEAD rules subordinate proposals, with human
  exceptions" is legible. C's earlier handle-chain model is not silently equated with A7.
- ✅ 11. The coordinator invariant is a principle: every initiation edge starts at a coordinator, and
  each new child has one validated parent; a shared principal does not collapse the unit chain.
- ✅ 12. `conventions.md` §7 defines AT entry as approved committed HL, explicit owner-selected
  LEAD/mandate, and bounded role assignment/dispatch. It states mutual obligations and the seven
  owner-return channels in §3.1. Ultimate accountability stays human.
- ✅ 13. The HL template separates the selected `team/` LEAD and protected mandate from working-unit
  role assignments, with an "Autonomous from" field. The owner can choose after HL approval, normally
  after research; the LEAD can create necessary units itself. No choice leaves CL/explicit AG intact.
- ✅ 14. No rule anywhere makes what a workflow role may do depend on which participant holds it,
  and no vendor name appears in `.tfw/` outside `adapters/`. Verifiable by grep.
- ✅ 15. No site in `.tfw/` or `knowledge/` still names TFW-54 as a future deliverable, and F11
  carries a re-measured claim with its date.
- ✅ 16. Nothing executable is added: no script, no hook, no daemon, no lock, no config key that
  selects behaviour, and no new artifact class or per-task file.
- ✅ 17. Every debt item captured by the reviews of phases A–D is disposed of before this task closes.

## 6. Definition of Failure (DoF) 🔒 FROZEN

- ❌ 1. **The mode merely thins gates instead of transferring routine coordination to the selected
  LEAD**, or pretends to transfer ultimate accountability away from the human. Requiring the owner
  to create/name each subordinate recreates manual routing under an autonomous label.
- ❌ 2. Anything executable ships: a spawner, a scheduler, a lock, a daemon, a worktree
  implementation of our own. NS3, and TFW-49's cause of death.
- ❌ 3. A liveness registry appears in the project tree under any name — a running-process file, a
  session registry, an active-agent list. It is state that must agree with a process, and the process
  will die first.
- ❌ 4. A rule makes a workflow role's permissions depend on which participant holds it, or a
  mentality changes what a principal may do. That is the self-extending grant re-entering by a new door.
- ❌ 5. A profile role grants or implies permission. D59's second boundary, and the whole reason
  roles are called context.
- ❌ 6. AT is reachable without an approved committed HL, explicit owner selection of LEAD and
  mandate, and bounded role assignment/dispatch, or via a `project_config.yaml` key. A pre-frozen
  full roster is not a substitute for that owner act.
- ❌ 7. A new artifact class or per-task file is required. Artifact count is a live constraint (S7),
  and the answer to auditability is `dispatch` plus the role artifacts, not a new file.
- ❌ 8. **The weakening of rule 8 ships silently** — the canon reads as though "the owner rules" is
  still true while a principal may rule. This is chosen with open eyes (owner ruling 2026-09-02) and
  the failure is concealing it, not making it.
- ❌ 9. An amendment can be ruled by its own originating proposer, including after forwarding,
  transcription or session replacement; or a subordinate acquires the LEAD's ruling grant merely
  because its work shares principal attribution.
- ❌ 10. This task's own research is treated as proof of the mode because it was convenient: the RES
  files report conclusions without reporting what the tools actually did, including the failures.
- ❌ 11. Branch policy, merge strategy or a second transport is decided here, taking TFW-61's subject.
- ❌ 12. An edited document creates avoidable attention debt: a document at or below ~1200 words
  crosses it without material necessity, or an inherited over-limit workflow grows beyond the minimum
  required to preserve meaning or place a rule at its enforcement site. The TS states the necessity
  and the rejected shorter form; EV records exact before/after counts.

**On failure:** DoF 1 → stop and re-plan; the mode is not worth shipping. DoF 2, 3, 4, 5, 6, 7, 9, 11
→ revert the offending deliverable and file a §12 amendment; do not repair in place. DoF 8, 10, 12 →
correct within the phase: these are drafting failures, not design failures.

## 7. Principles 🔒 FROZEN

1. **Human authority, bounded delegation.** NS2 principle 5: name boundaries, acceptance
   authority, accountability, stop conditions and escalation *before* granting autonomy. Every
   deliverable here either names one of those or it does not belong. The human initiates the named
   LEAD's mandate and retains ultimate responsibility throughout its subordinate chain.
2. **A mandate is a ceiling, never a source of permission.** `philosophy.md` F37; `conventions.md` §3
   rules 17–19. This task distributes what the owner approved and creates nothing.
3. **Every initiation edge starts at a coordinator.** An executor initiates nobody; a phase
   coordinator may not initiate the task coordinator. Cycles become unconstructible instead of
   forbidden.
4. **Every chain terminates at a human.** One selected LEAD principal names its accountable human;
   subordinate units resolve their declared parent chain to that mandate, never to an invented
   profile. Accountability is not itself root authorisation or a ruling grant.
5. **Authority is carried by the name.** A grant recorded in a mutable file makes an old signature
   unreadable; a grant carried by the principal's name is legible in the signature forever. Events are
   immutable, profiles are not. Selecting a named LEAD does not create a new grant, and acting on
   its behalf does not distribute its amendment powers to every unit.
6. **A role is context; it is never permission.** D59's second boundary. Role Locks and the frozen
   contract grant work; a title grants nothing.
7. **Permissions are per role, never per participant.** A table that lets a strong participant do more
   is the grant that extends itself.
8. **Git owns the mechanism, TFW owns the protocol.** Depending on git is not vendor dependence — it
   is the platform this framework already declared. Writing our own would be either code in the
   repository or a worse copy of something correct.
9. **Nothing executable.** The mode is conventions and markup. Every promise is behavioural, in the
   shape of D54.
10. **A separate agent session is not an independent person.** D59. This mode promises parallelism and
    addressability. Separate Executor and Reviewer units protect Role Locks without requiring two
    personal profiles or claiming independent human judgement.
11. **The autonomy boundary is explicitly chosen, not inferred.** After HL approval the owner may
    select manual or AT work, one LEAD and its reach. That choice lives in the existing contract and
    dispatch traces; later ordinary unit creation stays within it, never widens it silently.
12. **Isolation is not a lock.** D59's third boundary. A worktree removes index contention; it does not
    serialise anything, and no rule may treat it as if it did.

### 7.1 Quality Contract 🔒 FROZEN

Copied into every Phase TS.

- Word budget: 700–900 words remains the working range and ~1200 remains the attention threshold
  (`constraint.md` F2). A document at or below the threshold does not cross it unless required meaning
  or enforcement cannot survive a shorter form. An inherited over-limit workflow may grow only by the
  minimum materially necessary addition. The TS states why a shorter reference, substitution or cut
  would lose meaning; EV records exact before/after counts. This exception grants no unrelated prose.
- No new file, folder, config key or artifact class. A phase that believes it needs one files a §12
  amendment instead.
- Every rule lands at an enforcement site — a workflow step, a template field, a §14 anti-pattern.
  `process.md` F30: capture without an enforcement site does not change behaviour.
- Rules are written as prohibitions with named forms, never as advice. `risk.md` F1 measured the
  alternative at 0 successes out of 1.
- No vendor name outside `adapters/`. Verified by grep before the RF is written.
- A corrective pass may not grow the artifact it corrects.
- Every phase works in its own worktree from Phase A onward, and stages by exact path from the moment
  Phase A ships. This task is governed by its own first deliverable.

### 7.2 Knowledge Citations 🟢 FREE

| # | Source | Item | How it applies |
|---|--------|------|----------------|
| 1 | PV 0 — [`.tfw/README.md` #ns1](../../../.tfw/README.md#ns1) | *"another authorized person or agent can understand what the work is for… see where authority remains, and continue"* | The purpose of naming principals and routing authority: continuation by someone else, inspectably |
| 2 | PV 0 — [#ns2](../../../.tfw/README.md#ns2) principle 5 | Human authority and bounded delegation require named boundaries, acceptance authority, accountability, stop conditions and escalation before autonomy | A7 selects one LEAD while retaining the human's ultimate responsibility and explicit return conditions |
| 3 | PV 0 — [#ns3](../../../.tfw/README.md#ns3) | non-goal: *"a vendor-bound tool, runtime, model, interface, or memory feature"* | DoF 2; the reason git owns the worktree mechanism and we own the protocol |
| 4 | PV 0 — [#ns2](../../../.tfw/README.md#ns2) principle 7 | Assurance proportional to risk; subtract ceremony that does not protect purpose | No profile per role or session; existing dispatch and role artifacts carry provenance without a new registry |
| 5 | PV 1 — [#methodology-values](../../../.tfw/README.md#methodology-values) | Structural Enforcement | A7 separates committed contract, owner mandate and bounded dispatch checks; a roster alone grants no autonomy. Worktree isolation preserves separate mutation owners |
| 6 | PV 1 — same | Naming Creates Behavior | The grant is carried by the principal's name, so the signature is self-describing |
| 7 | PV 1 — same | Portability | No vendor name in `.tfw/`; participants are project-local handles |
| 8 | PV 2 — [`knowledge/philosophy.md`](../../../knowledge/philosophy.md) F37 | A mandate that can justify its own extension is the root cause | §7 P2; DoF 4 |
| 9 | PV 2 — same F38 | Coordinator attention is a finite resource, budgeted deliberately | Why five phases with their own HLs, and why TFW-58 and TFW-61 stay external |
| 10 | PV 3 — [`KNOWLEDGE.md`](../../../KNOWLEDGE.md) D59 | Five boundaries: availability ≠ tested · declared attribution ≠ authentication · recoverability ≠ locking · a separate session ≠ an independent person | §7 P6, P10, P12; DoF 5. Four of the five constrain this task directly |
| 11 | PV 3 — same D68 | Task-local state, immutable one-file-per-event journal, derived index, opaque event token not an actor | Phase B's writer field must not become the filename token again; no shared live file is introduced |
| 12 | PV 3 — same D63 | An approved HL is a contract; six sections freeze | The mandate this mode is bounded by, and what Phase C rewrites at rule 8 |
| 13 | PV 3 — same D64 | The reviewer defends purpose and must cite the clause | The external stop on a coordinator running a team |
| 14 | PV 3 — same D55 | The commit subject is the searchable record of declared context | §7 P8; Phase A's landing rule |
| 15 | PV 3 — same D54 | Adapter parity is behavioural, not file-layout | §3 item 9; Phase E |
| 16 | PV 3 — same D31 | File existence = state | Durable HL/dispatch traces, not an unrecorded chat choice or a config key, make the selected mandate reconstructible |
| 17 | PV 4 — [`conventions.md`](../../../.tfw/conventions.md) §3 rules 17–19 | Delegated authority: ceiling, no self-widening, never an excuse for an overrun | Already shipped; applied here, not re-authored |
| 18 | PV 4 — same §3 rules 20–21 | A Phase HL is derivation-only | The owner's per-phase HLs are legitimate; the boundary is stated in the header |
| 19 | PV 4 — same §14 | Anti-patterns are the enforcement site | Phases A, C and D each append rows |
| 20 | PV 5 — [`knowledge/convention.md`](../../../knowledge/convention.md) | Naming consistency as a design rule | Phase E's glossary terms |
| 21 | PV 6 — [`knowledge/process.md`](../../../knowledge/process.md) F6 | A coordinator without oversight drifts into scope explosion | The failure this mode could reproduce; answered by the frozen contract plus the Purpose Check |
| 22 | PV 6 — same F30 | Capture without an enforcement site does not change behaviour | §7.1; every deliverable names its site |
| 23 | PV 6 — same F7 | Agents in different sessions lose strategic context | Why the routing table lives in the HL — the artifact every role already loads |
| 24 | PV 7 — [`knowledge/constraint.md`](../../../knowledge/constraint.md) F11 | *"Fully independent agent sessions are a Codex-only capability"* | **Measured false while writing this HL.** §2 records what was verified; Phase E corrects the fact |
| 25 | PV 7 — same F12 | What a role is obliged to do belongs in files, never a tool's memory | Why the grant is in the tree, not in the per-machine binding |
| 26 | PV 7 — same F2 | Instructions degrade past ~1200 words | §7.1; DoF 12 |
| 27 | PV 7 — [`knowledge/risk.md`](../../../knowledge/risk.md) F1 | Two sessions, one index; a verbal staging directive survived 0 of 1 | Phase A in full, and the reason isolation beats a rule |
| 28 | PV 7 — [`knowledge/stakeholder.md`](../../../knowledge/stakeholder.md) F6 | The owner objects to frequency, never to being bound | §1; DoF 1 |
| 29 | PV 7 — same F7 | The result must be rendered before tokens are spent; the visualization gate is a precondition of this mode | §3.1 is a gate here in the strongest sense — this is the task it was built for |
| 30 | PV 7 — same F8 | A check that keeps printing known failures stops being read | Phase E: the drift check must run silent |
| 31 | PV 7 — [`knowledge/environment.md`](../../../knowledge/environment.md) F3, F4 | The shell rewrites a leading `/`; `--grep` cannot be subject-only | Phase A must reintroduce neither in the landing rule |
| 32 | PV 7 — `editions/02-assisted/team/README.md` | Ships `Роль в компании` / `Роль в проекте` with three absence values and the rule that the two are never merged | Field evidence for Phase B's schema, never authority over it (S4). Also where Full's `agent` and Assisted's `automation` diverge — two editions, two nouns, one concept |
| 33 | PV 3 — [`KNOWLEDGE.md`](../../../KNOWLEDGE.md) D68 | *"an event name ends in an opaque uniqueness token, not an actor"* | Read against the §12 ruling of 2026-09-03: the token already carries uniqueness alone, which is why reviving a writer field is legitimate and why it must never re-acquire the second job |
| 34 | PV 3 — same D73 | The canonical workflow owns ordered, uniquely addressed reads; one manifest owns adapter topology | Phase A must connect each new rule to the exact role checkpoint and synchronize only the manifest-declared copies |
| 35 | PV 3 — same D74, D75 | Primary and secondary paths preserve semantics while selecting the smallest sufficient context | The removed universal preamble is not an insertion point; Phase A preserves selective loading and proves no route regression |
| 36 | PV 6 — [`knowledge/process.md`](../../../knowledge/process.md) F39 | The delivery set of a rule is a search result, not a remembered list | The TS derives every defining, consuming, copied, and verification site before the rule is written |
| 37 | PV 1 — [Success Criteria](../../../.tfw/README.md#success-criteria) items 1, 2 and 4 | Durable continuation, traceable material decisions, result ready for acceptance | A7 retains producing/proposing unit provenance and separate review even when all working sessions share one LEAD principal |
| 38 | PV 3 — [`KNOWLEDGE.md`](../../../KNOWLEDGE.md) D80–D82 | Stable principal, human-rooted routing and role activation are different contracts | Preserve B's profile substrate; revise C–D's handle-as-node and pre-freeze-roster assumptions prospectively. D82's original review is not acceptance of A7 |

## 8. Dependencies 🟢 FREE

| Dependency | Status |
|------------|--------|
| TFW-53 — frozen contract, amendment log, baseline, Purpose Check, delegated-authority ceiling | ✅ DONE |
| TFW-60 — task-local state, immutable journal, `team/`, bindings, `dispatch` vocabulary | ✅ substrate shipped |
| TFW-55 — Project North Star designated as NS1–NS3 | ✅ DONE — the Purpose Check has a reference set above the task |
| TFW-54 — historical source | 🔒 `REJECTED — superseded`, read-only |
| TFW-61 — collaboration transport | ⬜ boundary only; branch and merge policy must not be decided here. **Ownership recorded 2026-09-03:** its proposal claims *"task-owned explicit-path staging, no shared-index ambiguity"* as its own Git-mode deliverable, which is Phase A deliverable 2 verbatim. The coordinator takes it into Phase A — this task needs the rule on itself from day one, and TFW-61 has neither an HL nor a freeze. The second task to arrive must not re-author it |
| TFW-58 — revise protocol | ⬜ boundary only. H8 is **not testable in AFD** (measured below) and moves here to a negative claim: the Role Assignment neither forbids a different participant on a revision round nor promises it helps. The loop is theirs |
| TFW-45 — stage-level swarm | ❄️ FROZEN. One shared word measured: `coordinator`, 17 uses there for per-stage spawns inside one workflow against 48 here for a workflow role across a task. Every other term is disjoint. Phase E's glossary qualifies it |
| Per-machine binding file | ⬜ absent at both `~/.tfw/bindings.yaml` and `%LOCALAPPDATA%\tfw\bindings.yaml`; Phase B will be its first real use. It selects attribution and grants nothing |
| Worktree mechanics, as measured | ✅ an app-managed worktree is normally detached and tied to one chat, shares the repository's git metadata, and permits a branch in only one worktree; nested subagents share the parent checkout unless a boundary is created explicitly |
| RCFR — Runtime Context Footprint Reduction | ✅ `DONE` in `master`; D73–D75 are the current context and adapter topology that every CRATM phase preserves |
| VBSA — Value-Bearing Scope Accounting | ✅ `DONE` and landed at `125ec27`; its value-bearing accounting governs Phase A's TS, Candidate and review |
| Research iteration 3 — provider profiles | ✅ complete and sufficient for current planning. Claude-native acceptance remains a Phase D profile gate, explicitly not a Phase A dependency |
| `gen_index.py` | ✅ active RCFR substrate for the Knowledge Gate, but not a CRATM deliverable: this task neither edits nor extends it |

## 9. Risks 🟢 FREE

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| R1. The mode is used before the ecosystem is ready and reproduces TFW-48/49 at smaller scale | Medium | High | Three-part entry condition; the Purpose Check as external stop; DoF 1 makes an unconvincing mode a failure rather than a shipped compromise |
| R2. Worktree isolation moves conflict from the index into a merge, and the merge is worse | Medium | Medium | Phase A's protocol must state when a worktree merges and who owns the merge. Research iteration 1 measures what Codex actually does with detached HEAD |
| R3. Delegated verdict authority is used where the owner would have decided differently | Medium | High | The grant is per principal and visible in the signature; the no-self-approval rule holds at every distance; the owner may reserve claims to themselves |
| R4. A brought-down or replaced delegate leaves no trace beyond its `dispatch` event, so a failed run is partly undiagnosable | Medium | Medium | `dispatch` now exists, which is more than TFW-54 would have had. Revisit trigger: the first run whose token spend cannot be accounted for |
| R5. Vocabulary collides with TFW-45, or Phase A drifts into TFW-61's transport question | Medium | Medium | DoF 11; H2 tests the boundary before the Phase D TS |
| R6. Phase B's writer field re-acquires the second job that killed `actor` | Low | High | D68 names it: uniqueness lives in the opaque token, identity in the field. Phase B's context block carries the original failure |
| R7. This task's own research becomes advocacy for the mode it tests | Medium | High | DoF 10; all three RES files report mechanics, failures and evidence limits, not conclusions alone |
| R8. Five sequential phases on one file stall on their own dependency chain | Medium | Medium | Phase A ships isolation first, so B–E each run in their own worktree; per-phase HLs let the owner keep discussing later phases without blocking earlier ones |
| R9. **A cross-vendor follow-up lands in a human's own session.** Measured once, read-only, from the obvious command (§2) | Medium | High | The dispatch captures the returned session id and the protocol follows up by id, never `--last`. No worktree prevents this: the shared namespace is the vendor's session store |
| R10. A delegated task returns silence, and the coordinator replaces it, splitting one role across several task ids — observed in field history | Medium | Medium | Inspect the referenced durable artifact and workspace; steer or interrupt the **same** task. Evidence of termination does not itself authorise substitution: the owner-return rule still applies |
| R11. **A Role Assignment row promises a semantic channel the selected route cannot open.** A route label or documented feature is promoted into a working long-lived peer without a direct nonce round trip | Medium | High | Test the exact target at dispatch. First release keeps long-lived chains provider-homogeneous; a failed direct route stops rather than degrading into relay or owner forwarding |
| R12. Residual worktree failures: stale base, a detached commit with no landing path, an ignored dependency absent from the worktree, cleanup before durable landing, and a broad landing that reintroduces the attribution error | Medium | Medium | Phase A's protocol answers each; the measured residue is litter rather than dangling trees, so cleanup is the cheaper half |
| R13. Parallel writes inside one task or worktree, since nested children share the parent checkout | Medium | Medium | One mutation owner per worktree; serial role changes where children share a checkout; read-only parallelism for research and review |
| R14. A Claude route is accepted from documentation, a nonce or the Helpdesk relay run rather than a complete native TFW unit | High | High | Before Phase D specifies or dispatches any Claude profile, one candidate must pass iteration 3's common eight-step gate, including isolation, correction, terminal reconstruction and owner-turn outcome |
| R15. **Installed behaviour changes across CLI versions, OS and surfaces.** The same direction changed its required overrides and cost after an upgrade; the installed Claude build trails newer documented native-Windows routes | High | Medium | Version, OS, tools and flags are dispatch-time diagnostic evidence only. Role Assignment and profiles name stable participants and behaviour, never a mutable version registry |
| R16. **Follow-up cost grows with the thread.** A resume replays it: 18,623 tokens against 5,030 for a cold call | Medium | Medium | Phase D prices delegation granularity on this rather than on the cold-call floor: fewer, larger handoffs beat a long correspondence, which is the same conclusion whole-workflow delegation reached for auditability reasons |
| R17. A profile equates current documented availability with the behaviour of the actual selected executable | Medium | High | Behavioural preflight records executable/surface, version, OS, required tools, worktree base, permission mode and inbound decision in dispatch evidence; no value is copied into the stable profile |
| R18. A new rule is added to `conventions.md` but omitted from the selective Read Contract or inline checkpoint that consumes it | High | High | Phase A treats D73–D75 as a compatibility contract: every rule has a named checkpoint and every manifest route is checked |
| R19. CRATM Phase A silently uses its pre-VBSA file set or accounting order | Low | High | Base the TS after landed `125ec27`; derive adapter copies from the manifest and preserve Candidate-before-EV/RF/REVIEW ordering |
| R20. A request for a peer session is implemented as a nested subagent or an agent-definition file | High | High | Check provider-visible identity and direct addressability for the dispatched unit; a relay-only child or definition without a live address fails. Profile admission follows A6 and Phase D's supplied-versus-additional distinction; one nonce is not eight-gate reliability evidence |
| R21. Claude-only autonomy assumes one universal provisioning path | High | High | Phase D selects and tests one native candidate at a time: lead-created team, owner-opened peer, headless, background or hybrid. Provisioning is route-specific and must complete before the declared boundary |
| R22. A live session roster is introduced to repair addressability, then becomes a second state authority and drifts | High | High | Direct provider-native discovery or explicit target identity plus frozen role artifacts must reconstruct the chain; no `SESSIONS.md`-like carrier is added and provider runtime state never becomes TFW authority |
| R23. A mixed-provider team returns the owner to message routing or smuggles in a bridge runtime | High | High | A6 excludes mixed long-lived role chains from the first release. A bridge is a separate future task with its own value, security, identity and liveness contract; bounded fresh helpers may only return results to a role holder |
| R24. One shared principal collapses all units into one dispatch node or hides a LEAD-origin proposal behind a child | High | High | Revised D TS must test positive distinct-unit routing and negative forwarding/restart laundering together; actual unit origin is separate from principal attribution |
| R25. Post-HL mode selection silently thaws the mandate or lets unit creation broaden scope | Medium | High | First owner choice is explicit; later unit creation only instantiates approved coverage. Widening, owner reservations and unavailable-role replacement retain their ruling gates |

## 10. RESEARCH Case 🟢 FREE

**A7 planning basis.** The new model is the owner's explicit product decision, not a newly verified
provider capability. Existing iterations supply route mechanics and their evidence limits. No new
research iteration is opened for relabelling identity: revised D must demonstrate the coherent
single-principal/unit-provenance contract with source-derived positive and negative cases. A genuine
new capability or authority blind spot returns to Main before implementation, not as an assumed pass.

### Blind Spots

All three iterations are complete. Iteration 3 closes the architectural questions needed for current
planning and places the remaining empirical questions at their consuming gates:

- **Peer versus helper is closed at rule level.** A long-lived role must have its own provider-visible
  identity, direct addressability, Role Lock, worktree boundary where it mutates, durable dispatch and
  role artifacts, a legal artifact boundary, and a reconstructible terminal result. A nested child
  behind a relay or an agent-definition file fails before work starts.
- **Claude-only remains an open Phase D profile gate, not a Phase A blocker.** Native teams,
  owner-opened peers, headless resumable sessions, background peers and hybrids are different route
  candidates. Documentation may open a candidate; only one complete native TFW unit can admit it.
- **Codex is the first-release profile candidate.** RCFR and VBSA support gates G1–G7 through
  user-visible tasks, direct coordinator routing, separate worktrees and legal role artifacts. G8 — a
  predeclared, counted walk-away result — remains uncontrolled and is not claimed as reliable.
- **Mixed long-lived execution is closed for the first release by A6.** Plausible bridge ingredients
  do not constitute an existing-session route and would add a runtime/security surface outside CRATM.
  Research resumes only in a separate task if mixing gains independent value.
- **Claude-native acceptance uses one common eight-step gate.** It captures behavioural preflight,
  freezes one small TFW unit, proves provisioning identity and a nonce-bearing direct route, isolates
  mutations, completes a forced correction across the legal roles, classifies every owner turn, and
  reconstructs the terminal unit without provider runtime state.
- **What the principal field is checked against.** Both available answers have already failed once in
  this repository: free text drifted (`claude` → `claude-code`, one tool with two spellings inside one
  corpus), and a handle-per-writer forced two external projects into a profile per agent session.
  Phase B's decision, priced against the 126-event corpus rather than guessed.
- **Whether the principal field reuses the name `actor` or takes a new one.** Reviving `actor` is
  cheap and natural, and leaves one field with three meanings across an immutable corpus — six legacy
  events carry it, three of those naming a tool rather than a person. A new name is unambiguous and
  leaves two words for one concept forever. Opened by the §12 ruling of 2026-09-03.
- **Whether the worktree protocol says anything about session identity per run.** Phase A isolates the
  git index; the fourth measured corruption came through the vendor's session store, which no worktree
  touches. Either the protocol carries the follow-up-by-id rule or it is a §14 anti-pattern and
  nothing more.
- ~~Whether a current Codex build removes the three config overrides~~ — **closed for that measured
  build**. The lasting control is dispatch-time behavioural preflight: executable/surface, version,
  OS, required tools, worktree base and permissions are evidence for the run, not profile fields or a
  live version registry.
- **Reliability of the chain under stress** — ambiguous instructions, an injected child failure, a
  dead child, concurrent writers, interruption and retry. One read-only trial is mechanics, not a rate.

### Hypotheses

All three iterations are complete. Statuses below are the researchers'; the coordinator applied them
without changing a verdict.

| # | Hypothesis | Status |
|---|----------|--------|
| H1 | Codex can carry the full chain — coordinator → phase coordinator → researcher, executor, reviewer — reliably enough that written instructions remove the self-forking, without any TFW-side runtime | 🟡 **mechanics supported, reliability unproven** — iter1. One read-only nested trial: three named children, correct parent paths, no descendant, no hang. Field history also shows silence and recovery splits. n=1; no ambiguous prompt, injected child failure or concurrent writer was tried |
| H2 | Session-level team mode and stage-level TFW-45 swarm can be defined without vocabulary collision, and Phase A can specify a worktree protocol without deciding TFW-61's transport | 🟡 **one word collides, one deliverable overlaps** — both. `coordinator`: 17 uses in TFW-45 against 48 here; everything else disjoint. TFW-61's proposal claims Phase A deliverable 2 verbatim. DoF 11 not breached; ownership now recorded in §8 |
| H3 | A worktree per autonomous run removes index contention at a merge cost lower than the measured corruptions it prevents | 🟢 **isolation supported, cost bounded only qualitatively** — iter1. Two git-index defects are structurally prevented; TD-178 still needs the landing rule. Cost bound: one handoff or branch step plus one exact-path landing. Not benchmarked. Disposition measured by iter2: litter, not dangling trees |
| H4 | Peer Claude sessions are durable enough to hold a delegated workflow; if not, the honest degradation is subagents or sequencing | 🟡 **partly supported, and the premise was wrong** — iter2. Peers persist for days and answer across projects, but cannot be **created** from inside a session, so a Role Assignment cannot name one. The creatable durable delegate is the headless resumable session, measured working |
| H5 | Claude and Codex can exchange more than exit codes, in at least one direction, without a TFW-side mechanism | ✅ **confirmed, both directions, asymmetric** — iter2. Neither can address the other's *existing* session, so a dispatch is send-and-wait with follow-up by id |
| H6 | `dispatch` plus the role artifacts make a delegation inspectable, so narrower-than-workflow handoffs need not be prohibited | 🟢 **supported, with a minimum evidence envelope** — iter1. Eight semantic fields must be durable: destination participant or task, workflow role, bounded scope, authoritative inputs, workspace mode, expected return, continuity instruction, descendant policy. `dispatch` indexes evidence; it is not a transcript |
| H7 | Optional `organization_role` and `project_role` add structured context without a breaking migration, and a team scope is not a third dimension | ✅ **confirmed on both clauses** — iter2. `team_profiles()` parses front matter and validates nothing: no key set, no required keys, so no migration exists to break. Scope already lives in the Role Assignment row, per task; a profile copy would recreate the two-files-must-agree problem D68 removed |
| H8 | On a revision round a fresh participant beats the one that produced the artifact | ❌ **not testable as stated — no control case exists** — iter2. Measured: **138** review arcs, 7 multi-round, reviewer unchanged in **7 of 7**. The figure "13 revision arcs" was the coordinator's error, carried from the TFW-54 proposal. The quoted failure was corrected by the **owner**, not by a replacement, and the same reviewer then produced the corpus's most thorough review — 100% of RF artifacts verified against a 42% floor. Same-family pairs close at 1.03 rounds over 69 arcs, a 98% first-pass approval rate that reads as a self-preference warning rather than efficiency. Moves to TFW-58 |
| H9 | A writer field can name a principal while legacy `actor` stays readable and the opaque filename token keeps its single job | 🟢 **supported** — iter2 measured the corpus half exactly as designed: 126 events, 0 without an accountable party, tolerance holding on real legacy shapes, the token compared against nothing. Its cost objection is void: the validator that turned a template line into a code edit is being retired (§8), so the field is markup again |
| H10 | A Codex-only team can use independently addressable user-visible tasks/threads for every long-lived TFW role, while subagents remain bounded stage helpers rather than role holders | 🟡 **field-supported for G1–G7; G8 not controlled** — RCFR/VBSA carry durable task ids, direct routing, separate worktrees and legal role artifacts; neither run predeclared the autonomy boundary and owner-turn denominator |
| H11 | A Claude-only team can satisfy the same provider-neutral contract if the owner provisions peer sessions before autonomy and the coordinator thereafter uses Claude-native discovery and messaging without relay subagents or a live roster | 🟠 **single-premise form split; broader feasibility open** — owner provisioning is one candidate, not universal. Native team, peer, headless, background and hybrid routes still lack one complete Claude-native TFW acceptance unit |
| H12 | Mixed-provider execution cannot satisfy the walk-away promise with current session controls and should be outside the first release | ✅ **supported as a first-release restriction, not permanent impossibility** — measured fresh crossings do not address existing foreign role tasks; channels/app-server are credible bridge ingredients only for a separately scoped runtime task |

> **Filter applied.** The frozen routing table, the grant carried by the name, the coordinator
> invariant and permissions-per-role are **not** hypotheses: the owner ruled on them between
> 2026-08-18 and 2026-09-02, and they are §7 principles now. Each hypothesis that remains would change
> the approach if refuted.

### Risks of Not Researching

Current planning is no longer exposed to H10–H12 as an unresolved architectural choice: A6 selects
provider-homogeneous first-release chains, Codex proceeds at its stated evidence level, and Claude is
guarded by the Phase D native gate. The remaining cost of not testing is local to those future claims:
without the Claude unit no Claude profile ships, and without a controlled G8 run Codex mechanics are
not advertised as a reliability rate.

### Proposed RESEARCH Focus

Two iterations, **one per tool, each measuring its own side**, by owner ruling 2026-09-02. They are
**parallel and independent**, not sequential — `iterations.yaml` will say so explicitly, because the
default reading is that iteration 2 targets iteration 1's gaps.

1. **Iteration 1 — Codex measures Codex** (H1, H3, H6): thread-based session management along the
   chain; what instruction removes the self-forking; what it does with worktrees, detached HEAD,
   deletion and merge; what a delegate actually receives, read from ONB files rather than assumed.
2. **Iteration 2 — Claude measures Claude and the crossings** (H4, H5, H9): peer-session persistence
   and on-demand creation; whether a Claude session can converse with a Codex run or only read its
   result, and the reverse; two vendors in one worktree; whether a writer field composes with the
   immutable legacy corpus.
3. **Challenge, both** (H2, H7, H8): attack the boundaries against TFW-45, TFW-58 and TFW-61; construct
   the delegations a real coordinator will want that are *not* whole workflows and decide each; test
   the two role dimensions against Full's own carriers.

**The first two RES files report mechanics, not only conclusions** — what forked, what hung, what had to
be said in words. DoF 10 exists because this task's research is the mode's first field run, and
convenience read as proof is the failure mode that costs the most here.

#### Iteration 3 — complete and sufficient 2026-09-05

**Codex tests the architectural split into provider-homogeneous execution profiles; no mixed team is
launched** (H10–H12). Start from the Helpdesk field trace, especially its session roster and TFW
artifacts, and distinguish directly observed Claude peer-session behaviour from relay/subagent
behaviour and from claims that still require a Claude-native trial. The research must not present a
Codex reading of Claude evidence as an end-to-end Claude test, and it may not introduce a live roster
into CRATM.

Evaluate RCFR and VBSA as existing Codex-only field traces against the same observable criteria:
user-visible task identity, coordinator addressability, role separation, worktree isolation, artifact
legality, and owner interventions. Mixed-provider execution is only a negative control: record the
missing direct route and the owner-routing consequence; do not launch a mixed team. The output is a
recommendation for homogeneous profiles, a verdict on whether mixing is deferred to another task,
and the exact acceptance test a later Claude-only run must perform. This is the normal sequential
third iteration, completed by the owner-assigned Codex Researcher task reporting to `Main
Coordinator` through Codex threads. Its remaining Claude-native run is a Phase D gate, not iteration 4
and not a blocker to Phase A.

### Why Not Just...?

- **Why not write our own worktree mechanism?** It would be code in the repository, which NS3 forbids
  and which killed TFW-49 — or a worse copy of something git already does correctly. Git is not a
  vendor; it is the platform this framework already stands on for attribution and baseline recovery.
- **Why not a `tfw-agent-start` command with a liveness file?** State that must agree with a running
  process is the problem D68 removed: the process dies and the file lies. And "one per machine" needs a
  lock, which is a runtime. The canon already rules that two sessions of one tool are two writers, so
  process uniqueness is not what needs guaranteeing — an accountable human per write is, and
  `on_behalf_of` already refuses an event without one.
- **Why not record the grant at session start instead of in the profile?** Events are immutable,
  profiles are not. A grant recorded at start-time and later changed makes an old signature
  unreadable. Two named principals put the grant in the signature permanently.
- **Why not keep TFW-54's rule that only whole workflows may be delegated?** `dispatch` did not exist
  when that conclusion was drawn, and the owner reversed the premise it rested on. It stays the safe
  default and becomes H6 rather than a prohibition.
- **Why not solve staging with a rule instead of a worktree?** A verbal directive was measured at 0
  successes out of 1, and the defect recurred three times including inside a release. Isolation is
  structural; a rule is advice, and the canon's own value ranks the first above the second.
- **Why not fold this into one phase?** F38 is verified: coordinator attention is finite, and the
  owner split TFW-53 from TFW-54 on exactly this ground. Identity, authority and delegation are three
  problems, and the phase boundaries are where the owner can still change their mind cheaply.

## 11. Strategic Insights (Planning) 🟢 FREE

| # | Insight | Category | Source |
|---|---------|----------|--------|
| S1 | **The owner's ask is the strong form, and the weak form is explicitly not worth building:** approve a multi-phase contract, leave, return to a finished result. *«второй я могу и в полуручном режиме провести»*. **Implication:** DoF 1 — a mode that only reduces gate frequency must fail its own acceptance | stakeholder | User, 2026-08-18 |
| S2 | **The cost model is tokens and time, not correctness.** *«сожрано куча токенов. а главное моё время потеряно»*. Drift is priced as waste. **Implication:** the value claim is measured in owner interactions and burned runs | stakeholder | User, 2026-08-18 |
| S3 | **The owner expects the contract plus research to remove surprise entirely:** *«первый hl + research должны снимать все неожиданности. иначе со всей задачей в целом что-то не так»*. **Implication:** amendment count per task is a planning-quality metric here, not merely a log | philosophy | User, 2026-08-18 |
| S4 | **An unavailable participant waits for a decision rather than being substituted:** *«пока без запасного, лучше человека пусть ждут»*. **Implication:** the mode has exactly one declared exception to walk-away, and it is infrastructure, not judgement | stakeholder | User, 2026-08-18 |
| S5 | **Artifact count is a live budget in the owner's head:** *«артефактов и так куча уже»*, and the same pressure opened TFW-57 independently. **Implication:** DoF 7. Zero new artifact classes is a condition, not a preference | constraint | User, 2026-08-18 |
| S6 | **The owner reads the predecessor as an investment awaiting return:** *«я хочу понять как мы извлечем ценность из задачи 53, ведь все делалось ради 54»*. **Implication:** §1 must state the dependency in that direction — this task is what makes the contract pay | philosophy | User, 2026-09-02 |
| S7 | **The owner asks for the negative definition before the positive one:** *«я хочу увидеть что есть задача, а чем она не является»*. **Implication:** the out-of-scope table is load-bearing frozen content, not a courtesy | process | User, 2026-09-02 |
| S8 | **Isolation is preferred over discipline, and the owner reached for the platform rather than a rule:** *«по поводу фазы проще через ворктри решить это»*. **Implication:** this is the project's own Structural Enforcement value applied by the owner to the git index, and it is a better answer than the staging rule the coordinator had planned | process | User, 2026-09-02 |
| S9 | **Platform independence was invoked to argue for writing our own worktree mechanism, and it argues the opposite.** The coordinator's disagreement is recorded because the reasoning matters more than the conclusion: git is already this framework's declared substrate, so the portable split is protocol-ours, mechanism-git | philosophy | Coordinator, 2026-09-02, against User's initial framing |
| S10 | **Field practice already runs the chain this task is designing.** Codex's coordinator creates a phase coordinator which creates the others and controls them downward — *«контролит по цепочке как раз»* — with per-session visibility and stop control. **Implication:** the initiation chain is a description of practice, not an invention, and the unreliability (*«иногда форкает себя»*) is what instructions must remove | environment | User, 2026-09-02 |
| S11 | **The owner arrived at the grant-in-the-name design themselves and named the reason as clarity:** *«у меня будет два именных, один с правом, другой без права? так тоже удобно, даже понятнее»*. **Implication:** §7 P5. The design was not argued into place; the owner's instinct and the immutability of events converged | stakeholder | User, 2026-09-02 |
| S12 | **Delegated verdict authority is chosen with the weakening understood.** The owner asked for it directly — *«надо думать сразу так, что захотим дать право на аммендмент»* — after the coordinator stated that it replaces "no frozen claim moves without the owner" with "without a principal the owner named". **Implication:** DoF 8 — the failure is concealing the change, not making it | stakeholder | User, 2026-09-02, confirmed |
| S13 | **Only the coordinator initiates, and the owner said so before the cycle problem was raised:** *«это должно быть доступно только координатору»*. **Implication:** §7 P3, and it dissolves the acyclicity rule the coordinator had planned for Phase C — one invariant instead of a prohibition | process | User, 2026-09-02 |
| S14 | **Per-phase HLs are wanted so discussion can continue without blocking the first phase:** *«некоторые детали я хочу еще обсуждать, но не тормозить первую фазу»*. **Implication:** the master DoD states each phase's outcome and never its implementation, so later detail stays refinement under rule 6 instead of becoming an amendment | process | User, 2026-09-02 |
| S15 | **The owner assigns research by capability, each tool measuring its own side.** **Implication:** two parallel independent iterations, which also makes this task's research the mode's first field run — the strongest available evidence and, if reported as conclusions only, the weakest | process | User, 2026-09-02 |
| S16 | **The owner's confusion about "when does autonomy start" was two questions wearing one name** — task authority and session identity. Naming them apart dissolved it: the reach is a declared field, the identity is which chair a session sat in. **Implication:** the frozen claim is that the field exists; its value is per-task data, so the owner keeps deciding forever without ever filing an amendment | philosophy | Coordinator synthesis from User, 2026-09-02 |
| S17 | **Delegation, isolation, context payload and durable trace are four independent controls, and no provider capability label stands in for any one of them.** A child path proves topology; only git state proves isolation. **Implication:** the mode is specified as four configurations rather than one switch — read-only delegates share the parent checkout, mutation-bearing ones get a worktree with a single mutation owner | process | Research iter1, D1–D7 |
| S18 | **The owner's autonomy grant arrived as one clause of a command, not as a record.** Iteration 2 was invoked with *«no questions to me»* appended to the invocation — which is exactly the failure mode §3's *"the autonomy boundary is a declared scope, not a moment"* predicts. **Implication:** the value of this task's own field run is that the grant was given in the shape the *"Autonomous from"* column exists to remove | stakeholder | User, 2026-09-03, via research iter2 SS1 |
| S19 | **The owner rejected an enforcement site for a rule this task's own next phase deletes:** *«если мы потом его введем и будем наоборот обязаны ставить actor»*. The coordinator had carried a research proposal to build one. **Implication:** before adding a control, check whether the phase plan already removes what it controls — the subtraction test applies to enforcement sites, not only to artifacts | philosophy | User, 2026-09-03 |
| S20 | **Unit tests are admissible in this repository for the project's own quality control, and inadmissible as part of the framework.** *«только здесь только для себя, это не часть фреймворка»*. **Implication:** `.tfw/scripts/` is the shipped half, so a check written for us cannot live there; and no deliverable of this task may require a receiving project to run our tests | constraint | User, 2026-09-03 |
| S21 | **The owner deliberately held CRATM while RCFR and VBSA occupied the same substrate, then asked to resume only when they should no longer interfere.** **Implication:** worktree isolation is not permission to ignore a known shared-file dependency; sequencing remains the cheaper control when one reviewed result has not yet landed | process | User, 2026-09-05 |
| S22 | **The owner is comfortable delegating a complete chain when all long-lived participants are Codex, and cites RCFR/VBSA as the working form.** **Implication:** Codex-only is the first candidate profile, and its roles are user-visible tasks/threads; nested subagents do not satisfy the same promise | stakeholder | User, 2026-09-05 |
| S23 | **The Helpdesk run made the Claude topology operationally different: the coordinator could message listed sessions but could not create all peers, and hidden subagents were not directly reachable.** **Implication:** Claude-only needs its own provider-native provisioning and routing proof, performed and checked by Claude, rather than translated Codex commands | environment | User, 2026-09-05 plus Helpdesk field trace |
| S24 | **The owner chooses no mixed-provider autonomous team for the first release.** **Implication:** A6 makes long-lived chains provider-homogeneous; mixing is a later independent value question, not an automatic combination of two profiles | stakeholder | User, 2026-09-05, confirmed and applied through A6 |
| S25 | **The owner's comfortable default is autonomy after research closes the questions; autonomy from approved HL is acceptable only for a small, familiar task with no new uncertainty.** **Implication:** `Autonomous from` remains task-local data, with post-research as the conservative default and post-HL as an explicit bounded exception | stakeholder | User, 2026-09-05 |
| S26 | **Availability, addressability, isolation, durable trace and owner-turn outcome are independent controls.** **Implication:** provider documentation may open a route candidate, but only one field run across all eight observable gates may close its profile | process | Research iter3, D1 and D7 |
| S27 | **Owner interaction is classified by cause after the declared autonomy boundary.** **Implication:** a return required by the frozen contract is not a routing defect, while a permission approval, relay, peer creation, roster repair or manual wake remains a failed autonomy turn even if the task later finishes | process | Research iter3, D10 |
| S28 | **The owner wants to initiate one named LEAD, not maintain a profile for every role.** *«остальных он создает сам и им имена уже не нужны, они созданы от него он ими управляет»*. **Implication:** identity belongs to the selected principal; child sessions carry roles, parentage and direct addresses. A permanent roster of named role principals is the wrong product model | stakeholder | Owner, Main Coordinator approval, 2026-09-06; A7 |
| S29 | **The owner explicitly retains responsibility for the entire initiated chain.** *«вся ответственность по цепочке на мне, т.к. именного именно я инициировал»*. **Implication:** mode selection after HL delegates routine coordination, not ultimate authority or accountability; shared attribution must not confer amendment rights on every child | stakeholder | Owner, Main Coordinator approval, 2026-09-06; A7 |

> S1–S27 were processed on 2026-09-05; S28–S29 await the next knowledge pass.

## 12. Amendment Log 🟢 APPEND-ONLY

| # | Date | § | Type | Proposer | Proposed change | Evidence | Cost | Alternatives considered | Verdict |
|---|------|---|------|----------|-----------------|----------|------|------------------------|---------|
| A1 | 2026-09-03 | §3.1 | `EXTEND` | research iter2 | Add `.tfw/scripts/gen_index.py` (`EVENT_KEYS`) to the change map under Phase B, so the map names every file the phase must touch | A new event carrying `writer: codex-lead` returns `['unknown keys: writer']` from the live `validate_event`; the map lists three templates and no code, and DoD 5 cannot be met without the edit | One more file inside Phase B's budget, and its test; the phase stops being template-only | Carry the writer in `via` — rejected: free-form, measured drift (`claude` → `claude-code` inside one corpus), and §7 P5 puts authority in the name. Leave the map silent — rejected: the executor meets a red gate mid-phase and must stop to ask | ❌ REJECTED — saubakirov, 2026-09-03 |
| A2 | 2026-09-03 | §5 | `EXTEND` | research iter2 | DoD 16: state that extending the closed key set of a validator that already ships is not *"adding something executable"*, and that no new script, hook, daemon, lock or behaviour-selecting config key is thereby permitted | DoD 5 requires `type: agent` to be consumed and *"named as a writer"*, which A1 shows needs the validator edit; DoD 16's word *"added"* reads as forbidding it to the person about to do it | One clause. It sharpens the NS3 boundary rather than weakening it, because it names what stays forbidden | Rely on the reading of "added" — rejected: an executor files an amendment mid-phase to ask, which is the interruption this mode exists to remove. Drop DoD 16's list — rejected: it is the guard TFW-49 died for the lack of | ❌ REJECTED — saubakirov, 2026-09-03 |
| A3 | 2026-09-03 | §4 | `EXTEND` | research iter2 | Phase B deliverable 3: the validator refuses `actor` on a **non-legacy** event while continuing to tolerate it on every legacy one | Probe row 5: a new event carrying `actor: claude-code` validates clean today, so the template's *"do not add the field to a new event"* has no enforcement site — what §7.1 forbids in its own words. The `legacy` flag that tells them apart already exists in `validate_event` | One condition and one test. It cannot reach existing events: legacy detection is by the event's own filename shape | Prose only — rejected by §7.1 and `process.md` F30: capture without an enforcement site does not change behaviour. Refuse `actor` everywhere — rejected: it would demand an edit to an immutable event, the failure the tolerance exists to prevent | ❌ REJECTED — saubakirov, 2026-09-03 |
| A4 | 2026-09-05 | §6 DoF 12; §7.1 word budget | `SUPERSEDE` | Coordinator | For a workflow already above ~1200 words before this phase, replace the impossible absolute bound with a differential one: the phase may edit it only when the final word count does not increase, the new rule has an addressed enforcement site, and EV records exact before/after counts. Documents at or below the threshold still may not cross it | The original Phase A draft already measured `handoff.md` at 1,727 words and `review.md` at 1,699; RCFR changed their topology and the reviewed VBSA candidate raises them to 2,013 and 2,102. Returning both below 1,200 would require cutting at least 813 and 902 words before adding Phase A, reopening semantics just verified by D73–D75 and VBSA | The method accepts inherited attention debt instead of repairing it here; review gains one exact count check, and Phase A cannot claim the documents satisfy F2 | Compress both below 1,200 here — rejected as a second RCFR with high semantic risk; put the rule only in `conventions.md` — rejected by DoD 2 and selective loading; defer Phase A again — rejected because no bounded compression task exists | ✅ APPROVED — saubakirov, 2026-09-05 |
| A5 | 2026-09-05 | §6 DoF 12; §7.1 word budget | `SUPERSEDE` | Owner | Supersede A4's zero-growth bound: text volume may increase when required meaning or an addressed enforcement site cannot be preserved by a shorter reference, substitution or same-document cut. The increase is the minimum materially necessary; TS states the necessity and rejected shorter form, and EV records exact before/after counts. The ~1200 threshold remains attention evidence rather than an absolute legality boundary | Owner ruling: *«увеличить объём текста разрешено, если нужно»*. A4 solved the inherited-over-limit case but would still force a semantic cut whenever the shortest correct enforcement edge has positive size | Some over-limit workflows may grow, so attention debt is explicit rather than hidden behind a passing count. The necessity statement and exact counts become reviewable obligations | Unlimited growth — rejected because it discards F2; keep A4 zero-growth — rejected by the owner as too rigid; raise the global threshold — rejected because the evidence concerns attention, not one project's validator setting | ✅ APPROVED — saubakirov, 2026-09-05 |
| A6 | 2026-09-05 | §3 Target State; §4 Phase D | `RESTRICT` | research iter3 | For the first release, every **long-lived** Role Assignment execution chain uses one provider-homogeneous profile with a field-proven native route. Mixed-provider fresh runs may be bounded helpers whose result returns to the role holder, but may not occupy long-lived role rows. A Claude profile is admitted only after the Phase D acceptance gate; Codex profile work may proceed at its current evidence level | Iteration 2 measured only fresh crossings; Helpdesk shows the relay/owner consequence of an unaddressable role; iteration 3 found no in-scope existing-session crossing. Claude channels and Codex app-server/SDK make a bridge plausible only by adding the runtime, transport, credential, liveness and security surface frozen out by §3 | The first release cannot use a mixed Codex/Claude long-lived role chain and exposes provider-specific profile text. Claude support waits for a native trial; expanding later needs new evidence and a separately authorised scope | Keep one universal mixed-capable mode — rejected because its existing-session route is absent and returns the owner or relay to routing. Declare mixing impossible forever — rejected because channels/app-server are credible bridge ingredients. Build the bridge now — rejected because it adds a runtime and security design outside this task | ✅ APPLIED — no owner verdict required |
| A7 | 2026-09-06 | §1; §3 including §3.1–3.2; §4 C–D; §5 items 5, 8–13; §6 items 1, 6, 9; §7 principles 1, 3–7, 10–11 | `SUPERSEDE` | Owner — saubakirov | One owner-selected stable named LEAD is the principal for an autonomous mandate; subordinate Coordinators, Executors, Reviewers and Researchers are directly addressable working sessions under that principal, not additional named `team/` profiles. After HL approval and its committed freeze, the Coordinator asks manual or autonomous; the owner chooses the LEAD and bounded reach, normally after research. The LEAD creates the necessary units itself inside that mandate. Separate principal attribution from unit role, address, parent and originating-proposal provenance; acting on behalf of the LEAD grants no automatic amendment authority. Keep human accountability, owner-reserved decisions, no self-ruling, separate review and worktree isolation. Do not require the full session roster before HL freeze; freeze the mandate's constraints, not ordinary bounded unit instantiation. Apply prospectively through the revised D contract, including C's routing consumers; preserve A–C historical approvals and release 2.2.0 | Owner's direct clarification in Executor task `01a076b3-d919-7471-9306-c1020b80d43c`, turn `01a07741-ad88-75f3-92c7-08391c2dc0a7`, followed by Main's explicit amendment proposal and the owner's approval in `CRATM — Main Coordinator` (`01a07050-9d35-7080-a5f6-afd14334e68d`): *«да утверждаю … потом становится LEAD именным, остальных он создает сам и им имена уже не нужны … вся ответственность по цепочке на мне»*. The frozen §3.1 instead assigned a distinct principal to each role and fixed the roster before freeze; C rule 8 equates dispatch nodes with writer handles | Revise the master visualization, acceptance and C–D semantics; one prospective D TS revision must scope the affected rule, template, workflow, adapter and assurance consumers and recompute its VALUE plan before execution. The old candidate and its review history remain evidence, not acceptance of the new model. No new sessions, profiles, runtime, artifact class, release or push is authorized by this amendment | Keep one profile per role — rejected: it models the team the owner explicitly did not request. Merely relabel all writers as LEAD — rejected: it collapses dispatch nodes and can launder self-ruling. Drop distinct Reviewer/provenance — rejected: fewer profiles do not remove role separation. Require all unit addresses at HL freeze — rejected: the owner chooses delegation after approval and the LEAD provisions bounded work | ✅ APPROVED — saubakirov, 2026-09-06 |

> **Filed 2026-09-03 by the coordinator, transcribed verbatim from `research/iter2/RES.md`.** The
> coordinator did not author these and may not rule on them (`conventions.md` §3 rule 8, and the
> delegated-authority rule that a coordinator may not apply a proposal it filed). Iteration 1 filed
> none: *"the evidence refines capability, dependency, risk and hypothesis status. It does not
> invalidate a frozen declarative claim at the HL's granularity."*

> **All three ruled together, 2026-09-03.** A1 and A2 rest on a carrier the owner is retiring:
> *«я хочу вообще избавиться от gen_index, кажется это была ошибка… просто игнорируем, или
> отключить»*. Removing it deletes the code-versus-markup tension between DoD 5 and DoD 16 outright —
> the writer field becomes template markup again, which is what §3.1 already assumed.
>
> A3 fails on a stronger ground than its carrier, and the owner named it: *«если мы потом его введем
> и будем наоборот обязаны ставить actor. ради чего ты пытаешься сейчас это делать?»* **Phase B does
> not add a field beside `actor` — it revives `actor`.** The field was never the defect; the defect
> was a filename carrying both a writer's identity and its own uniqueness, and the opaque token
> already fixed that. The only stated reason for the removal was that TFW had no principal to name,
> and Phase B creates the principal. Enforcing a prohibition that this task's own next phase deletes
> is scaffolding, and the coordinator was building an enforcement site for it. Withdrawn as an
> approach, not deferred.
>
> **What survives is a Phase B naming decision, not a rule.** Six legacy events carry `actor`, and in
> three of them it names a tool rather than a person. Reviving the name gives one field three meanings
> across an immutable corpus. Phase B decides whether to reuse `actor` — cheap and natural, ambiguous
> against six events — or to name the principal field something else, clean but leaving two words for
> one concept forever. Recorded in §10 as a blind spot.

> **A4 was filed separately on 2026-09-05.** RCFR and the reviewed VBSA candidate made the two
> Phase A workflow targets 2,013 and 2,102 words. The proposal does not claim those files satisfy F2;
> it asks whether this phase may add its required enforcement edges without increasing either file.
>
> **A4 was approved and immediately superseded by owner-initiated A5 on 2026-09-05.** The owner
> accepted the need for a differential rule but permitted minimum necessary growth. Frozen DoF 12 and
> §7.1 above apply A5; both historical proposals remain in the append-only log.
>
> **A6 was filed and applied on 2026-09-05.** `RESTRICT` narrows the first-release execution set and
> therefore applies on filing under `conventions.md` §3 rule 10; no owner verdict is required. The
> restriction changes no Phase A outcome. It guards Phase D and sends any mixed bridge to a separate
> future task only if that capability gains independent value.

> **A7 is owner-initiated and approved on 2026-09-06.** Main transcribes the real human owner's
> explicit approval under rule 9; neither its title nor its human attribution is an agent grant.
> The changes above are prospective product authority. They do not rewrite the A–C RF/REVIEWs,
> the released 2.2.0 baseline, D's earlier candidate or either D review. D's admission finding and
> the A7 model correction form one revised planning round; execution remains held until an exact
> revised TS and VALUE plan are approved. Existing role sessions are reused, with no new profiles.

---

*HL — TFW_20260902-111644_CRATM: Contextual Roles and Agent Team Mode | 2026-09-02*
