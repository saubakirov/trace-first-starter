import ast
from pathlib import Path

root = Path('C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework')
path = root / 'docs/scripts/test_integration.py'
source = path.read_text(encoding='utf-8')
lines = source.splitlines(keepends=True)
tree = ast.parse(source)
functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
effective = {node.name: node for node in functions}
output = {
    'test_static_pages_generated', 'test_knowledge_index_generated', 'test_task_pages_generated',
    'test_knowledge_topic_pages_generated', 'test_workflow_pages_generated', 'test_template_pages_generated',
    'test_frontmatter_in_generated_pages', 'test_decision_refs_resolved_in_knowledge_index',
    'test_artifact_refs_resolved_in_knowledge_topics', 'test_td_refs_resolved_in_output',
    'test_no_page_renders_its_own_frontmatter_as_body_text', 'test_index_override_used',
    'test_section_index_pages_generated',
    'test_every_recognized_task_has_an_unlisted_landing_and_nav_has_no_tasks_entry',
    'test_resolved_links_use_directory_urls',
}
aliases = {'test_phase_d_claude_release_config_history_and_prior_phases_are_byte_exact',
           'test_phase_d_added_product_lines_do_not_leak_provider_names_or_apis'}
orphan_helpers = {'_cratm_authority_consumer_errors', '_phase_d_git_paths'}
assert len(output) == 15 and len(functions) - len(effective) == 7

def body(node):
    start = min([node.lineno] + [d.lineno for d in node.decorator_list]) - 1
    return ''.join(lines[start:node.end_lineno])

integration = '''"""Generated-output checks, sharing one fresh MkDocs build per module.

Source/Git/temp-tree contracts live in test_repository_contracts.py.
Install docs/requirements.txt and pytest for this output family.
"""

import re
import subprocess
import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
'''
integration += '\n\n' + body(effective['build_site'])
for node in functions:
    if node.name in output:
        integration += '\n\n\n' + body(node)

kept = lines[303:]
for node in functions:
    if node.lineno < 304:
        continue
    if effective[node.name] is not node or node.name in aliases | orphan_helpers:
        start = min([node.lineno] + [d.lineno for d in node.decorator_list]) - 1
        for i in range(start, node.end_lineno):
            kept[i-303] = ''
pure = '''"""Source, Git-history and temporary-tree contracts with no website dependency.

These tests neither import the output-test module nor require generated site/.
Historical selectors retain the paths belonging to their pinned deliverables.
"""

import hashlib
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
'''
for node in functions:
    if node.lineno < 304 and node.name not in output | {'build_site'}:
        pure += '\n\n\n' + body(node)
pure += '\n\n\n' + ''.join(kept)
pure = pure.replace('{"migrate_board.py", "test_integration.py"}',
                    '{"migrate_board.py", Path(__file__).name}')
while '\n\n\n\n' in pure:
    pure = pure.replace('\n\n\n\n', '\n\n\n')
path.write_text(integration.rstrip()+'\n', encoding='utf-8', newline='\n')
(path.parent / 'test_repository_contracts.py').write_text(pure.rstrip()+'\n', encoding='utf-8', newline='\n')
runtime = root / 'docs/scripts/test_runtime_context.py'
text = runtime.read_text(encoding='utf-8')
for target in ('def test_no_normative_file_states_a_retired_rule', 'def test_empty_receiver_gets_exact_vendor_root_and_eleven_commands'):
    before = f'TextTarget("docs/scripts/test_integration.py", "{target}")'
    assert text.count(before) == 1
    text = text.replace(before, before.replace('test_integration.py', 'test_repository_contracts.py'))
runtime.write_text(text, encoding='utf-8', newline='\n')
print('split:',len(output),'output;',sum(n.startswith('test_') for n in effective)-len(output)-len(aliases),'pure effective tests before knowledge variants')
