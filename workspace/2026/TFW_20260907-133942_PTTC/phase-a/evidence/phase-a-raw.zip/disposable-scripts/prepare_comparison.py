import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
root=Path('C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework')
logs=base/'logs'
candidate=sys.argv[1]
baseline='099d37d21ddfada2ca72c576055f0a26029c7205'
dest=base/'comparison'
assert not dest.exists()
spent=sum(r['wall_seconds']+r.get('identity_seconds',0) for r in [json.loads(p.read_text()) for p in logs.glob('*.receipt.json')])
spent+=sum(json.loads(p.read_text())['wall_seconds'] for p in logs.glob('*.preparation.json'))
assert spent+180<3000
print('Comparison preparation fit',spent,3000-spent,'upper bound180s',flush=True)
started=time.perf_counter()
subprocess.run(['git','clone','--shared','--no-checkout','--quiet',str(root),str(dest)],check=True,timeout=90)
subprocess.run(['git','checkout','--detach','--quiet',baseline],cwd=dest,check=True,timeout=90)
paths=('docs/scripts/test_integration.py','docs/scripts/test_repository_contracts.py','docs/scripts/test_runtime_context.py','tools/README.md')
value_blobs={}
for path in paths:
    data=subprocess.check_output(['git','show',f'{candidate}:{path}'],cwd=root)
    (dest/path).write_bytes(data)
    value_blobs[path]=subprocess.check_output(['git','rev-parse',f'{candidate}:{path}'],cwd=root,text=True).strip()
baseline_paths=subprocess.check_output(['git','ls-tree','-r','--name-only','-z',baseline],cwd=root).decode().split('\0')
corpus={}
for path in baseline_paths:
    if not path or path in paths: continue
    before=(base/'baseline'/path).read_bytes()
    after=(dest/path).read_bytes()
    assert before==after,path
    corpus[path]=hashlib.sha256(before).hexdigest()
assert not (dest/'site').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=base/'baseline').strip()
row={'candidate':candidate,'baseline':baseline,'same_non_value_file_count':len(corpus),
     'non_value_files_sha256':corpus,'candidate_value_blobs':value_blobs,
     'baseline_tracked_drift_after_run':'none','candidate_composition_head':baseline,
     'site_before':'absent','wall_seconds':time.perf_counter()-started,'upper_bound_seconds':180}
(logs/'07-composition.preparation.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
print('Comparison ready:',len(corpus),'identical non-VALUE files;',row['wall_seconds'],'seconds',flush=True)
