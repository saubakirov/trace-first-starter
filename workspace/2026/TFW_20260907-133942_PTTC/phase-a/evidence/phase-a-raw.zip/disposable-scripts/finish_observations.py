"""Serialize existing observations and restore one disposable source; no test execution."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

base = Path(__file__).resolve().parent
logs = base / 'logs'
root = Path('C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework')
candidate = '8c72c4c25aa7dde461cfee23b11f90db5f09e220'
baseline = '099d37d21ddfada2ca72c576055f0a26029c7205'
started = time.perf_counter()
adverse = base / 'adverse'
page = (adverse / 'site/knowledge-index/index.html').read_bytes()
normal = (logs / '08-normal-knowledge-index.html').read_bytes()
leak = re.compile(rb'<hr />\s*<p>title: ')
assert leak.search(page) and not leak.search(normal)
(logs / '08-adverse-knowledge-index.html').write_bytes(page)
original = subprocess.check_output(['git', 'show', candidate + ':docs/scripts/gen_docs.py'], cwd=root)
source = adverse / 'docs/scripts/gen_docs.py'
changed = source.read_bytes()
assert hashlib.sha256(changed).hexdigest() == json.loads((logs/'08-adverse.preparation.json').read_text())['generator_after_sha256']
source.write_bytes(original)
assert source.read_bytes() == original
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=adverse)
events = [json.loads(line) for line in (logs/'08-adverse-output.events.jsonl').read_text().splitlines()]
build = [e for e in events if e['event']=='mkdocs_complete']
assert len(build)==1 and build[0]['exit']==0
receipt = json.loads((logs/'08-adverse-output.receipt.json').read_text())
assert receipt['exit']==1 and not receipt['timed_out']
assert '1 of 1726 pages render their frontmatter' in (logs/'08-adverse-output.pytest.txt').read_text(encoding='utf-8')
result = {'candidate':candidate, 'normal_page_sha256':hashlib.sha256(normal).hexdigest(),
          'adverse_page_sha256':hashlib.sha256(page).hexdigest(),
          'normal_leak':False,'adverse_leak':True,'offending_page':'knowledge-index/index.html',
          'fresh_build':build[0], 'pytest_exit':1, 'timed_out':False,
          'disposable_source_restored':True, 'restored_sha256':hashlib.sha256(original).hexdigest(),
          'disposable_git_status':'clean; ignored adverse site preserved',
          'wall_seconds':time.perf_counter()-started}
(logs/'08-restoration.preparation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')

classifications=[]
for path in sorted(logs.glob('*.events.jsonl')):
    events=[json.loads(line) for line in path.read_text().splitlines()]
    starts=[e for e in events if e['event']=='process_start']
    nested=[]
    for e in starts:
        a=e['argv']
        if isinstance(a,list) and (Path(a[0]).stem in ('pytest','py.test') or a[1:3]==['-m','pytest']):
            nested.append(e)
    classifications.append({'observation':path.name,'actual_child_starts':len(starts),
        'executable_counts':dict(Counter(Path(e['argv'][0]).name for e in starts)),
        'nested_pytest':nested,'mkdocs_starts':sum(e['mkdocs'] for e in starts),
        'other_python_commands':[e['argv'] for e in starts if Path(e['argv'][0]).stem=='python' and not e['mkdocs']],
        'codex_commands':[e['argv'] for e in starts if Path(e['argv'][0]).stem=='codex']})
assert not any(c['nested_pytest'] for c in classifications)
(logs/'process-classification.json').write_text(json.dumps(classifications,indent=2),encoding='utf-8')

old=subprocess.check_output(['git','show',baseline+':docs/scripts/test_integration.py'],cwd=root).decode('utf-8')
new=subprocess.check_output(['git','show',candidate+':docs/scripts/test_repository_contracts.py'],cwd=root).decode('utf-8')
trees=[ast.parse(s) for s in (old,new)]
subjects={}
for name in ('test_the_control_character_scanner_actually_detects_one','_scan_for_control_chars'):
    nodes=[next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name==name) for t in trees]
    sources=[ast.get_source_segment(s,n) for s,n in zip((old,new),nodes)]
    assert sources[0]==sources[1]
    subjects[name]={'sha256':hashlib.sha256(sources[0].encode()).hexdigest(),'baseline_lines':[nodes[0].lineno,nodes[0].end_lineno],
                    'candidate_lines':[nodes[1].lineno,nodes[1].end_lineno]}
for name in ('CONTROL_CHARS','BINARY_SUFFIXES','SHIPPED_TEXT'):
    nodes=[next((n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id==name for a in n.targets)),None) for t in trees]
    if nodes[0] is None:
        continue
    sources=[ast.get_source_segment(s,n) for s,n in zip((old,new),nodes)]
    assert sources[0]==sources[1]
    subjects[name]={'sha256':hashlib.sha256(sources[0].encode()).hexdigest()}
(logs/'paired-subject-identities.json').write_text(json.dumps(subjects,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
print('Process classifications:',len(classifications),'pytest; MkDocs',sum(c['mkdocs_starts'] for c in classifications))
