"""Compare observed inputs and relevant Git semantics at the implementation commit."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

base=Path(__file__).resolve().parent
root=Path('C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework')
logs=base/'logs'
started=time.perf_counter()
before=json.loads((logs/'06-full-suite.inputs.json').read_text())
receipt=json.loads((logs/'06-full-suite.receipt.json').read_text())
assert receipt['exit']==0 and not receipt['timed_out']
def git(*args): return subprocess.check_output(['git',*args],cwd=root)
candidate=git('rev-parse','HEAD').decode().strip()
old=before['git_context']['head']
assert candidate!=old
assert git('show','-s','--format=%P',candidate).decode().strip()==old
now_paths=set(git('ls-files','--cached','--others','--exclude-standard','-z').decode('utf-8').split('\0'))-{''}
now={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in sorted(now_paths) if (root/path).is_file()}
assert now==before['files_sha256'], 'tested input set or bytes changed at crossing'
merges=git('rev-list','--merges','--parents','HEAD').decode()
assert merges==before['git_context']['merges'], 'merge semantics changed'
merge_head=subprocess.run(['git','rev-parse','-q','--verify','MERGE_HEAD'],cwd=root,capture_output=True,text=True).stdout.strip()
assert merge_head==before['git_context']['merge_head']==''
events=[json.loads(s) for s in (logs/'06-full-suite.events.jsonl').read_text().splitlines()]
root_commands=[]
for e in events:
    if e['event']!='process_start' or not isinstance(e['argv'],list) or e['argv'][0]!='git': continue
    if Path(e['cwd']).resolve()!=root.resolve(): continue
    if e['argv'] not in root_commands: root_commands.append(e['argv'])
head_commands=[c for c in root_commands if any('HEAD' in part for part in c)]
expected=[['git','rev-parse','-q','--verify','MERGE_HEAD'],
          ['git','rev-list','--merges','--parents','HEAD'],['git','rev-parse','HEAD']]
assert all(c in expected for c in head_commands), head_commands
selected=[line.split()[0] for line in merges.splitlines() if line.split()[1:]==['cafd4947791d95907d1cd81fa10e1d9bbbe56578','2adf89918c64643f9edfde07182508decef1fde4']]
assert selected==['b977b89be0c759297dd5653040564f0169ba3e56']
value=json.loads((logs/'pre-candidate-working-blobs.json').read_text())['value_blobs']
committed={p:git('rev-parse',f'{candidate}:{p}').decode().strip() for p in value}
assert committed==value
row={'candidate':candidate,'tested_working_head':old,'same_all_source_bytes_and_population':True,
     'source_file_count':len(now),'value_blobs':committed,'merge_head':'absent before and after',
     'merge_graph_unchanged':True,'selected_historical_phase_e_candidate':selected[0],
     'actual_root_git_head_commands':head_commands,'all_unique_root_git_commands':root_commands,
     'judgment':'HEAD advances by one linear commit. With absent MERGE_HEAD the literal head value is not asserted; the same unique historical merge and its parents/ancestors drive the selected checks. All other observed actual-root Git commands use immutable revisions. Temporary repository operations are separate fixtures.',
     'environment':'same interpreter, packages and environment as the recorded pytest8 full run; no installation change at crossing',
     'wall_seconds':time.perf_counter()-started}
(logs/'candidate-crossing.preparation.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in row.items() if k!='all_unique_root_git_commands'}))
