import json
from pathlib import Path
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
root = Path('C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework')
out = base / 'logs' / '02-environment.preparation.json'
assert not out.exists()
receipts = [json.loads(p.read_text()) for p in (base/'logs').glob('*.receipt.json')]
spent = sum(r['wall_seconds'] for r in receipts)
assert spent + 240 < 3000
print('Preparation fit: spent',spent,'remaining',3000-spent,'upper bound 240s',flush=True)
started = time.perf_counter()
commands = []
code = 0
try:
    commands.append([sys.executable,'-m','venv','--system-site-packages',str(base/'venv')])
    subprocess.run(commands[-1],check=True,timeout=90)
    py = base/'venv/Scripts/python.exe'
    commands.append([str(py),'-m','pip','install','--disable-pip-version-check','--only-binary=:all:',
                     '-r',str(root/'tools/requirements.txt'),'-r',str(root/'docs/requirements.txt')])
    with (base/'logs/02-environment-install.txt').open('wb') as log:
        subprocess.run(commands[-1],stdout=log,stderr=subprocess.STDOUT,check=True,
                       timeout=max(1,240-(time.perf_counter()-started)))
except (subprocess.SubprocessError,OSError) as exc:
    code=1
    print(repr(exc),flush=True)
finally:
    row={'commands':commands,'wall_seconds':time.perf_counter()-started,'exit':code,
         'upper_bound_seconds':240,'spent_seconds_before':spent,
         'kind':'isolated environment preparation; zero pytest/build invocations'}
    out.write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
sys.exit(code)
