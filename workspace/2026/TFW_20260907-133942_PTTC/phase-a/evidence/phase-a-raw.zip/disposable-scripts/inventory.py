"""Static disposition and dependency attachment; never imports a test module."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

root=Path('C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework')
base='099d37d21ddfada2ca72c576055f0a26029c7205'
old=subprocess.check_output(['git','show',f'{base}:docs/scripts/test_integration.py'],cwd=root).decode('utf-8')
bt=ast.parse(old)
modules={name: (root/'docs/scripts'/name).read_text(encoding='utf-8')
         for name in ('test_integration.py','test_repository_contracts.py')}
trees={name:ast.parse(text) for name,text in modules.items()}
baseline_functions=[n for n in bt.body if isinstance(n,ast.FunctionDef)]
baseline_effective={n.name:n for n in baseline_functions}
current={n.name:(path,n) for path,t in trees.items() for n in t.body if isinstance(n,ast.FunctionDef)}
rows=[]
for n in baseline_functions:
    old_effective=baseline_effective[n.name] is n
    target=current.get(n.name)
    if not old_effective:
        disposition='REMOVE shadowed body; surviving effective predicate retained'
    elif target is None:
        disposition='REMOVE redundant alias' if n.name.startswith('test_') else 'REMOVE orphan of superseded bodies'
    elif ast.dump(n)!=ast.dump(target[1]):
        disposition='REWORK'
    elif target[0]=='test_integration.py':
        disposition='KEEP'
    else:
        disposition='MOVE unchanged'
    rows.append({'name':n.name,'baseline_lines':[n.lineno,n.end_lineno],
                 'baseline_effective':old_effective,'disposition':disposition,
                 'target':f'docs/scripts/{target[0]}:{target[1].lineno}' if target else None,
                 'baseline_body_sha256':hashlib.sha256(ast.get_source_segment(old,n).encode()).hexdigest(),
                 'current_body_sha256':hashlib.sha256(ast.get_source_segment(modules[target[0]],target[1]).encode()).hexdigest() if target else None})
dependencies={}
for path,t in trees.items():
    symbols={}
    for n in t.body:
        if isinstance(n,ast.FunctionDef): symbols[n.name]=n
        elif isinstance(n,ast.Assign):
            for name in n.targets:
                if isinstance(name,ast.Name): symbols[name.id]=n
        elif isinstance(n,(ast.Import,ast.ImportFrom)):
            for item in n.names: symbols[item.asname or item.name.split('.')[0]]=n
    for name,n in symbols.items():
        if not isinstance(n,ast.FunctionDef): continue
        direct=sorted({v.id for v in ast.walk(n) if isinstance(v,ast.Name)} & symbols.keys())
        closure=set(direct)
        todo=list(direct)
        while todo:
            dep=todo.pop()
            more={v.id for v in ast.walk(symbols[dep]) if isinstance(v,ast.Name)} & symbols.keys()
            new=more-closure; closure.update(new); todo.extend(new)
        dependencies[name]={'module':path,'direct_module_symbols':direct,
                            'transitive_module_symbols':sorted(closure),
                            'decorators':[ast.unparse(d) for d in n.decorator_list],
                            'local_imports':[ast.unparse(d) for d in ast.walk(n) if isinstance(d,(ast.Import,ast.ImportFrom))]}
    if path=='test_repository_contracts.py':
        assert 'build_site' not in symbols
        assert all(not isinstance(n,ast.ImportFrom) or n.module!='test_integration' for n in ast.walk(t))
        assert all(not isinstance(n,ast.Import) or all(v.name!='test_integration' for v in n.names) for n in ast.walk(t))
        assert all(not isinstance(n,ast.Constant) or n.value!='mkdocs' for n in ast.walk(t))
    assert all(isinstance(n,(ast.Expr,ast.Import,ast.ImportFrom,ast.Assign,ast.FunctionDef)) for n in t.body)
inventory={'baseline':base,'dispositions':rows,'dependencies':dependencies,
           'module_imports':{path:[ast.unparse(n) for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom))] for path,t in trees.items()},
           'import_time_effects':'stdlib/pytest/PyYAML imports, path derivation, literal/regex/dict construction, sorted literal parametrization; only output module registers build fixture',
           'helper_boundaries':'pure: source reads, Git objects/metadata, and temporary-tree edits/subprocesses; tfw_state is imported only for source-template parsing. Output landing imports tfw_state for task discovery; no generator is imported by the pure family.'}
dest=Path(__file__).resolve().parent/'logs/dependency-map.json'
dest.write_text(json.dumps(inventory,indent=2),encoding='utf-8')
print('Static disposition:',len(rows),'baseline function bodies;',len(dependencies),'current functions/helpers')
print('Effectively removed:',[r['name'] for r in rows if r['baseline_effective'] and r['target'] is None])
