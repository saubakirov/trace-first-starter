from pathlib import Path
root = Path('C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework')
p = root / 'docs/scripts/test_repository_contracts.py'
s = p.read_text(encoding='utf-8')
start = s.index('def test_phase_d_closure_visible_knowledge_uses_approval_epoch_not_product_baseline():')
end = s.index('\n\ndef ', start + 4)
old = s[start:end]
new = old.replace('    current = (PROJECT_ROOT / "KNOWLEDGE.md").read_text(encoding="utf-8")',
'''    # This claim is the historical closure identity, not today's explanation.
    # The current structural/provenance contract is checked with the Phase E group.
    closure_snapshot = _git_bytes(PHASE_E_BASELINE, "KNOWLEDGE.md").decode("utf-8")''')
new = new.replace('in current', 'in closure_snapshot').replace('current.count', 'closure_snapshot.count')
s = s[:start] + new + s[end:]
start = s.index('def test_phase_e_knowledge_keeps_exact_rtbo_and_final_cratm_decisions():')
end = s.index('\n\ndef ', start + 4)
s = s[:start] + '''PHASE_E_KNOWLEDGE_CANDIDATE = "b5a45c622c035c574d0fd5f5f7795add769be529"
PHASE_E_KNOWLEDGE_APPROVAL = "29df734a4ab12a4f4a796a0577389cef2e73bcac"
PHASE_E_KNOWLEDGE_CAPTURE = "7b4d4190c06a6ca02d55e23f90ed24214df8d2b5"


def _knowledge_row(text, key):
    rows = [line for line in text.splitlines() if line.startswith(f"| {key} |")]
    assert len(rows) == 1, f"{key}: expected one row, found {len(rows)}"
    return rows[0]


def _knowledge_links(row):
    return set(re.findall(r"\\[[^\\]]+\\]\\(([^)]+)\\)", row))


def _assert_phase_e_knowledge_contract(text, *, post_k2=True):
    """Check selected identity, lineage and provenance, never semantic approval.

    Explanation, attribution and successor legitimacy need independent reading against
    the cited owner acts. Passing this helper does not validate arbitrary prose. Exact
    row equality belongs only to the immutable historical regression below.
    """
    sources = {"D82": PHASE_E_BASELINE, "D83": PHASE_D_FINAL}
    if post_k2:
        sources["D84"] = PHASE_E_KNOWLEDGE_CAPTURE
    else:
        assert not any(line.startswith("| D84 |") for line in text.splitlines())
    for decision, ref in sources.items():
        row = _knowledge_row(text, decision)
        historical = _knowledge_row(_git_bytes(ref, "KNOWLEDGE.md").decode("utf-8"), decision)
        required = _knowledge_links(historical)
        assert required and required <= _knowledge_links(row), f"{decision}: missing or wrong source"
        for path in required:
            assert _git_bytes(ref, path), f"{decision}: empty immutable source {ref}:{path}"

    prefix = "| TFW_20260902-111644_CRATM/"
    artifacts = [line for line in text.splitlines() if line.startswith(prefix)]
    assert len(artifacts) == 1, "CRATM: missing or duplicate selected artifact row"
    artifact = artifacts[0]
    lineage = re.match(r"\\| TFW_20260902-111644_CRATM/B–([D-Z]) \\|", artifact)
    assert lineage, "CRATM: incompatible phase lineage"
    assert (lineage[1] >= "E") if post_k2 else (lineage[1] == "D"), "CRATM: phase/capture mismatch"
    ref = PHASE_E_KNOWLEDGE_CAPTURE if post_k2 else PHASE_E_KNOWLEDGE_CANDIDATE
    historical = _git_bytes(ref, "KNOWLEDGE.md").decode("utf-8")
    old_artifact = _knowledge_row(historical, "TFW_20260902-111644_CRATM/B–" + ("E" if post_k2 else "D"))
    required = _knowledge_links(old_artifact)
    assert required and required <= _knowledge_links(artifact), "CRATM: missing or wrong phase source"
    for path in required:
        assert _git_bytes(ref, path), f"CRATM: empty immutable source {ref}:{path}"
    if post_k2:
        commits = set(re.findall(r"\\b[0-9a-f]{40}\\b", artifact))
        assert {PHASE_D_CANDIDATE, PHASE_E_KNOWLEDGE_CANDIDATE, PHASE_E_KNOWLEDGE_APPROVAL} <= commits, \\
            "CRATM: missing or wrong immutable result/approval reference"
        for commit in commits:
            assert subprocess.run(["git", "cat-file", "-e", f"{commit}^{{commit}}"],
                                  cwd=PROJECT_ROOT, capture_output=True).returncode == 0, commit


def _phase_e_knowledge_examples(current):
    """Bounded disposable examples; none writes knowledge or creates an owner act."""
    explanations = {
        "D82": "Ordinary Full follows its complete semantic workflow contract without a shipped executable, "
               "Python/PyYAML, a tracked portfolio cache or a prose-length validity bound. Optional upstream "
               "parsing, read-only diagnostics and pinned migration remain separate. Hidden task landings "
               "preserve direct reachability without a Tasks catalogue or live aggregate; Assisted and history stay protected.",
        "D83": "The owner chooses one stable LEAD principal only after the HL is approved, frozen and committed; "
               "otherwise CL continues. Its protected mandate coordinates distinct addressable working units. "
               "Append-only unit rows and a complete roster provide no activation authority. Each continuation "
               "resolves its own state, gate, bounded dispatch and return. Only that principal's exact root "
               "Coordinator in Plan or Resume uses the handle-bearing LEAD title; children retain role titles. "
               "Rendered-title collision, exact readback and unclaimed failure rules, plus the finite "
               "revision-3/revision-4 continuation and phase-journal grammar, remain applicable.",
        "D84": "An optional journal writer identifies the resolved durable acting principal. Unresolved "
               "attribution is omitted. Provider, default handle, session, role or working-unit identity "
               "cannot supply a principal, proposal origin or authority; Handoff, Research and Review "
               "and their installed copies follow this same rule.",
    }
    wording = current
    for decision, explanation in explanations.items():
        old = _knowledge_row(wording, decision)
        references = old.rstrip(" |").rsplit(" | ", 1)[1]
        replacement = f"| {decision} | {explanation} | The same protected decision, explained differently. | {references} |"
        wording = wording.replace(old, replacement, 1)

    # Synthetic rendering of the existing initial-to-final Phase D owner transition.
    # A7 and the ruled revision chain are real; this fixture grants no new approval.
    predecessor = PHASE_D_PREFIX + "TS__phase-d__team_mode_and_role_assignment.md"
    successor = PHASE_D_PREFIX + "TS__phase-d__team_mode_and_role_assignment__rev3.md"
    ruling = PHASE_D_PREFIX + "REVIEW__phase-d__team_mode_and_role_assignment__rev2.md"
    transition = (" Synthetic successor illustration: the historical initial Phase D AT capture "
                  f"([predecessor]({predecessor})) is superseded by the already approved final "
                  f"principal/unit model ([successor]({successor})); owner A7 freeze `{PHASE_D_A7_FREEZE}`, "
                  f"[recorded ruling]({ruling}), reviewed TS source `73d711808a6b6fe1b1e15589e7c3c9d479a9e8a5`. "
                  "This is an example of an existing owner act, not a new decision or live knowledge edit.")
    row = _knowledge_row(wording, "D83")
    successor_text = wording.replace(row, row[:-1] + transition + "|", 1)
    successor_text += "\\n| D999 | Synthetic unrelated later decision row; not a live owner act. | Additional rows do not invalidate earlier provenance. | Fixture only. |\\n"
    distortion = wording.replace("identifies the resolved durable acting principal",
                                 "identifies a working unit whose title grants amendment authority", 1)
    return {"wording": wording, "approved-successor-synthetic": successor_text,
            "authority-distortion-for-independent-review": distortion}


def test_phase_e_knowledge_keeps_exact_rtbo_and_final_cratm_decisions():
    # Finite historical identity: the two pre-K2 inputs and the actual K2 capture.
    anchors = {"D82": PHASE_E_BASELINE, "D83": PHASE_D_FINAL, "D84": PHASE_E_KNOWLEDGE_CAPTURE}
    for ref, post in ((PHASE_E_KNOWLEDGE_CANDIDATE, False),
                      (PHASE_E_KNOWLEDGE_APPROVAL, False), (PHASE_E_KNOWLEDGE_CAPTURE, True)):
        historical = _git_bytes(ref, "KNOWLEDGE.md").decode("utf-8")
        for decision in ("D82", "D83", "D84") if post else ("D82", "D83"):
            expected = _git_bytes(anchors[decision], "KNOWLEDGE.md").decode("utf-8")
            assert _knowledge_row(historical, decision) == _knowledge_row(expected, decision)
        _assert_phase_e_knowledge_contract(historical, post_k2=post)
    _assert_phase_e_knowledge_contract((PROJECT_ROOT / "KNOWLEDGE.md").read_text(encoding="utf-8"))


def test_phase_e_knowledge_accepts_explanations_and_rejects_structural_damage():
    current = (PROJECT_ROOT / "KNOWLEDGE.md").read_text(encoding="utf-8")
    examples = _phase_e_knowledge_examples(current)
    for name in ("wording", "approved-successor-synthetic"):
        assert examples[name] != current
        _assert_phase_e_knowledge_contract(examples[name])
    # The separate authority-distortion example is intentionally for independent
    # semantic judgment. This structural helper cannot approve or reject its meaning.
    for decision in ("D82", "D83", "D84"):
        row = _knowledge_row(current, decision)
        for damaged in (current.replace(row, "", 1), current.replace(row, row + "\\n" + row, 1)):
            with pytest.raises(AssertionError, match="expected one row"):
                _assert_phase_e_knowledge_contract(damaged)
    artifact = _knowledge_row(current, "TFW_20260902-111644_CRATM/B–E")
    damages = (
        (current.replace(artifact, "", 1), "missing or duplicate"),
        (current.replace(artifact, artifact + "\\n" + artifact, 1), "missing or duplicate"),
        (current.replace("TFW_20260902-111644_CRATM/B–E", "TFW_20260902-111644_CRATM/B–D", 1), "phase/capture mismatch"),
        (current.replace(PHASE_E_KNOWLEDGE_CANDIDATE, "0" * 40, 1), "immutable result/approval"),
        (current.replace(PHASE_E_KNOWLEDGE_APPROVAL, PHASE_E_KNOWLEDGE_CANDIDATE, 1), "immutable result/approval"),
        (current.replace(PHASE_D_PREFIX + "TS__phase-d__team_mode_and_role_assignment__rev3.md",
                         PHASE_D_PREFIX + "TS__phase-d__team_mode_and_role_assignment__rev2.md", 1), "missing or wrong source"),
    )
    for damaged, reason in damages:
        assert damaged != current
        with pytest.raises(AssertionError, match=reason):
            _assert_phase_e_knowledge_contract(damaged)
''' + s[end:]
p.write_text(s, encoding='utf-8', newline='\n')
print('knowledge predicates reworked without live knowledge changes')
