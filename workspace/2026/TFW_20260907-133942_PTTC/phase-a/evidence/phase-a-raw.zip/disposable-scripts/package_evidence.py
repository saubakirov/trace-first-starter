"""Package measured receipts; no test/build invocation or product changes."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile

base=Path(__file__).resolve().parent
logs=base/'logs'
root=Path('C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework')
phase=root/'workspace/2026/TFW_20260907-133942_PTTC/phase-a'
out=phase/'evidence'
out.mkdir(exist_ok=True)
candidate='8c72c4c25aa7dde461cfee23b11f90db5f09e220'
baseline='099d37d21ddfada2ca72c576055f0a26029c7205'
receipts=[(p.name,json.loads(p.read_text())) for p in sorted(logs.glob('*.receipt.json'))]
preps=[(p.name,json.loads(p.read_text())) for p in sorted(logs.glob('*.preparation.json'))]
test_seconds=sum(r['wall_seconds'] for _,r in receipts)
identity_seconds=sum(r.get('identity_seconds',0) for _,r in receipts)
prep_measured=sum(r['wall_seconds'] for _,r in preps if not r.get('bound_not_claimed_as_measured')) + 0.004804299998795614
early_bound=120.0
late_bound=180.0
total=test_seconds+identity_seconds+prep_measured+early_bound+late_bound
assert total<3000 and len(receipts)==8 and sum(r['mkdocs_starts'] for _,r in receipts)==3
budget={'pytest_processes':8,'nested_pytest_processes':0,'mkdocs_starts':3,
        'measured_pytest_process_seconds':test_seconds,'measured_input_capture_seconds':identity_seconds,
        'measured_preparation_seconds':prep_measured,'earlier_preparation_upper_bound_seconds':early_bound,
        'later_short_preparation_packaging_and_closeout_upper_bound_seconds':late_bound,
        'executor_accounted_upper_bound_seconds':total,'executor_allocation_seconds':3000,
        'executor_time_headroom_seconds':3000-total,'coordinator_separate_measured_read_seconds':0.154197,
        'common_accounted_upper_bound_seconds':total+0.154197,
        'common_unspent_seconds_at_executor_return':3600-total-0.154197,
        'common_remaining_pytest_processes':2,'common_remaining_mkdocs_starts':1,
        'note':'180s is a conservative prospective allowance for later short source/log reads, serialization, wrapper overhead, archive/trace preparation and commit checks through Executor closeout, excluding separately measured entries. Neither 120s nor 180s is a measured duration. MkDocs child time is included in pytest process time, never added twice. Native work, message latency, tokens and money are unknown, not zero.'}
(logs/'budget-summary.json').write_text(json.dumps(budget,indent=2),encoding='utf-8')
mapping=json.loads((logs/'dependency-map.json').read_text())
lines=['# Complete baseline function disposition','',f'Baseline `{baseline}` → Candidate `{candidate}`. Static identity evidence is combined with observations 02/03/04/06; it is not execution proof by itself.','',
       '| Baseline function and lines | Disposition | Candidate target |','|---|---|---|']
aliases={'test_phase_d_claude_release_config_history_and_prior_phases_are_byte_exact':'test_phase_d_approval_epoch_protects_history_inputs_and_cumulative_prefixes',
         'test_phase_d_added_product_lines_do_not_leak_provider_names_or_apis':'test_phase_d_added_product_provider_terms_are_confined_to_adapter_and_named_exception'}
for r in mapping['dispositions']:
    target=r['target'] or (aliases.get(r['name']) if r['name'] in aliases else 'No live caller; helper used only by superseded bodies')
    lines.append(f"| `{r['name']}` {r['baseline_lines'][0]}–{r['baseline_lines'][1]} | {r['disposition']} | `{target}` |")
lines += ['','Seven earlier definitions were overwritten at module import in the baseline. Their latest effective forms survive unchanged, or (for the two thin aliases) their already-collected substantive targets survive. No protective meaning is inferred from a lower collected count.',
          '', 'The board guard REWORK only follows its actual containing filename for self-exclusion; migrate_board.py remains the narrow migration exclusion. The old integration filename is no longer excluded. The two other existing REWORK functions remove live whole-row locking while retaining finite historical claims at their immutable epochs. New knowledge helpers and one bounded case test supply structural cases and explicit semantic-review inputs.',
          '', 'Imports and direct/transitive module symbols, decorators and local imports for all 150 current functions/helpers are in dependency-map.json. Pure imports are ordinary library modules; tfw_state is imported locally for source-template parsing. Output consumers and build_site stay together. Literal assignments/regex construction/parametrization do not start a build. Static inspection is supported by zero observed MkDocs starts with absent/stale site and fresh-build ordinary output runs.']
(logs/'dependency-dispositions.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

verification=[
 'PTTC Phase A — actual command and evidence ledger',
 f'Baseline: {baseline}',f'Candidate: {candidate}',
 'Tested working HEAD for final collection/full run: 62cb3f58a56c2dc8e69fd5f67366264f10725c6d',
 'Producer Executor: 01a081fd-96cb-7862-9c15-33d803c1aade; parent Coordinator: 01a08196-9e95-7ef3-8a4f-a5d6b4a424a9',
 'Branch codex/pttc-phase-a-exec; worktree C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework',
 '', 'Eight ordinary pytest invocations in actual execution order follow. Each start receipt records the prospective allowance and remaining budget; input capture is additional measured time (01 predates the manifest observer). Allocation increased from 7 to 8 before observation03 by dispatch bc81, immutable producer 19650f7a61ddc9b1e9b604b258589f6fbd0d40a1; imported unchanged at 62cb3f58a56c2dc8e69fd5f67366264f10725c6d.',
 'Transparent disposable observer records successful child starts and pytest reports; scripts are attached. No selection or assertion is supplied by it. Full stdout/stderr are preserved, including pre-existing MkDocs warnings. No timeout occurred.',
 'Environment variables set for every observation: PYTHONUTF8=1, PYTHONDONTWRITEBYTECODE=1, PYTEST_PLUGINS=pttc_observer, PYTHONPATH=E:/TEMP/pttc-phase-a-b9b5/observer, PTTC_OBSERVATION=the named log prefix. Complete environment is represented by SHA256 4835a00e0ec9d5b43a89a65f669ca134cc7a7247cdccf8488e40e6f3c66baa1a excluding only the log destination; secrets are not exported.',
 'Windows 11 10.0.26200; Python 3.13.5; MkDocs 1.6.1; mkdocs-material 9.7.6; PyYAML 6.0.3. Controlled pair01/07 uses D:/python/Python313/python.exe with pytest9.0.2. Regular02–06/08 uses E:/TEMP/pttc-phase-a-b9b5/venv/Scripts/python.exe with pytest8.4.2 after isolated requirements installation. Global9 is outside tools/requirements.txt >=8,<9: local comparison limitation, not supported-environment gate evidence. No baseline repeat or global install change.',
 '']
for name,r in receipts:
    prefix=name.removesuffix('.receipt.json')
    events=[json.loads(line) for line in (logs/(prefix+'.events.jsonl')).read_text().splitlines()]
    verification += [prefix, 'command argv: '+json.dumps(r['command']), 'cwd: '+r['cwd'],
        f"pytest process wall={r['wall_seconds']:.9f}s; input capture={r.get('identity_seconds',0):.9f}s; exit={r['exit']}; timeout={r['timed_out']}; MkDocs starts={r['mkdocs_starts']}",
        f"site before={r['site_exists_before']}; site after={r['site_exists_after']}",
        'build receipts: '+json.dumps([e for e in events if e['event']=='mkdocs_complete']),
        'setup/call/teardown duration sums: '+json.dumps({w:sum(e['duration'] for e in events if e['event']=='test_report' and e['when']==w) for w in ('setup','call','teardown')}),
        'raw stdout/stderr: logs/'+prefix+'.pytest.txt',
        (logs/(prefix+'.pytest.txt')).read_text(encoding='utf-8').splitlines()[-1], '']
verification += [
 '02 failed with 121 passed / 3 failed, caused by two implementation selector errors: a pre-final knowledge snapshot and CRATM/A instead of the protected CRATM/B row. Failed source and stdout are retained. No claim is based on greenwashing that attempt. Correction03 selected all three transitive dependent tests by changed-function closure (not merely the count of failures), 3 passed with site absent. The other 121 results are applicable to unchanged dependencies. Candidate pure stale04 then passed all124 in one invocation and preserved every one of1778 pre-existing site files. Source hashes and correction diff bind the absent composite. Full06 independently includes them.',
 'Final collection05: 549 tests collected in0.98s. Full06: 548 passed,1 skipped in557.84s. Exact skip: tools/tests/test_migrate_board_2_0.py::test_repository_accounting_balances, Candidate source lines550–554, when board has no rows: "board already removed — accounting is frozen in BOARD-SNAPSHOT.md". Reason recovered from the existing event/source, with no -rs rerun.',
 'Raw actual argv classification found zero nested pytest invocations. Full06 has6810 direct child starts:6788 git,18 python (one MkDocs plus CLI migration/doctor cases),4 codex --version reads. migrate_board.py subprocesses are git only; tfw_doctor.py starts no subprocess. Temp directories named pytest-of-c0rpa are inputs, not extra processes. codex --version does not create an agent/task. process-classification.json retains commands for all8 runs.',
 'Candidate crossing: tests ran on final working bytes at62cb3f5, then the canonical handoff Candidate commit8c72c4c was created. No claim that its SHA existed before execution. candidate-crossing.preparation.json confirms every one of1984 source files and membership unchanged, exact four VALUE blobs, linear parent, MERGE_HEAD absent before/after, and identical full merge graph. The one historical PhaseE candidate remains b977b89be0c759297dd5653040564f0169ba3e56 with unchanged parents. The literal HEAD check is not asserted without MERGE_HEAD; all other actual-root observed Git inputs are immutable. Temporary Git fixtures are separate. Later EV/RF/status TRACE is not included in that full-run source manifest, and has no blanket full-suite PASS claim.',
 'Controlled pair: comparison07 starts at detached Baseline and overlays exactly the four Candidate VALUE blobs. All1968 non-VALUE actual source files match baseline; baseline tracked drift after01 was none. Baseline01 had no pre-run source manifest; its detached ref and later clean tracked audit/composition are the available identity evidence. Subject helper/constants/test bodies are exact in paired-subject-identities.json; fixture data are inside unchanged test body. Both site preconditions absent, interpreter/packages/env/parameters unchanged apart from necessary moved node path and isolated temporary directory. This controlled composition is distinct from actual Candidate full06.',
 f"Local pair process difference: {receipts[0][1]['wall_seconds']-receipts[6][1]['wall_seconds']:.9f}s lower; {receipts[0][1]['wall_seconds']:.9f}s → {receipts[6][1]['wall_seconds']:.9f}s; MkDocs1 → 0. One local pair with observer overhead; no repeated sampling, universal speedup, or knowledge-oracle timing claim.",
 'Adverse08 begins with1791 files of valid output copied from06. A prefix before the KNOWLEDGE.md frontmatter in a disposable generator makes that header body text. The ordinary module fixture starts one successful fresh MkDocs build; unchanged existing leak test fails for1 of1726 pages, knowledge-index/index.html. Source variation is restored byte-for-byte to Candidate only in the disposable root after evidence capture; original product generator was never edited. Normal/adverse HTML and hashes are attached. Expected adverse exit1 is evidence of detection, not a failed Candidate build.',
 '', 'Preparation ledger (wall seconds; child build time is included in pytest, never added twice):']
for name,r in preps:
    verification.append(f"{name}: {r['wall_seconds']:.9f}; "+('120s is a conservative bound plus0.0048043s measured copy, not all measured' if r.get('bound_not_claimed_as_measured') else 'measured'))
verification += ['', 'Final budget summary:', json.dumps(budget,indent=2),
 'The 180s later-command allowance is a conservative bound for short preparation/packaging/closeout command time not individually instrumented; it is not elapsed agent labor. Any further verification requires Coordinator routing. Executor has0 pytest/0 MkDocs allocation left; common remaining2 pytest/1 MkDocs contains one Reviewer selection and one contingency, not instructions to spend them.',
 'Native effort: one identical AC4 batch per already existing Executor/Reviewer, direct Coordinator routing and independent answers before unblinding; Reviewer actual turn01a08212-563b-73f1-9658-715b35aafce7. Formal semantic/Candidate review not yet observed. Coordinator separately measured0.154197s source/guide reads and is included only in the common total. Native wall duration, agent labor, tokens and money are unknown.',
 '', 'NUL-safe accounting argv and actual rows:',(logs/'accounting.preparation.json').read_text(),
 '', 'Raw attachment: phase-a-raw.zip; logs are original bytes except new derived indexes. ZIP has an internal SHA256 index for every member except its own index. Scripts are disposable observation/serialization tools, not a shipped runner.']
(out/'phase-a-verification.txt').write_text('\n'.join(verification)+'\n',encoding='utf-8')

v=['# Phase A input variants and native choices','',f'Candidate `{candidate}`. All examples are disposable; live KNOWLEDGE.md and product gen_docs.py are unchanged. Exact input bytes and diffs below are in `phase-a-raw.zip/logs/`.','',
   '## Knowledge cases','',
   '`knowledge-wording.md` and its `.diff` contain the exact D82/D83/D84 explanation rewrite generated by the Candidate helper. `knowledge-approved-successor-synthetic.md` adds the explicit initial→final Phase D relation and D999 example row. They passed the structural contract in observations03/04/06. The synthetic transition illustrates an already recorded owner act; it grants no new permission or live decision.','',
   '`knowledge-authority-distortion-for-independent-review.md` changes D84 from the durable acting principal to a working unit whose title grants amendment authority. This exact input is supplied to independent semantic review, not put through a phrase validator. The structural helper cannot approve/reject its meaning. Its final rejection, and source-grounded acceptance of harmless wording/successor, are DEFERRED to the assigned Reviewer.','',
   'Structural adverse inputs are defined in Candidate `test_phase_e_knowledge_accepts_explanations_and_rejects_structural_damage`: remove and duplicate each D82/D83/D84 row; remove/duplicate selected CRATM artifact row; replace B–E with B–D; replace real knowledge Candidate SHA with forty zeroes; replace approval SHA with Candidate SHA; replace required rev3 TS source with rev2. Existing `pytest.raises` observations verify the consequences in03/04/06. No source variant was written to live knowledge. Exact positive/deliberate-semantic-negative inputs and their SHA256 values are in `knowledge-variants.preparation.json`.','',
   'Immutable semantic reference attachments: initial Phase D TS at `b755de9128f2b0442615a4ca8b787761f937bbcd`; A7 frozen master at `2386bfb0994f6e0a1aed7b734e345cdb2a540ae1`; rev3 TS at reviewed source `73d711808a6b6fe1b1e15589e7c3c9d479a9e8a5`; recorded rev2 REVIEW at `18d54060da8796ddca7d648365cbfeb18f60690b`. Raw filenames are `initial-phase-d-ts.md`, `a7-frozen-master.md`, `final-ts-reviewed-source.md`, `recorded-phase-d-ruling.md`. Historical K2 anchors remain b5a45c622c035c574d0fd5f5f7795add769be529,29df734a4ab12a4f4a796a0577389cef2e73bcac,7b4d4190c06a6ca02d55e23f90ed24214df8d2b5.','',
   '## Real rendering defect','', 'Exact generator variation:', '', '```diff', (logs/'08-generator-variation.diff').read_text().rstrip(), '```','',
   '`08-normal-knowledge-index.html` came from the passing full suite and was copied unchanged into the adverse stale site. `08-adverse-knowledge-index.html` came from the successful fresh adverse build. `08-restoration.preparation.json` binds both hashes, actual successful build, existing-test failure and byte-exact disposable generator restoration. The ordinary leak test reports exactly one offender. No assertion or expected value was altered.','',
   '## AC4 native exercise','', 'Guide blob `2fdf930de8d974d47961b7fbd0708afe51520dd5` was identical for both native holders and remained the Candidate README blob. Direct addresses: Executor `01a081fd-96cb-7862-9c15-33d803c1aade`, Reviewer `01a081fd-9b5b-7061-9c98-7528ed698b07`, routing parent Coordinator `01a08196-9e95-7ef3-8a4f-a5d6b4a424a9`. Reviewer response turn `01a08212-563b-73f1-9658-715b35aafce7`. Coordinator confirmed both independent answers before lifting blinding; only then were Reviewer choices read and attached.','',
   'Exact raw batch and verbatim decisions are in `ac4-raw-batch.txt`, `ac4-executor-response.txt`, `ac4-reviewer-response.txt`. The stipulated E-S/E-K/E-F records are case data, not actual executions in this task. No case mutation/test/build was performed.','',
   '| Case | Observed Executor choice | Observed independent Reviewer choice / challenge |','|---|---|---|',
   '| A: benign TODO in RES | Preserve controlled-fixture E-S; reject blanket E-F; inspect changed corpus, scan if required; output evidence conditional on rendered claim | Same affected-claim distinction, explicitly requires inspecting generator membership; the batch does not establish every output dependency |',
   '| B: D84 rationale only | Old E-K does not accept new bytes; affected knowledge test plus independent cited-source reading; E-S stays | Selects broader pure module, also requires cited-source semantic judgment; supplied prose appears faithful but cited contents and output claim are missing in this batch |',
   '| C: BACKSPACE expectation changed to ESCAPE | Reject affected E-S reuse; return unsupported oracle for correction/authority; retain unrelated claims | Independently rejects changed-oracle reuse and return-to-green fixture manipulation; route to same Executor, then targeted check after resolving purpose |','',
   'The bounded observed result is claim-specific reuse and rejection of unsupported oracle acceptance, not identical command selection: B differed in selection breadth. Both preserve configured gates. This is one batch per existing native holder; it establishes no provider reliability/G8, universal behavioral result, final semantic knowledge acceptance, Phase B closure or publication.']
(out/'phase-a-input-variants.md').write_text('\n'.join(v)+'\n',encoding='utf-8')

members={}
# Serialize the exact negative inputs already exercised, without invoking pytest or assertions.
current=(root/'KNOWLEDGE.md').read_text(encoding='utf-8')
def selected_row(key):
    return next(line for line in current.splitlines() if line.startswith('| '+key+' |'))
negative={}
for decision in ('D82','D83','D84'):
    row=selected_row(decision)
    negative['missing-'+decision]=current.replace(row,'',1)
    negative['duplicate-'+decision]=current.replace(row,row+'\n'+row,1)
artifact=selected_row('TFW_20260902-111644_CRATM/B–E')
prefix='workspace/2026/TFW_20260902-111644_CRATM/phase-d/'
negative.update({
    'missing-artifact':current.replace(artifact,'',1),
    'duplicate-artifact':current.replace(artifact,artifact+'\n'+artifact,1),
    'wrong-lineage':current.replace('TFW_20260902-111644_CRATM/B–E','TFW_20260902-111644_CRATM/B–D',1),
    'fabricated-candidate':current.replace('b5a45c622c035c574d0fd5f5f7795add769be529','0'*40,1),
    'wrong-approval':current.replace('29df734a4ab12a4f4a796a0577389cef2e73bcac','b5a45c622c035c574d0fd5f5f7795add769be529',1),
    'wrong-ts-source':current.replace(prefix+'TS__phase-d__team_mode_and_role_assignment__rev3.md',prefix+'TS__phase-d__team_mode_and_role_assignment__rev2.md',1),
})
negative_index={'candidate':candidate,'current_input_sha256':hashlib.sha256(current.encode()).hexdigest(),
                'source':'exact deterministic replacements from the Candidate test; serialized after already recorded observations, no extra execution',
                'files':{}}
for name,text in negative.items():
    file='knowledge-negative-'+name+'.md'
    (logs/file).write_text(text,encoding='utf-8',newline='\n')
    negative_index['files'][file]=hashlib.sha256(text.encode()).hexdigest()
(logs/'knowledge-negative-inputs.json').write_text(json.dumps(negative_index,indent=2),encoding='utf-8')
for p in sorted(logs.iterdir()):
    if p.is_file(): members['logs/'+p.name]=p.read_bytes()
for p in sorted(base.glob('*.py')):
    members['disposable-scripts/'+p.name]=p.read_bytes()
members['disposable-scripts/observer/pttc_observer.py']=(base/'observer/pttc_observer.py').read_bytes()
index={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in members.items()}
members['SHA256-INDEX.json']=(json.dumps(index,indent=2)+'\n').encode()
zpath=out/'phase-a-raw.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in members.items(): z.writestr(name,data)
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for name,item in index.items(): assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
print(json.dumps(budget,indent=2))
print('Archive',len(members),'members;',zpath.stat().st_size,'bytes; SHA256',hashlib.sha256(zpath.read_bytes()).hexdigest())
