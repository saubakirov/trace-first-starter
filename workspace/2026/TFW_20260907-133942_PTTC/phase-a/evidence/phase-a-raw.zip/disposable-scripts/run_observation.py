"""One bounded ordinary pytest command with raw timing and subprocess receipts."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

p = argparse.ArgumentParser()
p.add_argument('label')
p.add_argument('root', type=Path)
p.add_argument('limit', type=int)
p.add_argument('build_allowance', type=int)
p.add_argument('pytest_args', nargs=argparse.REMAINDER)
a = p.parse_args()
base = Path(__file__).resolve().parent
logs = base / 'logs'
logs.mkdir(exist_ok=True)
out = logs / a.label
assert not out.with_suffix('.receipt.json').exists(), 'refuse overwriting observation'
receipts = [json.loads(path.read_text()) for path in logs.glob('*.receipt.json')]
preparations = [json.loads(path.read_text()) for path in logs.glob('*.preparation.json')]
spent = sum(r['wall_seconds'] + r.get('identity_seconds', 0) for r in receipts) + sum(r['wall_seconds'] for r in preparations)
builds = sum(r['mkdocs_starts'] for r in receipts)
assert len(receipts) + 1 <= 8 and builds + a.build_allowance <= 3
assert spent + a.limit + 60 <= 3000  # include an input-capture upper bound
env = os.environ.copy()
env['PYTHONUTF8'] = '1'
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['PYTEST_PLUGINS'] = 'pttc_observer'
env['PYTHONPATH'] = str(base / 'observer')
env['PTTC_OBSERVATION'] = str(out)
command = [sys.executable, '-m', 'pytest', *a.pytest_args]
identity_started = time.perf_counter()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=a.root)
paths = set(git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode('utf-8').split('\0')) - {''}
inputs = {path: hashlib.sha256((a.root/path).read_bytes()).hexdigest()
          for path in sorted(paths) if (a.root/path).is_file()}
git_context = {'head': git('rev-parse', 'HEAD').decode().strip(),
               'status': git('status', '--porcelain=v1', '--untracked-files=all').decode('utf-8'),
               'merges': git('rev-list', '--merges', '--parents', 'HEAD').decode(),
               'merge_head': subprocess.run(['git','rev-parse','-q','--verify','MERGE_HEAD'],cwd=a.root,capture_output=True,text=True).stdout.strip()}
out.with_suffix('.inputs.json').write_text(json.dumps({'files_sha256': inputs, 'git_context': git_context}, indent=2), encoding='utf-8')
identity_seconds = time.perf_counter()-identity_started
start_row = {'command': command, 'cwd': str(a.root.resolve()), 'limit_seconds': a.limit,
             'spent': {'pytest': len(receipts), 'mkdocs': builds, 'seconds': spent},
             'remaining_before': {'pytest': 8-len(receipts), 'mkdocs': 3-builds, 'seconds': 3000-spent},
             'forecast': {'pytest': 1, 'mkdocs': a.build_allowance, 'seconds_upper_bound': a.limit},
             'interpreter': sys.executable, 'python': sys.version, 'platform': platform.platform(),
             'packages': {n: importlib.metadata.version(n) for n in ('pytest', 'mkdocs', 'mkdocs-material', 'PyYAML')},
             'environment_sha256_excluding_log_destination': hashlib.sha256(json.dumps({k:v for k,v in env.items() if k != 'PTTC_OBSERVATION'}, sort_keys=True).encode()).hexdigest(),
             'site_exists_before': (a.root / 'site').exists(), 'git_context': git_context,
             'inputs_manifest': out.with_suffix('.inputs.json').name,
             'identity_seconds': identity_seconds}
out.with_suffix('.start.json').write_text(json.dumps(start_row, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in start_row.items() if k != 'git_context'}), flush=True)
started = time.perf_counter()
with out.with_suffix('.pytest.txt').open('wb') as stream:
    proc = subprocess.Popen(command, cwd=a.root, env=env, stdout=stream, stderr=subprocess.STDOUT)
    try:
        code = proc.wait(timeout=a.limit)
        timed_out = False
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
        code = proc.wait()
        timed_out = True
elapsed = time.perf_counter() - started
events_path = out.with_suffix('.events.jsonl')
events = [json.loads(line) for line in events_path.read_text().splitlines()] if events_path.exists() else []
receipt = {**start_row, 'exit': code, 'timed_out': timed_out, 'wall_seconds': elapsed,
           'mkdocs_starts': sum(e.get('mkdocs', False) for e in events if e['event']=='process_start'),
           'process_starts_observed': sum(e['event']=='process_start' for e in events),
           'site_exists_after': (a.root / 'site').exists()}
out.with_suffix('.receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k != 'git_context'}), flush=True)
print(out.with_suffix('.pytest.txt').read_text(encoding='utf-8', errors='replace')[-6000:], flush=True)
sys.exit(code if not timed_out else 124)
