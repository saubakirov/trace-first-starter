import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
root=Path('C:/Users/c0rpa/.codex/worktrees/b9b5/steps-framework')
logs=base/'logs'
candidate=sys.argv[1]
dest=base/'adverse'
assert not dest.exists()
spent=sum(r['wall_seconds']+r.get('identity_seconds',0) for r in [json.loads(p.read_text()) for p in logs.glob('*.receipt.json')])
spent+=sum(json.loads(p.read_text())['wall_seconds'] for p in logs.glob('*.preparation.json'))
assert spent+240<3000
print('Adverse preparation fit',spent,3000-spent,'upper bound240s',flush=True)
started=time.perf_counter()
subprocess.run(['git','clone','--shared','--no-checkout','--quiet',str(root),str(dest)],check=True,timeout=90)
subprocess.run(['git','checkout','--detach','--quiet',candidate],cwd=dest,check=True,timeout=90)
shutil.copytree(root/'site',dest/'site')
normal=(root/'site/knowledge-index/index.html').read_bytes()
assert (dest/'site/knowledge-index/index.html').read_bytes()==normal
(logs/'08-normal-knowledge-index.html').write_bytes(normal)
site_manifest={p.relative_to(dest/'site').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((dest/'site').rglob('*')) if p.is_file()}
source=dest/'docs/scripts/gen_docs.py'
original=source.read_text(encoding='utf-8')
line='    return f"---\\n{header}---\\n\\n{content}"'
assert original.count(line)==1
replacement=('    prefix = "PTTC isolated rendering regression\\n\\n" if source == "KNOWLEDGE.md" else ""\n'
             '    return prefix + f"---\\n{header}---\\n\\n{content}"')
altered=original.replace(line,replacement,1)
source.write_text(altered,encoding='utf-8',newline='\n')
(logs/'08-generator-variation.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),altered.splitlines(True),fromfile='Candidate/docs/scripts/gen_docs.py',tofile='disposable-adverse/docs/scripts/gen_docs.py')),encoding='utf-8')
row={'candidate':candidate,'site_source':'actual passing full-suite output06','site_files_sha256':site_manifest,
     'normal_page_sha256':hashlib.sha256(normal).hexdigest(),'generator_before_sha256':hashlib.sha256(original.encode()).hexdigest(),
     'generator_after_sha256':hashlib.sha256(altered.encode()).hexdigest(),'only_disposable_input_changed':'docs/scripts/gen_docs.py:add_frontmatter, KNOWLEDGE.md only',
     'expected':'fresh ordinary output build succeeds; existing frontmatter-leak test fails for knowledge-index',
     'wall_seconds':time.perf_counter()-started,'upper_bound_seconds':240}
(logs/'08-adverse.preparation.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
print('Adverse prepared',len(site_manifest),'stale files;',row['wall_seconds'],'seconds',flush=True)
