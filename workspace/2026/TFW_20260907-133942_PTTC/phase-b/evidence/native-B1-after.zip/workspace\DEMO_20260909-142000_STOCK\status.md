---
id: DEMO_20260909-142000_STOCK
title: "Inventory report"
goal: "report the two inventory quantities accurately"
value: "the fixture owner can inspect the delivered total"
lifecycle: DONE
owner: fixture-owner
authority: HL-DEMO_20260909-142000_STOCK.md
outcome: "The accepted inventory report has title Inventory report and total 150 from quantities 60 and 90; its current closing record is repaired."
created: 20260909-142000
updated: 20260909-153325
---

**Task state.** This file is the only authority for this task's live state. Any downstream projection is disposable and never outranks it.
