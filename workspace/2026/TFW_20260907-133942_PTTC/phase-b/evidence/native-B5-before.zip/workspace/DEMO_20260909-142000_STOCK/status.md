---
id: DEMO_20260909-142000_STOCK
title: "Inventory report"
goal: "report the two inventory quantities accurately"
value: "the fixture owner can inspect the delivered total"
lifecycle: KNW
owner: fixture-owner
authority: HL-DEMO_20260909-142000_STOCK.md
created: 20260909-142000
updated: 20260909-160949
---

**Task state.** This file is the only authority for this task's live state. Any downstream projection is disposable and never outranks it.
