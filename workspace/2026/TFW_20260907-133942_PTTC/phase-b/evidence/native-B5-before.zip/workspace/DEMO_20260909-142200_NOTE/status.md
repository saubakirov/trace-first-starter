---
id: DEMO_20260909-142200_NOTE
title: "Unrelated note"
goal: "plan the team lunch"
value: "participants know the lunch venue"
lifecycle: TODO
owner: fixture-owner
authority: status.md
created: 20260909-142000
updated: 20260909-142100
---

**Task state.** This file is the only authority for this task's live state. Any downstream projection is disposable and never outranks it.
