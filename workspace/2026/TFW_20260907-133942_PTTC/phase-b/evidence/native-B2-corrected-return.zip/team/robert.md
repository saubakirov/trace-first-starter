---
handle: robert
name: Robert
type: agent
since: 2026-09-09
accountable_to: fixture-owner
may_rule_amendments: false
---
Declared fixture attribution; actual native units retain their distinct PTTC roles.
