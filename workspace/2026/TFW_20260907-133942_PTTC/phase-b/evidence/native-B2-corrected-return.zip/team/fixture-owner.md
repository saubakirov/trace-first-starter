---
handle: fixture-owner
name: Synthetic Fixture Owner
type: human
since: 2026-09-09
---
Synthetic attribution only; not a real human act or PTTC authority.
