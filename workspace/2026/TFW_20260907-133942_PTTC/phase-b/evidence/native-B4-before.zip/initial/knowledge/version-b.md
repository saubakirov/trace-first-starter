# Selected knowledge excerpt

No decision row is present.
