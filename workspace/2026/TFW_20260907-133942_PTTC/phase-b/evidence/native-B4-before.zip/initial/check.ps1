param([string]$ProjectRoot = $PSScriptRoot)
$ErrorActionPreference = 'Stop'
$rows = @(Import-Csv -LiteralPath (Join-Path $ProjectRoot 'inventory.csv'))
if ($rows.Count -ne 2) { throw 'Expected two inventory rows' }
$total = 0
foreach ($row in $rows) {
    $quantity = 0
    if (-not [int]::TryParse($row.quantity, [ref]$quantity) -or $quantity -lt 0) { throw 'Invalid quantity' }
    $total += $quantity
}
$report = Get-Content -Raw -LiteralPath (Join-Path $ProjectRoot 'report.json') | ConvertFrom-Json
if ($report.title -ne 'Inventory report' -or $report.total -ne $total) {
    Write-Output "FAIL: report=$($report.total); inventory=$total"
    exit 1
}
Write-Output "PASS: report=$($report.total); inventory=$total"
