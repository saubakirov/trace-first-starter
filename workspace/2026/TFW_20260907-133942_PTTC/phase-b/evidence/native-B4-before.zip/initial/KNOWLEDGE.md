# Fixture knowledge

## 1. Architecture Map

The receiver owns inventory.csv, report.json and check.ps1.

## 2. Key Artifacts

FIXTURE.md and the selected task artifacts carry the synthetic premises.

## 3. Legacy & Deprecation

No legacy changes.

## 4. Project Facts

No verified project facts. All nine ordinary categories have zero facts.
