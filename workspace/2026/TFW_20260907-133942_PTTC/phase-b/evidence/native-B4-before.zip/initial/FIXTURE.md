# Synthetic receiving-project contract

This is one disposable receiving project, authorized only by PTTC B TS AC-4 and its actual
Coordinator dispatch. Every earlier owner/approval statement below is an explicitly synthetic
input, not an observed human act or an actual native verdict. It grants no real PTTC authority.

Synthetic outcome: a two-row inventory, 60 and 90, is reported as total 150 under the title
Inventory report. The project chooses its own PowerShell check. Its ordinary operation has
no sender Git-history, Python, pytest or MkDocs dependency.

The fixture owner reserves amendments to the quantities or acceptance rule. The assigned
Coordinator may apply already approved dispositions, close or repair records within that bound;
the separate Reviewer assesses claims; the Executor may correct report output only when routed.
No holder may independently accept its own material new output. No grant exists for publication.

Actual PTTC units act in their already assigned roles: Coordinator
01a08499-5ef0-7693-b8f6-3aa6bdc40516; Executor 01a08565-a2a2-7272-b46e-4504e505b43a;
Reviewer 01a08565-a299-7e20-ae91-340734e0e949. The real owner/TS/A3/A4, not this fixture, govern them.

The initial directory is immutable input. Both decision holders read the same initial bytes and
case requests; neither reads the other's response before both initial decisions are sealed.
Only after parent routing may actions mutate the project working copy. The six cases present
different epochs/variations of this one fixture. A case reset is explicit disposable input setup,
not a real lifecycle transition. Preserve each observed before/after snapshot before any reset.
Original initial bytes and original erroneous events remain available for independent inspection.

Task: workspace/DEMO_20260909-142000_STOCK. Case requests live in cases.json. They contain factual inputs and requests, not
Executor conclusions. Return one separately formed assessment per case with relevant source and
evidence needs. Stop at the role boundary. Initial decisions are sealed before follow-up actions.
