---
handle: robert
name: Robert
type: agent
---
Declared fixture attribution; actual native units retain their distinct PTTC roles.
