# Workspace Default Probe

Синтетический получатель NF-1 проверяет чистое получение Full и создание первой задачи в workspace.
Ожидаемый результат ограничен Mini-Setup: config/state из шаблонов, один рабочий контейнер и реальная первая запись задачи. Прикладной продукт и команды его сборки отсутствуют.

Входные параметры сценария: slcfx-owner, SLCFX, русский, Codex, без tutorial и preferences; Workspace Default Probe / WDP. Это тестовые входы по SLC NF-1, а не решения реального владельца нового проекта.

- [Метод](.tfw/README.md)
- [Порядок работы со знанием](.tfw/workflows/knowledge.md); проектное KNOWLEDGE ещё не создано.
- [Маршрут запроса релиза](.tfw/workflows/release.md); проектной release-процедуры нет.
- [Первая задача](workspace/2026/SLCFX_20260909-231913_WDP/status.md)

Остановка до research: Mini-Setup не означает завершённую инициализацию.
