# NF-10 prepared input

Receiver: `E:\TEMP\tfw-slc-native-05c6fcdfe6a1\receivers\nf10-divergent`. Prepared by prepare_inputs.py from immutable candidate framework bytes, excluding upstream config/state/receipts. All values, history, profiles, knowledge and any cut preservation are synthetic scenario INPUT, not a native result or completed stage.

Initial active list: `['workspace', 'tasks']`. Historical list: `None`. Prepared cut: `divergent`. Synthetic slcfx-owner container disposition: tasks is retained historical-only storage; no continuation is selected and no terminal lifecycle is inferred.

Only slcfx-owner is declared locally; native robert operator attribution remains in observations, with no agent binding/profile inference. Build is empty because no application exists; own receiver checks are direct shape/preservation/reader observations, not a source suite or placeholder echo PASS.
