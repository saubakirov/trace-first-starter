# NF-10 synthetic receiver

Prepared scenario input, not a completed init or real owner decision. Purpose: bounded SLC native observation. Russian, Codex, no tutorial/preferences; no application or application build commands.

Synthetic slcfx-owner container disposition: tasks is retained historical-only storage; no continuation is selected and no terminal lifecycle is inferred.

Project-owned bytes must survive. The installed .tfw/README.md is framework-owned, never this project's purpose or an attachment citation.
