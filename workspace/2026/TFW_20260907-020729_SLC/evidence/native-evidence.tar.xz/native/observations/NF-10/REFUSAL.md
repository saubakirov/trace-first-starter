# NF-10 — actual native refusal before application

After reading the pinned target workflow/3.3.0 guide and exact prepared preservation, the native Coordinator observed a conflicting affected digest. The attachment SLC__8a2dee13b477251168ef5aaa160ec40f9221575c411cabcd97c9d748eb960837.json records SLCFX-1 = 64 `a` characters; actual current state contains SLCFX-1 = 64 `d` characters. Source, guide, before-image hashes, disposition and membership otherwise resolve; 01-revalidation.json records the actual values.

The guide §4 permits an old-and-equal value or an already-absent removed pair. The observed value is neither. I therefore refuse the connected historical state/config/provenance group. I do not copy payload/adapters, prune state, narrow config, overwrite the conflicting digest, restore the old whole map, infer consolidation or perform ordinary Knowledge Gate threshold arithmetic over this unresolved migration.

Current active [workspace,tasks], old config version/provenance, later conflicting SLCFX-1, unaffected SLCFX-10, task and knowledge bytes remain intact. Diagnostic .upstream was staged/re-pinned before refusal and is retained openly; this is not an assertion of zero diagnostic writes. No successful update is claimed.

Next authoritative action in a real receiver would be resolving the exact conflicting pair and its authority against actual intervening work. In this bounded NF-10 input, the conflict is intentional and remains preserved; no new owner question or correction is authorized/needed for the expected refusal observation.
