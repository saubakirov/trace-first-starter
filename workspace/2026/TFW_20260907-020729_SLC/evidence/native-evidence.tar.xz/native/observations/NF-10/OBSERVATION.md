# NF-10 — native observation

REFUSED: current affected SLCFX-1=d*64 conflicts with preserved a*64. It is neither old-and-equal nor already absent. Refuse the connected state/config/provenance group under guide section 4; no overwrite, whole-map rollback, digest reset, payload or adapter application.

Actual 01-revalidation.json shows the conflicting pair while source/guide/authority/before-image hashes and membership resolve. REFUSAL.md records the native decision. protected-byte-audit.json and refusal-diff.json observe 74 diagnostic staging additions, zero removed files, zero modified files; active mixed config, old config version/provenance, divergent pair, active neighbor, tasks and later project bytes are intact.

Not computed: affected migration remains unresolved. A threshold calculation or forced reset would hide the known conflict.

Expected refusal is the required NF-10 observation, not a successful receiver update or an SLC product verdict. Prepared .tfw/VERSION=3.3.0 and config=3.2.0 discrepancy remains honestly unresolved. Diagnostic staging had occurred and is retained; zero project-field writes does not mean zero diagnostic writes. In a real receiver the next authority must resolve SLCFX-1 against intervening work; no such corrective effect is authorized in this intentional conflict fixture.

Evidence and checks are enumerated in receipt-native-body.md and protected-byte-audit.json. Actual sealed receipt locator is receipt-native.json once created; this observation itself is not a sealed attempt.
