---
handle: slcfx-owner
name: Synthetic SLC fixture owner
type: human
since: 2026-09-09
---

**Participant profile.** Declared attribution, not authentication. It grants and verifies nothing.
