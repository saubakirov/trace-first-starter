param([Parameter(Mandatory=$true)][string]$ReceiverRoot)
# Mechanical file copy only. The native Coordinator resolves workflow/authority/migration first.
$ErrorActionPreference = 'Stop'
$slcReceiver = (Resolve-Path -LiteralPath $ReceiverRoot).ProviderPath
$slcAllowed = [IO.Path]::GetFullPath('E:/TEMP/tfw-slc-native-05c6fcdfe6a1/receivers/')
if (-not $slcReceiver.StartsWith($slcAllowed,[StringComparison]::OrdinalIgnoreCase)) { throw 'Outside assigned receivers.' }
$slcSource = Join-Path $slcReceiver '.tfw/.upstream/.tfw'
$slcExcluded = @('project_config.yaml','knowledge_state.yaml','update_receipts','.upstream')
Get-ChildItem -Force -LiteralPath $slcSource | Where-Object { $_.Name -notin $slcExcluded } | Copy-Item -Destination (Join-Path $slcReceiver '.tfw') -Recurse -Force
$slcCommands = @('plan','research','handoff','review','resume','docs','knowledge','release','update','config','init')
foreach ($slcCommand in $slcCommands) {
    $slcDestination = Join-Path $slcReceiver ('.agents/skills/tfw-' + $slcCommand)
    New-Item -ItemType Directory -Force -Path $slcDestination | Out-Null
    Copy-Item -LiteralPath (Join-Path $slcSource ('adapters/codex/skills/tfw-' + $slcCommand + '/SKILL.md')) -Destination (Join-Path $slcDestination 'SKILL.md') -Force
}
$slcRootPath = Join-Path $slcReceiver 'AGENTS.md'
if (Test-Path -LiteralPath $slcRootPath) { throw 'This mechanical call only handles the inspected absent root; existing root needs direct bounded merge.' }
Copy-Item -LiteralPath (Join-Path $slcSource 'adapters/codex/AGENTS.md.template') -Destination $slcRootPath
Write-Output 'Copied framework and selected Codex adapter. Excluded project_config merge, knowledge_state, receipts/preservation/.upstream, root project purpose, knowledge, tasks, profiles, build and all unrelated content. Framework README operation: verified framework-owned source; replacement allowed, bytes unchanged where equal.'
