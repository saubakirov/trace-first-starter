"""Read-only file parity and metadata measurement, not a workflow engine or native proof."""
import hashlib, json, sys
from pathlib import Path
import yaml
root = Path(sys.argv[1])
source = root / '.tfw/.upstream/.tfw'
excluded = {'project_config.yaml','knowledge_state.yaml','update_receipts','.upstream'}
files = [p for p in source.rglob('*') if p.is_file() and p.relative_to(source).parts[0] not in excluded]
different = [p.relative_to(source).as_posix() for p in files if not (root/'.tfw'/p.relative_to(source)).exists() or p.read_bytes() != (root/'.tfw'/p.relative_to(source)).read_bytes()]
manifest = yaml.safe_load((source/'adapters/manifest.yaml').read_text(encoding='utf-8'))
commands = manifest['commands']
adapters = manifest['adapters']
missing_sources = []
for adapter in adapters.values():
    if not (root/'.tfw/.upstream'/adapter['persistent']['source']).is_file():
        missing_sources.append(adapter['persistent']['source'])
    for command, spec in commands.items():
        src = adapter['commands']['source'].format(command=command,workflow=spec['workflow'])
        if not (root/'.tfw/.upstream'/src).is_file():
            missing_sources.append(src)
bad_copies = [c for c in commands if not (root/f'.agents/skills/tfw-{c}/SKILL.md').is_file() or
              (source/f'adapters/codex/skills/tfw-{c}/SKILL.md').read_bytes() != (root/f'.agents/skills/tfw-{c}/SKILL.md').read_bytes()]
actual_commands = sorted(p.name[4:] for p in (root/'.agents/skills').glob('tfw-*') if p.is_dir())
cfg = yaml.safe_load((root/'.tfw/project_config.yaml').read_text(encoding='utf-8'))
state = yaml.safe_load((root/'.tfw/knowledge_state.yaml').read_text(encoding='utf-8'))
ag = (root/'AGENTS.md').read_text(encoding='utf-8') if (root/'AGENTS.md').is_file() else ''
result = {'receiver':str(root.resolve()),'framework_file_count':len(files),'different_framework_files':different,
          'manifest_adapters':list(adapters),'manifest_commands':list(commands),'manifest_roles':{c:s['role'] for c,s in commands.items()},
          'unresolved_manifest_sources':missing_sources,'bad_codex_copies':bad_copies,'actual_codex_commands':actual_commands,
          'root_start_markers':ag.count('<!-- TFW:CODEX:START -->'),'root_end_markers':ag.count('<!-- TFW:CODEX:END -->'),
          'root_exact_source':(root/'AGENTS.md').is_file() and (root/'AGENTS.md').read_bytes()==(source/'adapters/codex/AGENTS.md.template').read_bytes(),
          'version_file':(root/'.tfw/VERSION').read_text().strip(),'config_version':cfg['tfw']['version'],
          'installed_from':cfg['tfw']['installed_from'],'active':cfg['tfw']['task_containers'],
          'historical':cfg['tfw'].get('historical_containers'),'state':state,
          'empty_sections_digest':hashlib.sha256(b'\0\0').hexdigest()}
out = Path(sys.argv[2]); out.write_text(json.dumps(result,indent=2,default=str)+'\n',encoding='utf-8')
print(json.dumps(result,default=str))
