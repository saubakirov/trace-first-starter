"""Read and hash preservation/current input; the native Coordinator decides applicability."""
import base64, hashlib, json, sys
from pathlib import Path
import yaml
root = Path(sys.argv[1])
results = []
for path in (root/'.tfw/update_receipts').glob('SLC__*.json'):
    raw = path.read_bytes(); p = json.loads(raw)
    before_config = base64.b64decode(p['config_before_base64'])
    before_state = base64.b64decode(p['state_before_base64'])
    now_cfg = yaml.safe_load((root/'.tfw/project_config.yaml').read_text(encoding='utf-8'))
    now_state = yaml.safe_load((root/'.tfw/knowledge_state.yaml').read_text(encoding='utf-8'))
    current_fields = {'task_containers':now_cfg['tfw']['task_containers'],'historical_containers_present':'historical_containers' in now_cfg['tfw']}
    if current_fields['historical_containers_present']:
        current_fields['historical_containers'] = now_cfg['tfw']['historical_containers']
    results.append({'file':str(path.resolve()),'sha256':hashlib.sha256(raw).hexdigest(),
        'address_matches':path.name == 'SLC__'+hashlib.sha256(raw).hexdigest()+'.json',
        'config_before_hash_matches':hashlib.sha256(before_config).hexdigest()==p['config_before_sha256'],
        'state_before_hash_matches':hashlib.sha256(before_state).hexdigest()==p['state_before_sha256'],
        'authority_hash_matches':hashlib.sha256((root/'README.md').read_bytes()).hexdigest()==p['authority_sha256'],
        'guide_hash_matches':hashlib.sha256((root/'.tfw/.upstream/.tfw/migrations/3.3.0.md').read_bytes()).hexdigest()==p['guide_sha256'],
        'origin':p['origin'],'target_commit':p['target_commit'],'authority':p['authority'],
        'old_fields':p['old_fields'],'intended_fields':p['intended_fields'],'current_fields':current_fields,
        'membership':p['membership'],'preserved_removed_pairs':p['removed_pairs'],
        'current_pairs':now_state['knowledge'].get('processed_task_digests'),
        'before_state':yaml.safe_load(before_state),'current_state':now_state,'current_project':now_cfg['project']})
output=Path(sys.argv[2]); output.write_text(json.dumps(results,indent=2,default=str)+'\n',encoding='utf-8')
print(json.dumps(results,default=str))
