"""Inventory and validate retained files against their manifests; no native verdict or workflow execution."""
import hashlib,json,subprocess
from datetime import datetime
from pathlib import Path

base=Path('E:/TEMP/tfw-slc-native-05c6fcdfe6a1'); obs=base/'observations'
selection=[('NF-1','nf1-greenfield','02-mini-setup'),('NF-2','nf2-first-task','01-hl-draft'),('NF-3','nf3-tasks','99-final'),('NF-4','nf4-history-only','02-historical-resume'),('NF-5-absent','nf5-absent','99-final'),('NF-5-empty','nf5-empty','99-final'),('NF-6','nf6-history','resume-01-read-only'),('NF-7','nf7-keep-active','99-final'),('NF-8','nf8-state-first','99-final'),('NF-9','nf9-config-first','99-final'),('NF-10','nf10-divergent','99-final')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):return {'path':p.as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
def files(root):return {p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(root.rglob('*')) if p.is_file()}
def differences(a,b):return {'added':sorted(b.keys()-a.keys()),'removed':sorted(a.keys()-b.keys()),'modified':sorted(k for k in a.keys()&b.keys() if a[k]!=b[k])}
data={'indexed_at':datetime.now().astimezone().isoformat(timespec='seconds'),'base':base.as_posix(),'candidate':'05c6fcdfe6a1c1b4e9615f0390d094ee1b1fb5e8','candidate_tree':'c1c9f62fc31634f11227a7b9c4789d5c8f118f92','cases':[],'common_evidence':[],'snapshot_mismatches':[],'receiver_mismatches':[],'receipt_locator_mismatches':[]}
for case,name,selected in selection:
 p=obs/case; root=base/'receivers'/name
 row={'case':case,'receiver':root.as_posix(),'final_manifest':info(p/selected/'manifest.json'),'snapshots':[],'observation_files':[info(x) for x in sorted(p.iterdir()) if x.is_file()],'receipts':[info(x) for x in sorted((root/'.tfw/update_receipts').glob('UPDATE__*.md'))],'preservation':[info(x) for x in sorted((root/'.tfw/update_receipts').glob('SLC__*.json'))]}
 for manifest in sorted(p.glob('*/manifest.json')):
  m=json.loads(manifest.read_text(encoding='utf-8')); actual=files(manifest.parent/'tree'); d=differences(m['files'],actual)
  actual_dirs=sorted(x.relative_to(manifest.parent/'tree').as_posix() for x in (manifest.parent/'tree').rglob('*') if x.is_dir())
  if any(d.values()) or actual_dirs!=m['directories']:data['snapshot_mismatches'].append({'manifest':manifest.as_posix(),'diff':d,'directory_diff':actual_dirs!=m['directories']})
  row['snapshots'].append(info(manifest)|{'file_count':len(m['files']),'observed_at_utc':m['observed_at_utc']})
 final=json.loads((p/selected/'manifest.json').read_text(encoding='utf-8')); current=files(root); d=differences(final['files'],current)
 current_dirs=sorted(x.relative_to(root).as_posix() for x in root.rglob('*') if x.is_dir())
 row['current_vs_final_manifest']=d; row['current_directories_equal']=current_dirs==final['directories']
 if any(d.values()) or not row['current_directories_equal']:data['receiver_mismatches'].append({'case':case,'diff':d})
 for locpath in [p/'receipt-native.json',p/'receipt-repeat.json']:
  if not locpath.exists():continue
  loc=json.loads(locpath.read_text()); actual=Path(loc['receipt'])
  if not actual.is_file() or sha(actual)!=loc['sha256']:data['receipt_locator_mismatches'].append(locpath.as_posix())
 if case in ['NF-3','NF-5-absent','NF-5-empty','NF-6','NF-7','NF-9']:
  before=json.loads((p/'repeat-01-reobserved/manifest.json').read_text())['files']; d=differences(before,final['files'])
  row['after_repeat_check_diff']=d
 elif case in ['NF-8','NF-10']:
  before=json.loads((p/('02-recovered' if case=='NF-8' else '02-refused')/'manifest.json').read_text())['files'];row['after_first_check_diff']=differences(before,final['files'])
 data['cases'].append(row)
data['common_evidence']=[info(p) for p in sorted(obs.iterdir()) if p.is_file() and p.name not in ['EVIDENCE-INDEX.json','FINAL-NATIVE-RETURN.md']]
original=obs/'NF-3/reprepare-retained/.tfw/update_receipts/UPDATE__20260909-233251__4fcd.md'
original_copy=obs/'NF-3/02-original-source-deviation/tree/.tfw/update_receipts/UPDATE__20260909-233251__4fcd.md'
data['original_deviating_nf3_receipt']={'retained':info(original),'snapshot':info(original_copy),'original_sha256':'36ce5caf52c291ebe4f12c9fc19b6bfbeef064890814f4849fc2a9e64326b685','both_match_original':sha(original)==sha(original_copy)=='36ce5caf52c291ebe4f12c9fc19b6bfbeef064890814f4849fc2a9e64326b685','original_locator':'NF-3/receipt-first.json preserves its original now-relocated path; do not rewrite history'}
control='C:/Users/c0rpa/.codex/worktrees/4907/steps-framework'; source='C:/Users/c0rpa/.codex/worktrees/0edf/steps-framework'
data['control']={'path':control,'head':subprocess.check_output(['git','-C',control,'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',control,'status','--short'],text=True).splitlines()}
data['clean_source']={'path':source,'tfw_status':subprocess.check_output(['git','-C',source,'status','--short','--','.tfw'],text=True).splitlines()}
out=obs/'EVIDENCE-INDEX.json'
with out.open('x',encoding='utf-8') as f:json.dump(data,f,indent=2);f.write('\n')
print(json.dumps({'index':info(out),'case_count':len(data['cases']),'snapshot_count':sum(len(c['snapshots']) for c in data['cases']),'snapshot_mismatches':data['snapshot_mismatches'],'receiver_mismatches':data['receiver_mismatches'],'receipt_locator_mismatches':data['receipt_locator_mismatches'],'original_deviating_receipt_unchanged':data['original_deviating_nf3_receipt']['both_match_original'],'control':data['control'],'clean_source':data['clean_source'],'post_check_diffs':[{'case':c['case'],'diff':c.get('after_repeat_check_diff',c.get('after_first_check_diff'))} for c in data['cases'] if c.get('after_repeat_check_diff',c.get('after_first_check_diff')) is not None]}))
