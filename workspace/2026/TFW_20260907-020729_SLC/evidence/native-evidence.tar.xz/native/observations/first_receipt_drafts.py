"""Serialize the Coordinator's explicitly authored observations below; never choose or execute a workflow."""
import hashlib, json
from pathlib import Path

base = Path('E:/TEMP/tfw-slc-native-05c6fcdfe6a1')
obs = base/'observations'
target = '05c6fcdfe6a1c1b4e9615f0390d094ee1b1fb5e8'
cases = [
    dict(case='NF-3', receiver='nf3-tasks', before='03-reprepared-3.2.0', after='04-applied-clean', check='04-verification-clean.json',
         decision='Preserve the established single active [tasks] choice and first creation path tasks. Apply target framework/Codex surfaces and only version/provenance metadata. No historical key or digest deletion is applicable.',
         observed='Actual corrected 3.2.0 to untagged 3.3.0 upgrade. The re-prepared receiver exactly matched 00-prepared (reprepare-diff.json: 0 added, 0 removed, 0 modified). Corrected application changes only tfw.version and tfw.installed_from outside framework/adapter additions and diagnostic staging; knowledge_state and original task/purpose/profile bytes are unchanged.',
         gate='Active membership: tasks/2026/SLCFX-10 -> SLCFX-10. Pending {SLCFX-10}, removed {}, configured hard interval 5: 1/5, continue. Preserve remembered b*64; do not claim consolidation.',
         limitation='The original first attempt used exact Git archive bytes from a dirty saved checkout and violated the update section 0 clean-source guard. That is an operator procedural deviation, not a clean-source PASS or Candidate defect. Its sealed UPDATE__20260909-233251__4fcd.md (SHA256 36ce5caf52c291ebe4f12c9fc19b6bfbeef064890814f4849fc2a9e64326b685) remains unchanged at observations/NF-3/reprepare-retained/.tfw/update_receipts/ and in 02-original-source-deviation/tree/.tfw/update_receipts/. The original receipt locator names its original, now relocated path; these retained paths resolve it. The root directed transparent fixture re-preparation; this is not a native crash or product rollback. A rejected recursive-delete command had no effects; explicit validated Move-Item retained the old framework/adapter tree. SOURCE-CORRECTION.md records the ruling and mechanics.'),
    dict(case='NF-5-absent', receiver='nf5-absent', before='00a-qualified-input', after='03-applied', check='03-verification.json',
         decision='Determinate absent secondary: normalize exact active [workspace, tasks] to [workspace], without a question or any historical key/folder. Membership and remembered map are empty; remove no pair.',
         observed='Actual 3.2.0 upgrade; framework and selected adapters were installed while the old mixed config still held (01-compatible-readers). Only task_containers and version/provenance changed in config. State was not written; tasks remains absent. No task or historical scaffold was added.',
         gate='Active membership {}, remembered {}, pending {}, removed {}; configured hard interval 5: 0/5 no-op.',
         limitation='During fixture preparation, the generic initial README sentence was qualified to state absent storage and no keep-active decision before application. Original 00-prepared and actual 00a-qualified-input are retained. Preservation and initial staging occurred before the clean-source clarification; their origin/time are unchanged, not retrospectively attributed to 0edf. Identical Candidate and archive bytes were then revalidated from clean 0edf before payload/config/provenance application. An operator string guard failed on CRLF matching before any state/config write; rereading confirmed unchanged semantic inputs, followed by an exact patch. This was tooling failure, not a Candidate refusal.'),
    dict(case='NF-5-empty', receiver='nf5-empty', before='00a-qualified-input', after='03-applied', check='03-verification.json',
         decision='Determinate empty secondary: normalize exact active [workspace, tasks] to [workspace], without a question or any historical key/folder. Membership and remembered map are empty; remove no pair.',
         observed='Actual 3.2.0 upgrade; framework and selected adapters were installed while old mixed config still held (01-compatible-readers). Only task_containers and version/provenance changed in config. State was not written; the pre-existing empty tasks directory remains empty. It is retained input, not a newly created historical scaffold.',
         gate='Active membership {}, remembered {}, pending {}, removed {}; configured hard interval 5: 0/5 no-op.',
         limitation='During fixture preparation, the generic initial README sentence was qualified to state empty storage and no keep-active decision before application. Original 00-prepared and actual 00a-qualified-input are retained. Preservation and initial staging occurred before the clean-source clarification; their origin/time are unchanged, not retrospectively attributed to 0edf. Identical Candidate and archive bytes were then revalidated from clean 0edf before payload/config/provenance application. An operator string guard failed on CRLF matching before any state/config write; rereading confirmed unchanged semantic inputs, followed by an exact patch. This was tooling failure, not a Candidate refusal.'),
    dict(case='NF-6', receiver='nf6-history', before='00-prepared', after='03-applied', check='03-verification.json',
         decision='Apply the explicit synthetic container-level historical-only disposition in README.md: active [workspace], historical [tasks]. Membership tasks/SLCFX-1 -> SLCFX-1; remove only its old-and-equal a*64 remembered pair. Preserve whole distinct SLCFX-10 and all task paths/bytes; infer no terminal lifecycle.',
         observed='Actual 3.2.0 same-major migration. 01-compatible-readers shows compatible payload/adapters before narrowing. 02-state-before-config observes the actual sequential state reconciliation with old mixed config, not a crash. Only then were active/history fields and version/provenance published. Original active SLCFX-10=b*64, knowledge, consolidation date/statistics and unrelated config remain unchanged.',
         gate='Current active workspace/2026/SLCFX-10 only; reference tasks/SLCFX-1 remains readable. Pending {SLCFX-10}, removed {}; hard interval 5: 1/5 continue. Historical SLCFX-1 is not an introduced removed-ID gate issue.',
         limitation='Preservation and original staging were made before source clarification. Their actual origin/time remain intact; same Candidate and archive bytes were revalidated from clean 0edf before target payload/state/config/provenance application. A CRLF string guard failed before affected writes and was corrected after revalidation. The old-and-equal pair was removed once using an exact patch, never a whole-map replacement.'),
    dict(case='NF-7', receiver='nf7-keep-active', before='00-prepared', after='01-applied', check='01-verification.json',
         decision='SETTLED KEEP-ACTIVE DECISION: retain exact [workspace, tasks], no historical key and no digest deletion. Relevant membership is tasks/SLCFX-1 -> SLCFX-1, with active neighbor workspace/2026/SLCFX-10 -> SLCFX-10. Authority is the approved NF-7 synthetic slcfx-owner reply, applied only after the actual grouped question; QUESTION.md and SCRIPTED-REPLY.md record it. The prior unclear README remains byte-identical. This new decision is recorded in this immutable attempt, not inferred from task age or missing status. Reuse it when membership/disposition remain unchanged; new material circumstances require fresh observation.',
         observed='The actual Coordinator grouped the possible continuation and asked before application. QUESTION.md was authored and displayed in the native tool result at 2026-09-09T23:39:05+05:00; only afterward the pre-approved scripted keep-active reply was supplied. Target payload/adapters and version/provenance then applied. Both remembered pairs a*64 and b*64 and all project/task bytes survive.',
         gate='Active whole IDs {SLCFX-1, SLCFX-10}; pending both, removed {}; hard interval 5: 2/5 continue. Missing modern task state is not converted to DONE or historical disposition.',
         limitation='This is an actual native question with an explicitly scripted fixture reply, not a newly delivered real-human question, owner approval, or comprehension observation. No second material question is warranted while these exact circumstances remain unchanged.'),
    dict(case='NF-8', receiver='nf8-state-first', before='00-prepared', after='02-recovered', check='02-verification.json',
         decision='Recover the evidenced state-first cut: affected pair SLCFX-1 is already absent and affected config still equals recorded old fields. Preserve later active SLCFX-10=c*64 and later project edits; publish only intended active [workspace]/historical [tasks] plus outstanding version/provenance.',
         observed='01-revalidation.json verifies content address, before-image hashes, guide/authority identity and old-or-intended affected inputs. Compatible readers/adapters are present before final config. No knowledge_state write occurred. project.after_cut_note and workspace/2026/SLCFX-10/later-active.txt are retained byte-for-byte. Actual retry completes the expected affected config without restoring the old b*64 active value.',
         gate='Current active {SLCFX-10}, pending {SLCFX-10}, removed {}; hard interval 5: 1/5 continue. The later remembered c*64 is retained; no consolidation is invented.',
         limitation='The cut and before-image were explicitly prepared inputs, not a prior native update attempt or observed crash. The native observation is the actual recovery from that prepared state. The prepared preservation identifies this origin.'),
    dict(case='NF-9', receiver='nf9-config-first', before='00-prepared', after='02-recovered', check='02-verification.json',
         decision='Despite both version fields already equaling 3.3.0 and Candidate provenance, inspect the target changelog/guide and exact preservation. Recover legacy config-first cut by deleting only old-and-equal SLCFX-1=a*64; preserve active SLCFX-10=b*64 and the already intended config.',
         observed='01-revalidation.json verifies content address, before-image hashes, guide/authority identity and affected membership. The actual equal-version retry installed exact selected adapters and reconciled the one historical pair before gate arithmetic. Config bytes were not changed. Only knowledge.processed_task_digests.SLCFX-1 changed in project state.',
         gate='Current active {SLCFX-10}, pending {SLCFX-10}, removed {}; hard interval 5: 1/5 continue. Version equality was an input, not evidence of completed migration.',
         limitation='The config-first cut and before-image were explicit prepared inputs, not an observed crash or a forged prior native attempt. This receipt records actual recovery; the subsequent completed equal-version repeat is a separate required observation.'),
    dict(case='NF-10', receiver='nf10-divergent', before='00-prepared', after='02-refused', check='01-revalidation.json',
         decision='REFUSED: current affected SLCFX-1=d*64 conflicts with preserved a*64. It is neither old-and-equal nor already absent. Refuse the connected state/config/provenance group under guide section 4; no overwrite, whole-map rollback, digest reset, payload or adapter application.',
         observed='Actual 01-revalidation.json shows the conflicting pair while source/guide/authority/before-image hashes and membership resolve. REFUSAL.md records the native decision. protected-byte-audit.json and refusal-diff.json observe 74 diagnostic staging additions, zero removed files, zero modified files; active mixed config, old config version/provenance, divergent pair, active neighbor, tasks and later project bytes are intact.',
         gate='Not computed: affected migration remains unresolved. A threshold calculation or forced reset would hide the known conflict.',
         limitation='Expected refusal is the required NF-10 observation, not a successful receiver update or an SLC product verdict. Prepared .tfw/VERSION=3.3.0 and config=3.2.0 discrepancy remains honestly unresolved. Diagnostic staging had occurred and is retained; zero project-field writes does not mean zero diagnostic writes. In a real receiver the next authority must resolve SLCFX-1 against intervening work; no such corrective effect is authorized in this intentional conflict fixture.')
]

for c in cases:
    p=obs/c['case']; root=base/'receivers'/c['receiver']
    before=p/c['before']/'manifest.json'; after=p/c['after']/'manifest.json'
    attachments=sorted((root/'.tfw/update_receipts').glob('SLC__*.json'))
    refs='\n'.join('- '+str(x).replace('\\','/')+'; SHA256 '+hashlib.sha256(x.read_bytes()).hexdigest() for x in attachments) or 'None required: no affected state/container retirement.'
    manifest_refs='\n'.join('- '+str(x).replace('\\','/')+'; SHA256 '+hashlib.sha256(x.read_bytes()).hexdigest() for x in [before,after])
    verification = ('Source integrity/provenance: VERIFIED for the pinned clean source; target application is REFUSED. Receiver state/config exclusions and conflicting-byte preservation: VERIFIED by the audit. Connected-group consistency: BLOCKED by the exact SLCFX-1 conflict. Adapter/runtime surface: N/A because no target/adapter application was selected after refusal; do not claim installed parity or update completion.' if c['case']=='NF-10' else
        'Source integrity/provenance, receiver exclusions, connected-group result and selected adapter surface: VERIFIED for this observed run. '+c['check']+' measures all 71 selected framework files equal to the pinned target, four manifest adapters/eleven command roles with resolving sources, eleven exact installed Codex copies, and one exact managed root. Both version fields equal 3.3.0 and installed_from names the full untagged Candidate. Matching installed bytes also retain the target live wording and exclusions; this does not certify future agent behavior.')
    body=f'''## 1. Pinned source and receiver

Receiver: {root.as_posix()}. Baseline is an explicitly prepared uncommitted filesystem state, not a Git commit: {before.as_posix()}. Target is authorized untagged Candidate {target}, tree c1c9f62fc31634f11227a7b9c4789d5c8f118f92, prepared version 3.3.0; no v3.3.0 tag is asserted. Clean read-only source C:/Users/c0rpa/.codex/worktrees/0edf/steps-framework supplied git archive of that exact object, never HEAD/live-tree copies. Archive {obs.as_posix()}/source-candidate-clean-framework.tar, SHA256 0d2c52981cd4b027ad6ae4b2b874d44b2f26335c821cd05262b2aacbbf957e58. SOURCE-PIN-CLEAN.json and SOURCE-CORRECTION.md record source guard, origin and root clarification 2fd47b036aea5d34f79415043366c1efe15340d8. Clean .tfw status was re-observed before this sealing pass. Target behavior reader is {root.as_posix()}/.tfw/.upstream/.tfw/workflows/update.md with target CHANGELOG.md and migrations/3.3.0.md. Guide SHA256 d544442538eef8000885700ac379ee4f9fbf3d112757aa8bcf21a46ac969e44c. Actual attempt sealing clock/identity are in this receipt header; snapshots retain action observation times.

## 2. Authority and semantic groups

Actual native Coordinator robert, task 01a08584-8bcf-7481-97a0-bd27d04dbb55; parent/root 01a08164-fb6d-78a3-b41a-e0fabdc680c9. Real acceptance authority saubakirov through exact SLC TS approval 40b2dd5666cf608a9f1282567550de6a6b62fadd, TS blob 6535418fb65ad1b6f7f7a7b40a01506c1df27943, bounded slc-native-nf1-nf10 dispatch and slc-native-clean-source clarification. Synthetic receiving human slcfx-owner and receiver purpose/disposition are test inputs. No real-human acceptance, AT admission or release publication is claimed.

Groups considered together: pinned canonical framework/templates/migration, selected Codex managed root and eleven skills, receiver active/reference membership and exact remembered pairs, framework version/provenance, project-purpose designation/exclusions, immutable evidence and outcome. The acting Coordinator read and chose these effects; filesystem utilities only copy/hash/parse or seal already-authored text.

## 3. Decision and effects

{c['decision']}

{c['observed']}

Project README explicitly designates installed .tfw/README.md as framework-owned, not receiver Project North Star or a purpose-bearing legacy source. Its replace-after-verify classification applies to completed updates; NF-10 leaves it untouched. Root README.md remains project-owned and unchanged. No purpose-bearing legacy replacement/attachment was required. Config, knowledge_state, upstream task history, upstream receipts/preservation and unrelated content were excluded from payload. Only the explicitly stated affected fields/pairs and metadata were merged; source project state never replaces receiver state. KNOWLEDGE.md, profiles, task artifacts, language/prefix, build={{}}, scope budgets, consolidation date/statistics and all unaffected choices remain intact. No runtime/helper is installed as a receiving-project prerequisite.

Preservation references (each filename is its full content hash; these are evidence, not current authority):
{refs}

## 4. Verification

{verification}

Protected-byte comparison: {p.as_posix()}/protected-byte-audit.json. It reports exact config/state semantic changes and zero original non-framework/purpose/task/profile changes. Snapshot manifests:
{manifest_refs}

Native membership and Knowledge Gate observation: {c['gate']} Selected synthetic HLs have no gate sections; current digest is SHA256(two NUL) = 96a296d224f285c67bee93c30f8a309157f0daa35dc5b87e410b78630a09cfc7. Remembered a/b/c/d values are prepared inputs, not processed facts. No malformed membership or whole-ID collision was observed in these bounded paths.

Maintainer checks: N/A as a receiver prerequisite. Root/Executor's existing 581 passed/1 skipped and MkDocs exit 0 are separate source assurance, not native receiver verification, and were not rerun here. Application checks: N/A because this explicit synthetic receiver has build {{}} and no application; no placeholder/echo command is claimed PASS. File/YAML measurements are diagnostic tools of this experiment, not a shipped runtime or proof of filesystem/network isolation, provider G8 or owner understanding.

Limitations/deviations: {c['limitation']}

## 5. Cleanup, continuation, and final-message input

Cleanup resolved/disclosed before sealing: retain {root.as_posix()}/.tfw/.upstream and all assigned receiver/source/archive/snapshot/evidence paths below {base.as_posix()} for required inspection. These are diagnostic retained paths, not installed project state; no destructive cleanup is needed. Original observations and receipts remain immutable. No external action, tag or push occurred.

Unresolved material items: {'intentional affected-pair conflict described above; receiver update is incomplete' if c['case']=='NF-10' else 'none for this observed application; required repeat/resume evidence, where specified by the NF matrix, follows as a separate action'}. Next authoritative action: {'root/Executor indexes this expected refusal; a real receiver would require authority to resolve the exact conflicting pair' if c['case']=='NF-10' else 'perform only the already assigned remaining repeat/resume, then return native evidence to root for Executor EV/RF and independent Reviewer assessment'}.

Final message delivery at receipt time: planned/not-yet-observed. Render a Russian outcome from this sealed receipt, citing actual completion or refusal, useful active/historical paths, preserved choices, deviations/limitations and next action. A saved outcome is a rendered fixture message, not proof of real-human delivery or comprehension. Evidence root: {p.as_posix()}.
'''
    for filename,text in [('receipt-native-body.md',body),('OBSERVATION.md',f"# {c['case']} — native observation\n\n{c['decision']}\n\n{c['observed']}\n\n{c['gate']}\n\n{c['limitation']}\n\nEvidence and checks are enumerated in receipt-native-body.md and protected-byte-audit.json. Actual sealed receipt locator is receipt-native.json once created; this observation itself is not a sealed attempt.\n")]:
        with (p/filename).open('x',encoding='utf-8',newline='\n') as f: f.write(text)
    print(json.dumps({'case':c['case'],'body':str(p/'receipt-native-body.md'),'preservation_count':len(attachments)}))
