"""Filesystem evidence only: no workflow routing, decisions, acceptance or agent emulation."""
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

def manifest(root):
    root = Path(root)
    return {p.relative_to(root).as_posix(): {
        "bytes": p.stat().st_size,
        "sha256": hashlib.sha256(p.read_bytes()).hexdigest()
    } for p in sorted(root.rglob("*")) if p.is_file()}

def main():
    action, *args = sys.argv[1:]
    if action == "snapshot":
        root, destination = map(Path, args)
        destination.mkdir(parents=True, exist_ok=False)
        shutil.copytree(root, destination / "tree")
        data = {"observed_at_utc": datetime.now(timezone.utc).isoformat(),
                "receiver": str(root.resolve()), "files": manifest(root),
                "directories": sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_dir())}
        out = destination / "manifest.json"
        out.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"manifest": str(out), "file_count": len(data["files"]),
                          "manifest_sha256": hashlib.sha256(out.read_bytes()).hexdigest()}))
    elif action == "diff":
        first, second, output = map(Path, args)
        a = json.loads(first.read_text(encoding="utf-8"))["files"]
        b = json.loads(second.read_text(encoding="utf-8"))["files"]
        result = {"added": sorted(b.keys() - a.keys()), "removed": sorted(a.keys() - b.keys()),
                  "modified": sorted(k for k in a.keys() & b.keys() if a[k] != b[k])}
        output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"diff": str(output), "counts": {k: len(v) for k, v in result.items()}}))
    elif action == "yaml":
        import yaml
        for name in args:
            path = Path(name)
            value = path.read_text(encoding="utf-8")
            if value.startswith("---\n"):
                value = value.split("---", 2)[1]
            print(json.dumps({"path": str(path), "data": yaml.safe_load(value)}, ensure_ascii=True, default=str))
    elif action == "inspect":
        import yaml
        for name in args:
            root = Path(name)
            cfg = yaml.safe_load((root / '.tfw/project_config.yaml').read_text(encoding='utf-8'))
            state = yaml.safe_load((root / '.tfw/knowledge_state.yaml').read_text(encoding='utf-8'))
            t = cfg['tfw']
            data = {'root': str(root), 'version_file': (root / '.tfw/VERSION').read_text().strip(),
                    'project': cfg['project'], 'tfw': {k:t.get(k) for k in ['version','upstream','installed_from','task_containers','historical_containers','knowledge','scope_budgets']},
                    'build':cfg['build'], 'state':state,
                    'readme':(root / 'README.md').read_text(encoding='utf-8'),
                    'task_files':sorted(p.relative_to(root).as_posix() for container in ['tasks','workspace'] for p in (root / container).rglob('*') if p.is_file()),
                    'preservation':sorted(p.relative_to(root).as_posix() for p in (root / '.tfw/update_receipts').glob('SLC__*.json'))}
            print(json.dumps(data, ensure_ascii=True, default=str))
    else:
        raise SystemExit("snapshot, diff, yaml or inspect only")

if __name__ == "__main__":
    main()
