# Cedar design notes — C3 / 2026-09-12 and 2026-09-13

Synthetic source identity CEDAR-DESIGN-NOTES-032-C3. These are retained proposals, not an owner ruling.
Authority/source roles remain those in sources/charter.md. Both propose a background for the identical
scope: Orion motion previews prepared on or after 2026-09-10.

## Ivo proposal — 2026-09-12

Fictional designer Ivo proposes ivory as the preview background, arguing it makes soft edge details
more visible. This is Ivo's own preference; no owner acceptance is attached.

## Mina proposal — 2026-09-13

Fictional designer Mina proposes charcoal as the preview background, arguing it keeps bright highlights
legible. This is Mina's own preference; no owner acceptance is attached. Mina's later date does not
rule on Ivo's proposal, and neither designer has the charter's acceptance authority.

No compromise or authorized resolution is recorded. A dependent choice requires Rowan's explicit
background decision for this same scope; invented consensus is not an accepted third option.
