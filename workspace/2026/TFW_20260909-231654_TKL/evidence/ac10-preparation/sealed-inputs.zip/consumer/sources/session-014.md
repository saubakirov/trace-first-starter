# Cedar owner session — C0 / 2026-09-01

Synthetic source identity CEDAR-SESSION-014-C0. Original speaker: fictional studio owner Rowan.
Recorder: fictional project recorder Sora. Authority: CEDAR-CHARTER-C0, sources/charter.md.

## Format decision

Rowan accepted PDF as the delivery format for all internal preview/review packages, including motion
and static work. This is the original broad rule recorded as legacy/decisions.md D17 at epoch C0.
It remains a historical accepted decision; its label alone does not establish unchanged current scope.

## Naming decision

Rowan accepted the convention `CDR-{asset}-rNN` for the basename of every review file. `{asset}` is the
work item's asset identifier and NN is a two-digit revision. The appropriate extension follows the
applicable format rule. Example basename: CDR-poster-r03. No later naming change is decided here.

These are fictional internal review decisions, not permission to send files or publish anything.
