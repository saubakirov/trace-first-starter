# Cedar owner session — C2 / 2026-09-10

Synthetic source identity CEDAR-SESSION-027-C2. Original speaker: fictional studio owner Rowan.
Recorder: fictional project recorder Sora. Authority: CEDAR-CHARTER-C0, sources/charter.md.

## Scoped format decision

For Orion motion previews prepared on or after 2026-09-10, Rowan accepts MP4 in place of the PDF format
from the C0 D17 decision. This exception is limited to Orion motion previews. Static catalogue proofs,
including those for Orion, retain PDF; other projects also retain the original scope unless a separate
applicable decision changes it. Original D17/source wording must remain preserved.

The accepted naming convention is unchanged. This session does not decide a preview background and
does not approve public release. It authorizes only the stated fictional internal format choice.
