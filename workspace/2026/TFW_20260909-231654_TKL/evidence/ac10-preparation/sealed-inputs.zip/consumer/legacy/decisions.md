# Cedar historical decisions — epoch C0

Synthetic legacy carrier. Accepted meaning and source text are preserved; inspect current incoming
relations before applying an old accepted label. This is an ordinary source, not a current index.

## D17 — internal review format

Disposition: accepted at C0, 2026-09-01. Statement: all internal preview/review packages use PDF,
including motion and static work. Scope: all Cedar review packages under that original decision.
Source: sources/session-014.md, Format decision, CEDAR-SESSION-014-C0. Original speaker/qualifier:
fictional owner Rowan under sources/charter.md CEDAR-CHARTER-C0; recorder Sora is not the owner.

This exact legacy identity is `legacy/decisions.md#D17 @ C0`. Preserve this original row and source;
look for incoming scoped successors/corrections/conflicts in knowledge/records before current use.
