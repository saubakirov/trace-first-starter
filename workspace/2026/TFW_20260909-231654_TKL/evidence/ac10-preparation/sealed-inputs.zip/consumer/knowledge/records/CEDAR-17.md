# CEDAR-17 @ C2

Synthetic ordinary-file knowledge record. Presence is not acceptance.

| Field | Value |
|---|---|
| Record identity | CEDAR-17 @ C2 |
| Publication intent | Preserve the one stated synthetic claim and its disposition at this record epoch; no real TKL publication or acceptance |
| Kind | technical-reference decision |
| Statement | Use MP4 for Orion motion previews prepared on or after 2026-09-10. |
| Applicability | Only Orion motion previews at or after that synthetic date. Static catalogue proofs, including Orion, and other project scopes are unchanged. |
| Grounds and uncertainty | Exact retained source CEDAR-SESSION-027-C2; source SHA256 5874277795f712a336f5d89389bde31d6f2aea80c39abd631d426f0598ccad8a. The project and roles are synthetic. |
| Disposition | accepted within the synthetic C2 scenario |
| Source | sources/session-027.md / Scoped format decision, epoch CEDAR-SESSION-027-C2, SHA256 5874277795f712a336f5d89389bde31d6f2aea80c39abd631d426f0598ccad8a |
| Originating task and unit | Synthetic Cedar assurance example only; no invented real native task, commit or unit |
| Producer | fictional recorder Sora, preserving Rowan's actual statement in the fixture |
| Qualifier | fictional owner Rowan at session-027 |
| Acceptance authority | Rowan's explicit scoped decision under CEDAR-CHARTER-C0; no real execution grant |
| Completed effect or missing decision | The fictional scoped format choice is complete; background and public release are not decided. |
| Relations | Scoped successor to legacy/decisions.md#D17 @ C0, exact legacy carrier SHA256 631e10deb4f50597daa353053c73dc2bc9f99bc28ba5a548c8fb556aac211b7b. Only the stated Orion-motion/date scope replaces PDF; preserve D17 outside it. |

## Source and decision context

The original broad PDF rule stays readable and still governs the unmodified static/project scope.
The source explicitly leaves naming unchanged. This newer record is applied because of its scoped
accepted decision, not merely its later date. It contains the incoming relation to the exact old D17
identity; the legacy carrier itself was not retroactively edited into a pointer to this record.

## Current use and retry

Inspect actual scope, grounds, disposition and source, then search incoming relations to this identity
and material ancestors. Same source/intent reuses the recorded disposition; a changed claim needs a
separate authorized correction. File presence, source repetition and recency never supply authority.
