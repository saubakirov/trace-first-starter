# CEDAR-28 @ C3-Ivo

Synthetic ordinary-file knowledge record. Presence is not acceptance.

| Field | Value |
|---|---|
| Record identity | CEDAR-28 @ C3-Ivo |
| Publication intent | Preserve the one stated synthetic claim and its disposition at this record epoch; no real TKL publication or acceptance |
| Kind | human knowledge — synthetic design preference |
| Statement | Use ivory as the Orion motion-preview background. |
| Applicability | Orion motion previews prepared on or after 2026-09-10. |
| Grounds and uncertainty | Exact retained source CEDAR-DESIGN-NOTES-032-C3; source SHA256 17628ef20c544c18b44b9b5ee807bd76c9a29b475bfb881a1339d7872c1f15c0. The project and roles are synthetic. |
| Disposition | unresolved proposal, not accepted |
| Source | sources/session-032.md / Ivo proposal — 2026-09-12, epoch CEDAR-DESIGN-NOTES-032-C3, SHA256 17628ef20c544c18b44b9b5ee807bd76c9a29b475bfb881a1339d7872c1f15c0 |
| Originating task and unit | Synthetic Cedar assurance example only; no invented real native task, commit or unit |
| Producer | fictional designer Ivo; retained by recorder Sora without promotion |
| Qualifier | no authorized acceptance qualifier has decided this proposal |
| Acceptance authority | absent for background acceptance; only fictional owner Rowan can decide under CEDAR-CHARTER-C0 |
| Completed effect or missing decision | Keep dependent background choice open until Rowan decides that exact scope. |
| Relations | Unresolved conflict with CEDAR-29 @ C3-Mina, same Orion-motion/date scope; both original proposals remain. No successor or priority relation. |

## Source and decision context

Ivo's argument concerns edge visibility. It is a preserved human-source preference inside the
fiction, not an accepted policy or technical proof. The later counterpart must be inspected without
choosing it solely for recency or inventing agreement.

## Current use and retry

Inspect actual scope, grounds, disposition and source, then search incoming relations to this identity
and material ancestors. Same source/intent reuses the recorded disposition; a changed claim needs a
separate authorized correction. File presence, source repetition and recency never supply authority.
