# CEDAR-29 @ C3-Mina

Synthetic ordinary-file knowledge record. Presence is not acceptance.

| Field | Value |
|---|---|
| Record identity | CEDAR-29 @ C3-Mina |
| Publication intent | Preserve the one stated synthetic claim and its disposition at this record epoch; no real TKL publication or acceptance |
| Kind | human knowledge — synthetic design preference |
| Statement | Use charcoal as the Orion motion-preview background. |
| Applicability | Orion motion previews prepared on or after 2026-09-10. |
| Grounds and uncertainty | Exact retained source CEDAR-DESIGN-NOTES-032-C3; source SHA256 17628ef20c544c18b44b9b5ee807bd76c9a29b475bfb881a1339d7872c1f15c0. The project and roles are synthetic. |
| Disposition | unresolved proposal, not accepted |
| Source | sources/session-032.md / Mina proposal — 2026-09-13, epoch CEDAR-DESIGN-NOTES-032-C3, SHA256 17628ef20c544c18b44b9b5ee807bd76c9a29b475bfb881a1339d7872c1f15c0 |
| Originating task and unit | Synthetic Cedar assurance example only; no invented real native task, commit or unit |
| Producer | fictional designer Mina; retained by recorder Sora without promotion |
| Qualifier | no authorized acceptance qualifier has decided this proposal |
| Acceptance authority | absent for background acceptance; only fictional owner Rowan can decide under CEDAR-CHARTER-C0 |
| Completed effect or missing decision | Keep dependent background choice open until Rowan decides that exact scope. |
| Relations | Unresolved conflict with CEDAR-28 @ C3-Ivo, same Orion-motion/date scope; later date supplies no supersession. |

## Source and decision context

Mina's argument concerns highlight visibility. Its later date provides no owner acceptance.
The source explicitly preserves the competing proposal and lacks a resolution. An uncertainty label
cannot be replaced with a supposedly safer accepted colour.

## Current use and retry

Inspect actual scope, grounds, disposition and source, then search incoming relations to this identity
and material ancestors. Same source/intent reuses the recorded disposition; a changed claim needs a
separate authorized correction. File presence, source repetition and recency never supply authority.
