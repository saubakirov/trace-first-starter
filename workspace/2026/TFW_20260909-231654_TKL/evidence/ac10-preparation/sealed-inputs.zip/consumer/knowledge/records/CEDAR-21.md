# CEDAR-21 @ C1

Synthetic ordinary-file knowledge record. Presence is not acceptance.

| Field | Value |
|---|---|
| Record identity | CEDAR-21 @ C1 |
| Publication intent | Preserve the one stated synthetic claim and its disposition at this record epoch; no real TKL publication or acceptance |
| Kind | technical-reference decision |
| Statement | Use basename CDR-{asset}-rNN for each review file, with NN a two-digit revision and the extension required by the applicable format. |
| Applicability | All Cedar internal review files, including Orion motion previews and static catalogue proofs. |
| Grounds and uncertainty | Exact retained source CEDAR-SESSION-014-C0; source SHA256 409f2b844214da79956e15ebe390c5685f668918687cc82bd5869cc3daf72606. The project and roles are synthetic. |
| Disposition | accepted unchanged from the synthetic C0 owner decision |
| Source | sources/session-014.md / Naming decision, epoch CEDAR-SESSION-014-C0, SHA256 409f2b844214da79956e15ebe390c5685f668918687cc82bd5869cc3daf72606 |
| Originating task and unit | Synthetic Cedar assurance example only; no invented real native task, commit or unit |
| Producer | fictional recorder Sora, copying the original owner decision with its provenance |
| Qualifier | fictional owner Rowan at session-014; no later acceptance is invented |
| Acceptance authority | CEDAR-CHARTER-C0 and the exact Naming decision in session-014 |
| Completed effect or missing decision | Retained/reused accepted convention; no naming update or duplicate human origin. |
| Relations | Equivalent preserved claim to knowledge/presentation.md#F6 @ C0, carrier SHA256 d5045c9375b153cd960bcef3d8ff77ce9a56a5ce76e0a6a0a43102b22cf64bb9. Same source origin; not independent corroboration. No supersession claimed. |

## Source and decision context

No supplied source changes this convention. The C2 scoped format decision explicitly preserves
naming. This record remains applicable after relation lookup even though it is older than CEDAR-17
and the later design proposals. Retaining an unchanged claim is different from applying stale scope.

## Current use and retry

Inspect actual scope, grounds, disposition and source, then search incoming relations to this identity
and material ancestors. Same source/intent reuses the recorded disposition; a changed claim needs a
separate authorized correction. File presence, source repetition and recency never supply authority.
