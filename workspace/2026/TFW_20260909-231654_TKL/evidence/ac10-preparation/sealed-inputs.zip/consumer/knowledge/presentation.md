# Cedar presentation knowledge — legacy topic C0

Synthetic topic carrier; preserved accepted knowledge is checked for incoming current relations.

## F6 — review-file naming

Accepted unchanged naming claim at C0: use basename `CDR-{asset}-rNN`, with a two-digit revision and the
extension required by the applicable format. Scope: every Cedar internal review file. Original human
source: fictional owner Rowan, sources/session-014.md Naming decision, CEDAR-SESSION-014-C0. Authority:
sources/charter.md CEDAR-CHARTER-C0. Sora recorded the statement; source copying is not a new origin.

Exact legacy identity: `knowledge/presentation.md#F6 @ C0`. This topic carries the original meaning;
a later equivalent record can preserve it without changing the convention or claiming corroboration.
