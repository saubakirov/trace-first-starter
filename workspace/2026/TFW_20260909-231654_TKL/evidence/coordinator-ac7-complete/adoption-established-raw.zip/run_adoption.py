import sys,json,hashlib,pathlib,subprocess,datetime,re,yaml
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
E=pathlib.Path(__file__).parent
R=E/'coordinator'
S=pathlib.Path('C:/Users/c0rpa/.codex/worktrees/b8ba/steps-framework')
D=datetime.datetime.fromisoformat('2026-09-13T15:26:13.371245+00:00')
pointer=json.loads((E/'02-preservation.json').read_text())
A=R/pointer['preservation']
P=json.loads((A/'preservation.json').read_text())
M=P['reader_adapter_and_affected_paths']
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def identity(p):
    if not p.exists(): return {'present':False,'sha256':None,'bytes':0}
    b=p.read_bytes();return {'present':True,'sha256':sha(b),'bytes':len(b)}
def matches(p,i):
    return (not p.exists()) if not i['present'] else p.is_file() and sha(p.read_bytes())==i['sha256'] and len(p.read_bytes())==i['bytes']
def git(root,*args,check=True):
    q=subprocess.run(['git','-c','core.longpaths=true','-C',str(root),*args],capture_output=True)
    if check and q.returncode: raise RuntimeError(q.stderr.decode('utf-8','replace'))
    return q
class Unique(yaml.SafeLoader): pass
def mapping(loader,node,deep=False):
    d={}
    for k,v in node.value:
        key=loader.construct_object(k,deep=deep)
        if key in d: raise ValueError('Duplicate YAML key: '+str(key))
        d[key]=loader.construct_object(v,deep=deep)
    return d
Unique.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,mapping)
def config(): return yaml.load((R/'.tfw/project_config.yaml').read_text(encoding='utf-8'),Loader=Unique)
def field(c,name):
    v=c
    for part in name.split('.'):
        if not isinstance(v,dict) or part not in v:return {'present':False,'value':None}
        v=v[part]
    return {'present':True,'value':v}
def guard():
    assert datetime.datetime.now(datetime.timezone.utc)<D,'Epoch exhausted; no more application'
    assert sha((A/'preservation.json').read_bytes())==pointer['content_address']
    assert git(S,'rev-parse',P['target']).stdout.decode().strip()==P['target']
    assert not git(S,'status','--porcelain','--','.tfw').stdout
    for obj,h in P['authority_objects'].items():assert sha(git(S,'show',obj).stdout)==h,obj
    assert matches(R/'README.md',P['root_purpose'])
    for path in ['.tfw/workflows/update.md','.tfw/migrations/knowledge-lifecycle.md','.tfw/migrations/3.3.0.md','.tfw/adapters/manifest.yaml']:
        assert sha(git(S,'show',P['target']+':'+path).stdout)==P['source_payload'][path]
        assert sha((R/'.tfw/.upstream'/path).read_bytes())==P['source_payload'][path]
def conflicts():
    c=config(); out=[]
    for f,pair in P['fields'].items():
        actual=field(c,f)
        if actual not in [pair['old'],pair['intended']]:out.append({'field':f,'actual':actual,**pair})
    for path,pair in M.items():
        if path=='.tfw/project_config.yaml':continue
        if not any(matches(R/path,pair[k]) for k in ['old','intended']):out.append({'path':path,'actual':identity(R/path),**pair})
    return out
def source_all():
    for path,h in P['source_payload'].items():
        assert sha(git(S,'show',P['target']+':'+path).stdout)==h,path
        assert sha((R/'.tfw/.upstream'/path).read_bytes())==h,path
    for path,i in P['entire_before'].items():assert matches(A/'before'/path,i),path
    for path,pair in M.items():
        if pair['intended']['present']:assert matches(A/'intended'/path,pair['intended']),path
def adapters():
    mf=yaml.load((R/'.tfw/adapters/manifest.yaml').read_text(),Loader=Unique)
    assert set(mf['adapters'])=={'codex','claude-code','cursor','antigravity'}
    assert set(mf['commands'])=={'plan','research','handoff','review','resume','docs','knowledge','release','update','config','init'}
    expected={'research':'Researcher','handoff':'Executor','review':'Reviewer'}
    for cmd,c in mf['commands'].items():
        assert c['route']=='/tfw-'+cmd and c['role']==expected.get(cmd,'Coordinator')
        assert (R/c['workflow']).is_file()
        for name,ad in mf['adapters'].items():
            source=ad['commands']['source'].format(command=cmd,workflow=c['workflow'])
            assert (R/source).is_file()
            assert ad['commands']['strategy']=='copy'
        ad=mf['adapters']['codex'];src=R/ad['commands']['source'].format(command=cmd);dst=R/ad['commands']['target'].format(command=cmd)
        assert src.read_bytes()==dst.read_bytes()
    a=(R/'AGENTS.md').read_text(encoding='utf-8');b=(R/'.tfw/adapters/codex/AGENTS.md.template').read_text(encoding='utf-8')
    for marker in ['<!-- TFW:CODEX:START -->','<!-- TFW:CODEX:END -->']:assert a.count(marker)==1
    start=a.index('<!-- TFW:CODEX:START -->');end=a.index('<!-- TFW:CODEX:END -->')+len('<!-- TFW:CODEX:END -->')
    assert a[start:end]==b[b.index('<!-- TFW:CODEX:START -->'):b.index('<!-- TFW:CODEX:END -->')+len('<!-- TFW:CODEX:END -->')]
    assert matches(R/'AGENTS.md',P['entire_before']['AGENTS.md'])
def retained():
    for path,i in P['entire_before'].items():
        if path not in M or M[path]['old']==M[path]['intended']:assert matches(R/path,i),path
    old=(A/'before/KNOWLEDGE.md').read_text(encoding='utf-8');new=(R/'KNOWLEDGE.md').read_text(encoding='utf-8')
    for line in old.splitlines(keepends=True):
        if line not in P['removed_entry_lines'] and line.strip():assert line.strip() in new,line
    assert matches(R/'.tfw/knowledge_state.yaml',P['state']['old'])
def snapshot():
    return {p.relative_to(R).as_posix():identity(p) for p in R.rglob('*') if p.is_file() and '.git' not in p.relative_to(R).parts}
def checks():
    rows=[]
    for args in [('diff','--check'),('fsck','--no-dangling'),('diff','--cached','--check')]:
        q=git(R,*args,check=False);rows.append({'argv':['git','-c','core.longpaths=true',*args],'exit':q.returncode,'stdout':q.stdout.decode('utf-8','replace'),'stderr':q.stderr.decode('utf-8','replace'),'observed_at':now()})
        assert q.returncode==0,rows[-1]
    return rows
def dump(name,obj): (E/name).write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
def apply():
    start=now();guard();source_all();assert not conflicts(),conflicts()
    for path,i in P['entire_before'].items():assert matches(R/path,i),path
    writes=[]
    for path,pair in M.items():
        if path in ['.tfw/project_config.yaml','KNOWLEDGE.md'] or not pair['intended']['present']:continue
        if matches(R/path,pair['intended']):continue
        guard();assert not conflicts();assert matches(R/path,pair['old'])
        if path in P['source_payload']:assert sha(git(S,'show',P['target']+':'+path).stdout)==pair['intended']['sha256']
        dst=R/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((A/'intended'/path).read_bytes());assert matches(dst,pair['intended']);writes.append({'path':path,'at':now(),'after':identity(dst)})
    adapters()
    for path in P['retired_paths']:
        guard();assert not conflicts();dst=(R/path).resolve();assert dst.is_relative_to(R.resolve()) and matches(dst,M[path]['old']);dst.unlink();writes.append({'path':path,'at':now(),'after':identity(dst)})
    guard();assert not conflicts();assert matches(R/'.tfw/project_config.yaml',M['.tfw/project_config.yaml']['old'])
    intermediate=(A/'intermediate-config.yaml').read_bytes();obj=yaml.load(intermediate,Loader=Unique)
    exp=json.loads(json.dumps(P['intended_config']));exp['tfw']['installed_from']=P['old_config']['tfw']['installed_from'];assert obj==exp
    (R/'.tfw/project_config.yaml').write_bytes(intermediate);writes.append({'path':'.tfw/project_config.yaml','phase':'retirement-old-provenance','at':now(),'after':identity(R/'.tfw/project_config.yaml')})
    guard();assert not conflicts();assert matches(R/'KNOWLEDGE.md',M['KNOWLEDGE.md']['old']);(R/'KNOWLEDGE.md').write_bytes((A/'intended/KNOWLEDGE.md').read_bytes());writes.append({'path':'KNOWLEDGE.md','at':now(),'after':identity(R/'KNOWLEDGE.md')})
    adapters();retained();assert config()==exp
    for path,pair in M.items():
        if path!='.tfw/project_config.yaml':assert matches(R/path,pair['intended']),path
    guard();assert not conflicts();assert (R/'.tfw/project_config.yaml').read_bytes()==intermediate
    (R/'.tfw/project_config.yaml').write_bytes((A/'intended/.tfw/project_config.yaml').read_bytes());writes.append({'path':'.tfw/project_config.yaml','phase':'verified-provenance','at':now(),'after':identity(R/'.tfw/project_config.yaml')})
    assert config()==P['intended_config'];adapters();retained();source_all()
    for path,pair in M.items():assert matches(R/path,pair['intended']),path
    git(R,'add','--all'); results=checks()
    changed=git(R,'diff','--cached','--name-only','-z').stdout.decode().split('\0');assert all(not p or p in pointer['actual_target_changes'] or p.startswith(pointer['preservation']+'/') for p in changed)
    out={'start':start,'verified_at':now(),'writes':writes,'unique_changed_targets':len(set(x['path'] for x in writes)),'checks':results,'after':snapshot(),'cleanup':{'observed_at':now(),'retained':'.tfw/.upstream/','reason':'finite exact pinned diagnostic source for this disposable assurance receiver; no deletion required','removed':[]},'limitations':P['limits'],'receipt':'not-yet-sealed'}
    dump('03-applied-verified.json',out);print(json.dumps({k:v for k,v in out.items() if k not in ['after','writes']},indent=2))
if __name__=='__main__':apply()
