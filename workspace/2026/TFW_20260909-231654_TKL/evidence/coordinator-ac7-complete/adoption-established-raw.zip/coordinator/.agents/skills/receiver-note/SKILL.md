---
name: receiver-note
description: Synthetic foreign neighbor retained by the update exercise.
---

Preserve the original neighbor bytes.
