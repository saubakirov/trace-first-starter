# Project knowledge - seeded receiver

## Current knowledge use

Use ordinary files and textual search. Inspect relevant scope, grounds, disposition, source and
producer before applying a claim. Search `knowledge/records/` for incoming successor, correction,
equivalence and conflict references to its exact identity; follow material chains in both directions.
Legacy targets use exact path plus D/F/heading and source epoch. Scoped successors replace only
their stated scope; unchanged accepted claims remain applicable. Unresolved conflict names the
missing authorized decision. No generated index, original chat or task-archive sweep is required.

## 1. Architecture Map

Offline reference receiver for a bounded adoption exercise.

### Architecture Decisions

| ID | Decision | Source |
|---|---|---|
| D1 | Synthetic prior reference: preserve the token ALPHA exactly; no real accepted decision is asserted. | [Original](sources/legacy-observation.md#example) |

## 2. Key Artifacts

[Seeded source](sources/legacy-observation.md) and [legacy topic](knowledge/domain.md).

## 3. Legacy & Deprecation

The seeded D1 and F1 identities, source paths and example URL remain historical fixture meaning.

## 4. Project Facts

[Domain](knowledge/domain.md) remains the legacy category route.

New qualified claims use independently addressable records under `knowledge/records/`; producing roles retain their actual source and acceptance. Existing D/F rows and category/source routes keep their original meaning. No new record or processing is authorized by this update.
