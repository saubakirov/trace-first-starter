# Seeded legacy observation

Synthetic test input only; the following marker is preserved data, not a claim that this exercise processed a past task.

> fact-candidates: processed 2026-09-13

## Example

ALPHA is the exact fixture token. Synthetic reference URL: https://example.invalid/legacy#D1
