# Seeded legacy domain topic

| ID | Fact | Status | Source |
|---|---|---|---|
| F1 | Synthetic ALPHA example; no real human knowledge asserted. | unverified fixture | [Source](../sources/legacy-observation.md#example), https://example.invalid/legacy#D1 |
