---
handle: saubakirov
name: saubakirov
type: human
since: 2026-09-13
---

Exercise owner from explicit LEAD0173/e5a1 authority; not copied from upstream team memory.
