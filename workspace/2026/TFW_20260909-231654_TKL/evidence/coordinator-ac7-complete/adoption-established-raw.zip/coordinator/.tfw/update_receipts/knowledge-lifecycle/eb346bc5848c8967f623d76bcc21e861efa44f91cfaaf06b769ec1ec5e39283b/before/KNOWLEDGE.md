# Project knowledge - seeded receiver

## 1. Architecture Map

Offline reference receiver for a bounded adoption exercise.

### Architecture Decisions

| ID | Decision | Source |
|---|---|---|
| D1 | Synthetic prior reference: preserve the token ALPHA exactly; no real accepted decision is asserted. | [Original](sources/legacy-observation.md#example) |

## 2. Key Artifacts

[Seeded source](sources/legacy-observation.md) and [legacy topic](knowledge/domain.md).

## 3. Legacy & Deprecation

The seeded D1 and F1 identities, source paths and example URL remain historical fixture meaning.

## 4. Project Facts

[Domain](knowledge/domain.md) remains the legacy category route.
Total facts: 1 (synthetic fixture count).
Maintain a counted inventory of every fact here.
