from run_adoption import *
import uuid
receipt=json.loads((E/'04-sealed-receipt.json').read_text());rp=R/receipt['path'];assert matches(rp,receipt['identity'])
outcome='Actual adoption completed in the seeded established receiver. Compatible knowledge readers are installed; 33 target paths changed and four retired live settings removed. Legacy sources, links, inert state and project choices were preserved. Receiver checks passed. Untagged Candidate '+P['target']+' only; no release/publication. Next: one unchanged repeat and one prepared later-field refusal.'
dump('06-adoption-outcome.json',{'rendered_at':now(),'receipt':receipt,'text':outcome,'delivery_evidence':'Coordinator native commentary separately reports actual outcome; no owner comprehension claim','sealed_receipt_unchanged':matches(rp,receipt['identity'])})
start=now();before=snapshot();guard();source_all();assert not conflicts();adapters();retained();assert config()==P['intended_config']
for path,pair in M.items():assert matches(R/path,pair['intended']),path
for path in ['.tfw/workflows/update.md','.tfw/migrations/3.3.0.md','.tfw/migrations/knowledge-lifecycle.md']:
    assert (R/'.tfw/.upstream'/path).read_bytes()==git(S,'show',P['target']+':'+path).stdout
assert matches(rp,receipt['identity']);assert json.loads((E/'06-adoption-outcome.json').read_text())['text']==outcome
check=checks();after=snapshot();assert before==after
dump('07-unchanged-repeat.json',{'start':start,'finished_at':now(),'outcome':'VERIFIED unchanged completed repeat; zero receiver writes, zero new receipt, no inventory/promotion or question','before':before,'after':after,'path_byte_identical':True,'checks':check,'receipt':receipt,'cleanup':'Pinned staging remains retained and byte-identical; disposition reobserved','original_outcome_reobserved':True,'source':P['target'],'authority_objects':P['authority_objects']})
print('REPEAT VERIFIED '+now())
guard();prepare=now();base=(R/'.tfw/project_config.yaml').read_bytes();assert b'\n  knowledge:' not in base
assert base.count(b'\ntfw:\n')==1
injected=base.replace(b'\ntfw:\n',b'\ntfw:\n  knowledge:\n    interval: 17\n')
(R/'.tfw/project_config.yaml').write_bytes(injected)
note=R/'later-notes.md';assert not note.exists();note.write_text('# Prepared later work\n\nSynthetic unrelated later note. Preserve these exact bytes during the refusal case.\n',encoding='utf-8')
assert config()['tfw']['knowledge']['interval']==17
pre=snapshot();dump('08-prepared-later-field.json',{'prepared_at':prepare,'observed_at':now(),'prepared_not_crash':True,'field':'tfw.knowledge.interval','old':5,'intended':'absent','Z':17,'later_note':identity(note),'config_before_preparation':{'sha256':sha(base),'bytes':len(base)},'snapshot_before_invocation':pre})
start=now();guard();source_all();actual_conflicts=conflicts()
assert len(actual_conflicts)==1 and actual_conflicts[0]['field']=='tfw.knowledge.interval' and actual_conflicts[0]['actual']=={'present':True,'value':17},actual_conflicts
assert snapshot()==pre
assert matches(rp,receipt['identity']);adapters();retained()
checked=checks();assert snapshot()==pre
at=now();aid='UPDATE__'+datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=5))).strftime('%Y%m%d-%H%M%S')+'__'+uuid.uuid4().hex[:4];ref=R/'.tfw/update_receipts'/(aid+'.md');assert not ref.exists()
body=f'''---
kind: update_receipt
attempt_id: {aid}
recorded_at: {at}
writer: robert
---

# Update Receipt - `{aid}`

Immutable actual refusal of one prepared later-field input. This is a labelled synthetic conflict, not an observed crash or a real user's later change. Earlier successful adoption and unchanged repeat remain preserved.

## 1. Pinned source and receiver

| Field | Value |
|---|---|
| Receiver root | `{R.as_posix()}` |
| Receiver baseline | Successful adoption `60066bf1143da33fad12102c0c17163501abd631` plus explicitly prepared config interval 17 and `later-notes.md`; exact snapshot in `{(E/'08-prepared-later-field.json').as_posix()}` |
| Source ref | Explicit immutable untagged commit `{P['target']}` |
| Source full SHA | `{P['target']}` |
| Source provenance | Local configured steps-framework at `{S.as_posix()}`; version 3.3.0 and installed_from `steps-framework@{P['target']}` reobserved; no release tag |
| Target workflow read | Pinned `.tfw/workflows/update.md`, `.tfw/migrations/3.3.0.md`, `.tfw/migrations/knowledge-lifecycle.md`; exact source/authority bytes rechecked at this invocation |
| Attempt time | Refusal preflight started {start}; refusal and preserved-byte check observed before sealing {at}; deadline {D.isoformat()} |

## 2. Authority and semantic groups

| Question | Answer |
|---|---|
| Acting handle and role | robert, Coordinator task `01a09974-6716-7cc0-9916-fd6d04c91481` |
| Acceptance authority | saubakirov through LEAD0173 `144e3e651382330afba4d7131a562d05e7f515f9` and e5a1 `1c6a9bd7ae9709944b3260af4c1f084a8501dce9`; immutable hashes in original preservation |
| Governing task/phase | `TFW_20260909-231654_TKL` AC7, exactly one prepared later-field refusal after completed adoption and unchanged repeat |
| Groups inspected together | Knowledge compatible readers/adapters/config/entry/provenance; no affected SLC group; exact original preservation reused |
| Material questions | Concrete conflict: tfw.knowledge.interval is 17, preserved old 5, intended absent. No authority to overwrite Z. Preserve it and route any real future disposition to owner through LEAD; no question needed to erase this prepared test input because erasure is not requested |

## 3. Decision and effects

| Effect | Exact paths/groups | Decision | Reason and authority |
|---|---|---|---|
| Applied | Only this append-only refusal receipt | No target application, repair, rollback or provenance change | Third-value predicate stops the connected operation before any target write |
| Preserved | `.tfw/project_config.yaml` including interval 17; `later-notes.md`; all reader/adapter/entry/state/topic/source/marker/purpose files, original before-image and prior receipt | Exact invocation snapshot unchanged before this new receipt; legacy and unrelated later bytes retained | Pinned guide third-value rule; original old/intended attachment `{pointer['preservation']}`. Root README remains explicitly synthetic project purpose, `PRESERVE_BYTES`; framework README equal owned target, no write |
| Skipped | Upstream live project config/state, root/team/knowledge/tasks/tools/tests/other content, upstream receipts and attachments, unselected provider roots; connected target application | No copying or config merge | Source payload exclusions and refusal boundary; no project-history sweep, new accepted record or consolidation |
| Refused | Connected knowledge reader/adapter/config/entry/provenance operation | REFUSED because `tfw.knowledge.interval` equals Z=17, old=5, intended=absent | Exact present field is outside original old/intended values; prior receipt or equal version does not authorize rollback |

## 4. Verification

| Check | Result | Artifact or command |
|---|---|---|
| Source integrity and provenance | VERIFIED | Full Candidate, all 73 staged source bytes, guide bytes, clean upstream .tfw, root and both authority objects rechecked |
| Receiver state/config exclusions | VERIFIED | Invocation raw snapshot identical after refusal preflight/checks; Z and unrelated later note preserved; config semantic parsing rejects duplicate keys |
| Connected-group consistency | BLOCKED | Exactly one conflict, tfw.knowledge.interval=17; refusal expected for this prepared input. No target write attempted; this is not a positive adoption result |
| Adapter/runtime surface | VERIFIED | Installed 11 selected command copies and one block remain exact; four-adapter manifest/11 routes and roles resolve; no helper/runtime installed |
| Maintainer checks | N/A | No source implementation change or receiver compiler; upstream suite not a receiver prerequisite |
| Receiver proof | VERIFIED | Configured git diff --check and git fsck --no-dangling plus cached diff --check exited 0; before/after bytes and path set identical before receipt creation; evidence `{(E/'09-later-field-refusal.json').as_posix()}` |

## 5. Cleanup, continuation, and final-message input

- Temporary files/worktrees removed or retained: `.tfw/.upstream/` retained as exact pinned diagnostic source; all original preservation and prepared conflict/later note retained. No destructive cleanup or whole-map rollback.
- Cleanup resolution/disclosure observed before sealing: retained source and complete snapshot rechecked at {at}; no deletion performed.
- Unresolved material items: prepared Z intentionally remains; no receiver continuation beyond refusal is authorized by this test. Auxiliary README link and synthetic-history limitations remain.
- Next authoritative action: Coordinator preserves custody and routes actual AC7 evidence for outer independent review; a real future owner change of Z would need its own decision. No self-extension of the epoch.
- Final message delivery at receipt time: `planned/not-yet-observed`
- Final message inputs: unchanged repeat verified with zero receiver writes; prepared later-field invocation refused before target writes, preserving interval 17 and unrelated note. No claim of real crash, human acceptance or comprehension.
- Attachments/evidence: `{pointer['preservation']}/preservation.json` and physical old/intended bytes; prior receipt `{receipt['path']}`; external `07-unchanged-repeat.json`, `08-prepared-later-field.json`, `09-later-field-refusal.json` under `{E.as_posix()}`.
'''
ref.write_text(body,encoding='utf-8');assert ref.read_text(encoding='utf-8')==body
post=snapshot();assert {k:v for k,v in post.items() if k!=ref.relative_to(R).as_posix()}==pre
dump('09-later-field-refusal.json',{'start':start,'finished_at':now(),'outcome':'REFUSED connected group before target writes; preserved prepared Z and unrelated later work','conflicts':actual_conflicts,'checks':checked,'before':pre,'after':post,'only_new_path':ref.relative_to(R).as_posix(),'receipt':identity(ref),'target_writes':0,'prepared_not_crash':True,'earlier_receipt_unchanged':matches(rp,receipt['identity']),'authority_objects':P['authority_objects'],'source':P['target']})
print('REFUSAL SEALED '+now());print((R/'.tfw/templates/briefing.md').read_text(encoding='utf-8'))
dump('10-refusal-outcome.json',{'rendered_at':now(),'receipt':ref.relative_to(R).as_posix(),'receipt_identity':identity(ref),'text':'Unchanged completed repeat verified with zero receiver writes. Prepared interval 17 was refused before any target write; the conflicting value and unrelated later note were preserved. Next: retain this evidence for outer independent review. No real-crash, historical acceptance, publication or comprehension claim.'})
git(R,'add','--all');checks();git(R,'commit','-m','TFW_20260909-231654_TKL: preserve actual unchanged repeat and prepared later-field refusal');assert not git(R,'status','--porcelain').stdout
dump('11-final-receiver.json',{'at':now(),'head':git(R,'rev-parse','HEAD').stdout.decode().strip(),'clean':True,'positive_adoption':'60066bf1143da33fad12102c0c17163501abd631','repeat':'07-unchanged-repeat.json','refusal':'09-later-field-refusal.json','receipt_before_after_identity':matches(rp,receipt['identity']),'deadline':D.isoformat(),'all_completed_before_deadline':datetime.datetime.now(datetime.timezone.utc)<D})
print((E/'11-final-receiver.json').read_text())
