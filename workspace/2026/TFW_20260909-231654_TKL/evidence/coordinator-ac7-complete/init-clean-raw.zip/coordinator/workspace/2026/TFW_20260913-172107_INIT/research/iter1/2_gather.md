# Gather — Separate acquired source, receiver state and future acceptance

> **Mindset:** Explorer; map actual evidence and gaps within this one receiver.
> Goal: establish the source, semantic setup and closure evidence needed for the bounded Full initialization.
> Authority, role, purpose and prior exposure: [Briefing](1_briefing.md). Producer: robert, Researcher `01a0995f-6132-7c92-86d3-c5388827a8cd`; direct parent/recipient: operational Coordinator `01a09974-6716-7cc0-9916-fd6d04c91481`.
> Gather-only ruling: [dispatch bdc1](../../journal/20260913-173708__dispatch__bdc1.md), clean input `48623ad3c3c79ce3984aa9b177afdbe26d9cc191`. Standalone init; HL-only inputs remain N/A.

## Dimensions

There are fewer than three independent choices: receiver purpose, source, adapter, human owner and role sequence are already fixed by authority. The remaining research distinction is **evidence coverage**: acquisition identity, current receiver semantics, or completed setup/acceptance behavior. Use the comparison matrix below; do not turn unauthorized source substitution or skipped review into architecture alternatives.

## Findings

### G1. Acquisition matches the pinned framework after the prescribed exclusions

Read [quickstart](../../../../../.tfw/quickstart.md), its Full acquisition lines 26–32, and the actual receiver files. Quickstart excludes upstream live config, knowledge state, update receipts, upstream cache, team, task/knowledge state, root project files and maintainer tools/tests; init creates local config and knowledge from clean forms.

At exact Candidate `27cdb701b91c5b45b9f54b3e98c9ad67635b3e30`, `git ls-tree -rz --full-tree <pin> -- .tfw` in upstream `C:/Users/c0rpa/.codex/worktrees/01b7/steps-framework` listed 80 source files. A read-only comparison hashed every receiver `.tfw/` file as a raw Git blob, including its byte length; it used no checkout filter or text normalization. Result: 74 receiver files, 73 exact source-byte matches, no extra framework path, and one expected difference: local `.tfw/project_config.yaml`. Six omitted source paths comprise `.tfw/knowledge_state.yaml` and all five files under upstream `.tfw/update_receipts/`. Together with replacing rather than copying live config, these match the prescribed state exclusions. No excluded file content was imported or used as receiver memory.

The local config's SHA-256 is `0a047689af0b32faf5350653ea555e299a704bb3b54d5c3121fa7888fef20fda`; its raw blob is `44b530b28fa839d46134befd59e206c102c00ca3`, distinct from upstream live-config blob `d821fe17a0f2fc9aba03b3f87ebab27b241743e3`. This difference is necessary receiver ownership, not source drift. `KNOWLEDGE.md` equals the clean `.tfw/templates/KNOWLEDGE.md` byte for byte, SHA-256 `fe8cdc199c8b314548198b3104c47755df7f9f17c8a12869b604b97614a01541`.

The filesystem inventory outside `.tfw/` and the Git metadata pointer contains exactly 11 files at this input: root README and knowledge entry, one human profile, current INIT status, four journal events, iteration registry and the existing Briefing. `tools/`, `tests/`, `tasks/`, `history/`, `RELEASE.md`, `.user_preferences.md`, `.tfw/.upstream`, knowledge state and update receipts are absent. There is no project `knowledge/records/` directory or qualified project record yet; the clean entry explicitly says no facts/decisions have been qualified. This absence is not evidence of a lost contributor or a reason to fabricate a record. No application runtime or upstream task corpus appears in the inspected receiver.

The [official Git ls-tree reference](https://git-scm.com/docs/git-ls-tree), opened 2026-09-13, documents tree-object entries and NUL-delimited unquoted paths. It supports the bounded source inventory method; byte identity is a separate observed comparison, not a claim that Git validates init semantics. Mechanical hashing of 74 payload files exceeds the soft 15-file stage guideline for the specific approved source-equality question; it does not preload their semantic contents or expand the product scope.

### G2. Current config/control checks support Mini-Setup, not Full completion

The host observer used PyYAML 6.0.3 with duplicate-key rejection to compare the local config against its clean template and inspect selected YAML/frontmatter. This is external research tooling; no package, script or runtime prerequisite was added to the receiver.

| Checked subject | Actual result | Limit |
|---|---|---|
| Config differences from template | Exactly eight: project name/repo/branch, `tfw.upstream`, `installed_from`, `task_prefix`, and two build commands | These are current authorized receiver values; this is not a final update/Full Setup check |
| Framework config structure | Other parsed values equal the template; active paths `[workspace]`; exact three scope-budget keys; configured template/workflow paths exist | No historical or retired runtime/knowledge keys were introduced |
| Version/provenance | `.tfw/VERSION` and config agree at 3.3.0; `installed_from` identifies exact untagged Candidate | Equal version alone would not establish source equality; G1 supplies the actual bytes |
| Knowledge entry | Byte-identical clean template, no qualified claim | No publication, capture qualification or accepted project fact is inferred |
| Task and profile | Actual ID matches directory; RES; owner saubakirov; one human profile with matching handle; status authority resolves to root README; created is not later than updated | No HL/TS is required or fabricated for canonical init |
| Four journal records | Parse without duplicate keys; human `on_behalf_of`, Codex `via`, optional writer absent; every declared task-relative ref resolves | These are created/dispatch records, not a performed RF transition |
| Current research registry | Iteration 1 in progress, minimum 2 / maximum 2 | Updated by the Coordinator in bdc1, not this Researcher |

The eight values are `TKL isolated receiver assurance`, `local-assurance`, `codex/tkl-init-coordinator`, symbolic upstream `steps-framework`, the pinned installed-from value, prefix `TFW`, lint `git diff --check`, and test `git fsck --no-dangling`. The configured branch describes the receiver's Coordinator branch; this Researcher's separate worktree branch does not authorize changing it. The two Git commands were inspected, not run as a claim of completed init verification.

### G3. Adapter sources exist; installation and repeat remain owed

The [adapter manifest](../../../../../.tfw/adapters/manifest.yaml) was inspected as the exact copy-map evidence selected by this source/adapter question, not as runtime role authority. Its Codex persistent source resolves to `.tfw/adapters/codex/AGENTS.md.template`; all 11 command source files and canonical workflow targets exist. The command routes are unique. Roles are Coordinator for plan/resume/docs/knowledge/release/update/config/init, Researcher for research, Executor for handoff and Reviewer for review.

`AGENTS.md` and all `.agents/skills/tfw-*/SKILL.md` destination files are absent in this research-stage input, consistent with Full Setup still ahead. Source existence and G1 byte identity do not prove installation. The Coordinator must later verify the actual managed block, selected copy bytes, complete route/role mappings, preserved foreign neighbors where present and unchanged repeat. The Researcher installed nothing and did not read unselected adapter instructions.

| Evidence approach | Useful coverage | Insufficient on its own |
|---|---|---|
| Pinned tree plus raw byte comparison | Acquisition identity and prescribed exclusions | Project-purpose and control correctness |
| Parsed config/control/profile and relevant source reading | Present semantics and exact governing routes | Installed adapter behavior, idempotence or acceptance |
| Future actual Full Setup output, repeat and independent RF review | Completed delivered effects and justified limitations | Cannot be asserted before the named owners perform it |

### G4. Required root routes resolve; two inherited auxiliary targets do not

Root README bytes are unchanged from intake `e25422e6f95e414e4d341951940742bb699a6647`, SHA-256 `081f6a6a4c2b9f8c9333f5045fa6e1c9579c170b9e42b3b0c658a7f258ead013`. All four local references resolve: framework method, canonical init command, project knowledge and the selected INIT trace. Its release absence and assurance-only purpose remain explicit.

Framework `.tfw/README.md` also matches intake and Candidate bytes, SHA-256 `05f440703a174082ab246212116ee3c73501fd804ed037fd0aaf1515a6cc7798`. Of its ten local Markdown/HTML reference occurrences, two distinct target paths do not exist in this Full payload: `../docs/brand/philosophy.png` and `../editions/README.md` (the latter appears more than once). This is an actual inherited auxiliary navigation limitation, not a broken required root route or an altered source. It prevents a claim that every framework README reference is locally usable. Preserve it for the Coordinator's bounded disposition and later independent init review; do not silently copy extra upstream content, repair VALUE or assume that byte equality pays the limitation.

### G5. The settled transition ruling still needs future exact evidence

Briefing preserves actual LEAD c183 at `de859a575e2f24c047257532e38d0f195460598d`. Gather's acquisition checks confirm `tools/` is outside this receiver; canonical init and its source remain exact Candidate bytes. Thus the identified helper is external maintainer assurance, not a receiver dependency. The scoped authority decision remains settled: direct RES-to-RF only at the actual init checkpoint after research and Full Setup, with complete carriers/refs and only the exact expected inherited helper error. Any additional error stops. No helper PASS, transition write or independent acceptance occurred in this Gather. The Coordinator retains that limitation in RF for the actual Reviewer.

## Timing and handover

First observed continuation stamp: 12:37:44.4904261 UTC on 2026-09-13. Actual source inventory/hash read completed at 12:39:23.5160457; config/control/adapter-source checks at 12:41:18.6991869; root/framework reference check at 12:41:52.5297061. The preceding Briefing WAIT began 12:36:32 and bdc1 approval is dated 12:37:08, an identified 36-second interval; no deduction is applied. Combined clock remains conservatively measured from 12:17:59.851010 UTC. Exact stage commit and next WAIT timestamp are returned directly.

This stage preserves source/version, actual producer, inspected context, positive checks, the auxiliary-link limitation and still-owed setup/transition/review evidence. No material private context is claimed lost. New exposure is the source inventory, config template, copy map, framework README, selected current controls and primary Git documentation; no AC10 fixture/oracle/question/answer-specific path was received. Initial raw inventory output used an overbroad `outside_framework` label while listing all tracked files; the subsequent filesystem inventory above correctly separates the 11 non-framework files. No source conclusion relies on that initial label, and no receiver file changed during inspection.

## Checkpoint

| Found | Remaining |
|---|---|
| 73 exact framework files, correct live-state exclusions and template-derived receiver config/knowledge | Full Setup's actual adapter/root outputs and repeat |
| Present owner/status/authority and journal references are coherent | Complete future RF transition evidence under c183 and independent review |
| Required root navigation works; two inherited auxiliary target paths are absent | Explicit bounded disposition of that limitation, without unapproved copying or repair |

OBSERVE: exact Candidate tree, working bytes, parsed current controls, copy map, root/reference targets and primary documentation. ORIENT: source equality, semantic validity and completed acceptance are different evidence layers. DECIDE: use a compact evidence-coverage comparison; preserve the concrete auxiliary-link observation and settled helper limit. ACT: return this committed Gather to the operational Coordinator, then WAIT for its ruling before Extract.

External source used: YES. Briefing gap closed for source/current-state mapping: YES. Fewer-than-three-dimensions comparison matrix used: YES. Stage complete: YES. Extract, setup, lifecycle changes and acceptance are not authorized by this file.
