# Extract — What the present evidence covers, and what still must happen

> **Mindset:** Analyst; organize evidence without inventing another design choice or future result.
> Goal: make the minimum remaining Full-init verification and its limits explicit.
> Producer/lineage/exposure: [Briefing](1_briefing.md). Same Researcher `01a0995f-6132-7c92-86d3-c5388827a8cd`, principal robert for owner saubakirov; direct parent/recipient `01a09974-6716-7cc0-9916-fd6d04c91481`.
> Exact Extract-only control: `6645deb24b7bcf8aa0a64f82ff69f0ae78acb35c`, [dispatch ad35](../../journal/20260913-174552__dispatch__ad35.md). Input findings: [Gather](2_gather.md), producer `452d6fadc6507e2f22f51b6fa6fd8756c38dbb98`.

## Configuration Space

Gather had fewer than three independent dimensions. Use its **evidence coverage** comparison rather than a fictitious architecture cube. These are levels of available evidence, not alternatives authorizing skipped duties.

| Evidence coverage | Included subject | Still outside that evidence |
|---|---|---|
| Acquisition identity | Exact Candidate files, exclusions and clean forms | Receiver semantics and future setup effects |
| Acquisition plus current semantics | Above, plus actual purpose/config/control/profile/reference state | Installed adapter output, unchanged repeat, qualified closure and independent verdict |
| Above plus completed setup and acceptance | Actual later effects and the corresponding independent review | Other receivers, arbitrary foreign content, provider reliability and the future AC10 first answer |

## Findings

### E1. Observed / required / unobserved matrix

| Subject | Observed at Gather / current control | Required consequence | Not yet observed; existing owner |
|---|---|---|---|
| Framework source | 73 raw-byte matches; only receiver config differs; upstream state/receipts excluded | Retain exact pinned source and truthful installed-from identity through setup | Any later changed source/output needs its affected check; Coordinator |
| Project purpose and roots | Root README preserved and its four selected links resolve | Preserve its assurance purpose, human owner and real routes through setup/repeat | Post-setup preservation; Coordinator, then independent Reviewer |
| Config and controls | Eight authorized template differences; current RES, owner and refs coherent | Preserve selected project values and update state only at the actual legal checkpoint | Final semantic config and real RF event/bytes; Coordinator |
| Knowledge | Clean entry equals template; no project record or legacy corpus | Use approved research findings only where warranted; preserve stage sources and actual qualification/disposition | Applicable final knowledge effect or justified absence; Coordinator. No automatic fact/record publication is owed merely to fill a template |
| Codex adapter | Persistent source and 11 command sources/workflow paths exist; destinations absent | Install one actual managed block and all exact command copies with correct roles/routes | Target bytes, block count, local route application and repeat; Coordinator |
| Foreign neighbors | No pre-existing root AGENTS.md or installed skill neighbors in this clean receiver | State N/A for preservation of those absent neighbors here | Preservation of real foreign neighbors in another receiver is untested, not PASS; that receiver's separate bounded owner |
| Auxiliary method navigation | Two distinct missing Candidate README targets: illustration and Editions | Preserve Candidate bytes and carry exact limitation into RES/init RF | Independent sufficiency decision; actual Reviewer, after Coordinator reporting |
| Init transition/helper | c183 precedence settled; helper excluded from receiver | After research and Full Setup, validate full proposed carriers, require only exact inherited RES-to-RF helper error, preserve actual write order/evidence | Real preflight/write/readback and reported limitation; Coordinator. No helper PASS |
| Review and close | Current status remains RES; no actual init RF or REVIEW | Actual init RF/output, independent verdict and applicable knowledge effects before filled DONE outcome | Same assigned Reviewer judges; Coordinator closes only after applicable acceptance |

Absence of AGENTS neighbors does not erase the real root README preservation obligation. Source/control checks are reusable for unchanged inputs; they do not certify later writes in advance. The Coordinator has accepted the research handover, not independently accepted init.

### E2. Minimum affected checks for the later owners

These are bounded verification obligations derived from actual [init](../../../../../.tfw/workflows/init.md), Gather evidence and scoped c183, not an execution script or a new test platform.

1. **Fix the checked subject.** Identify the completed setup revision and actual selected file set. Recheck changed config, root and knowledge meaning/bytes against approved receiver values and applicable source. Reuse G1 acquisition evidence only while its relevant bytes and source remain unchanged.
2. **Verify actual adapter output.** Inspect the single managed `TFW:CODEX` block and all 11 installed command files. Compare exact copy bytes to the selected Candidate sources, check unique literal routes and canonical workflow targets/roles, and report missing/extra blocks or paths. Source existence alone remains insufficient.
3. **Observe one relevant unchanged repeat.** Compare the installed path set, raw output bytes, managed-block count and protected project/control bytes before and after the actual selected adapter repeat. A repeat must follow configured-receiver attach/repair semantics, not recreate Full-init state or rerun research. Include untracked/path-set changes; an unchanged tracked diff alone can miss new files. This does not demonstrate preservation of absent foreign neighbors or another receiver's adoption/refusal behavior.
4. **Verify the real state handoff at its checkpoint.** Under c183, check proposed RF status/event identity, declared vocabulary, human accountability, profile, monotonic times and every local reference. Preserve the helper result exactly, with only its named inherited RES-to-RF error permitted. Additional errors stop. Only the actual Coordinator writes status then the immutable event and checks resulting carriers. This research does not perform the transition.
5. **Carry complete evidence to the same independent Reviewer.** Init RF names actual changes/results, producing-role returns and unresolved/limited claims, including both auxiliary targets and the inherited helper limitation. Reviewer assesses the actual RF/output; approval is not inferred from the Coordinator's stage rulings. The subsequent actual close checks acceptance and applicable knowledge effects and records a filled outcome.

The Codex [persistent source](../../../../../.tfw/adapters/codex/AGENTS.md.template) and [research skill source](../../../../../.tfw/adapters/codex/skills/tfw-research/SKILL.md) were read narrowly in this stage. The former is exactly one bounded managed block with 11 command routes; the latter dispatches the canonical research workflow and preserves Researcher Role Lock and WAIT/STOP gates. They specify what must later be present; neither is an installed adapter result in this input.

Primary external cross-check: [official Git diff documentation](https://git-scm.com/docs/git-diff), opened 2026-09-13, distinguishes whitespace/conflict-marker checking via `--check` from reporting whether compared content differs via `--exit-code`. Research inference: a successful whitespace check cannot stand in for repeat equality, path coverage or semantic checks. Actual bytes/path sets and the relevant state must be compared for their own claims. No repeat or configured final build check was run during Extract.

### E3. Reporting boundaries that remain useful

The auxiliary targets are **retained limitations**, not fixed, waived or paid. Dispatch ad35 expressly preserves exact Candidate bytes and sends their sufficiency question to the independent Reviewer; it authorizes no extra source copy. Likewise c183 gives this receiver-specific execution precedence, not a helper PASS or acceptance verdict.

A justified-none knowledge outcome must name the inspected role/source scope and reason; no project record directory, extra human fact or copied upstream memory is needed just to make an empty route look populated. A real required decision or missing source remains explicit with its existing owner. Here the available material research findings already live in Briefing/Gather/Extract and must reach the Coordinator; no private-context reconstruction is claimed.

The most useful remaining distinction is **permission versus observed effect**: authorization for Full Setup, a direct transition or review does not show it happened. Conversely, a helper's inherited graph omission does not authorize an invented HL/TS/ONB chain. These boundaries can be attacked in Challenge without exercising another receiver or widening product scope.

## Timing and handover

First observed Extract-continuation stamp: 2026-09-13 12:46:42.6248346 UTC. Focused template/current status/registry and exact control were read after a clean fast-forward; selected Codex source reads and the primary-reference epoch were recorded at 12:47:18.5583671 UTC. The preceding Gather WAIT was 12:45:13 to ad35 approval 12:45:52, an identified 39 seconds with no deduction. Combined conservative clock still begins 12:17:59.851010 UTC.

No new receiver defect, failed execution attempt or private-context gap was observed during this analytical stage. Previous observer errors and limitations remain in their original sources. New exposure is limited to this control, the selected Codex source block/skill and primary Git documentation; no AC10 fixture, oracle, question or answer-specific path was supplied. Only this research stage is authored. Exact commit/readback and next authority WAIT time are returned directly.

## Checkpoint

| Found | Remaining |
|---|---|
| Acquisition, current semantics and completed acceptance have different evidence scopes | Challenge must test the proposed sufficiency boundaries |
| Five bounded affected-check obligations cover the still-owed setup/repeat/handoff/review work | Actual later owner execution and independent verdict remain future |
| Clean-receiver N/A and both retained limitations are explicit | No cross-receiver preservation, all-links success or helper PASS can be inferred |

OBSERVE: accepted Gather, actual ad35/c183 scope, selected source forms and primary diff semantics. ORIENT: separate present observations from required effects and independent acceptance. DECIDE: retain the evidence-coverage matrix and minimum affected checks within the existing owners' work. ACT: return the committed Extract directly and WAIT for the Coordinator's ruling before Challenge.

External source used: YES. Briefing gap closed for verification structure: YES. Structured comparison built from Gather's below-three-dimensions exception: YES. Stage complete: YES. No Challenge, setup, state, RF, REVIEW or product write is authorized by this file.
