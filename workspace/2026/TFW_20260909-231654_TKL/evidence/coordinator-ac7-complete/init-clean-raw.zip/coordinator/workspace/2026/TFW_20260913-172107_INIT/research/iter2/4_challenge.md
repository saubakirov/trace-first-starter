# Challenge — Preserve applicable obligations under d642
> **Mindset:** Critic; focused, one pass.
> **Goal:** Evaluate the three assigned hypotheses without converting form coverage, source evidence or scoped authority into completed init acceptance.
> **Parent:** [status](../../status.md), [Briefing hypotheses](1_briefing.md), [Gather](2_gather.md), [Extract](3_extract.md), [Challenge ruling](../../journal/20260913-183829__dispatch__c641.md). Local HL/TS/ONB absence is explicit; actual outer obligations remain under d642.

## Consistency Check

Use Extract's exact dimension names and A/B/C meanings from Gather. All three dimension pairs were considered. The 27 combinations are analytical representation coverage, not executed fixtures, tests or a reliability result. For evaluation, each claimed disposition must retain its exact subject: combining unrelated fields cannot justify a contradictory status for one obligation.

**Incompatible pairs:**

| Dimension A | Alternative | Dimension B | Alternative | Why incompatible |
|---|---|---|---|---|
| Authority for a required input | B: explicit inapplicability | Evidence timing and coverage | B: unperformed effect deferred | The same obligation cannot both be not owed and still owed but unperformed. This eliminates C13–C15 as single-obligation dispositions. |
| Authority for a required input | B: explicit inapplicability | Evidence timing and coverage | C: required claim blocked | The same obligation cannot be declared inapplicable merely because its required proof/authority is missing. Eliminate C16–C18; d642 expressly bars missing outer facts becoming N/A. |
| Authority for a required input | A: actual authority exists | Evidence timing and coverage | C specifically because that same authority is missing | Contradictory on one authority/epoch. C07–C09 survive only for a different missing dependency, such as coverage/environment. |

Authority × Knowledge and Evidence × Knowledge have no additional unconditional incompatible pair. They require actual provenance: a human-qualified claim cannot be manufactured from a technical finding; a missing contributor cannot be covered by another bounded observation. A source observation may remain valid while the larger claim lacks a material contribution. These conditions constrain the following survivors; they are not blanket approvals.

**Surviving configurations:**

| Config | Authority for a required input | Evidence timing and coverage | Knowledge disposition | Notes |
|---|---|---|---|---|
| C01 / C02 / C03 | A | A | A / B / C respectively | Actual observation may be retained; human qualification needs its real source, and missing contribution limits the larger conclusion. |
| C04 / C05 / C06 | A | B | A / B / C respectively | Authorized future effect remains pending; another valid source/qualification does not execute it. |
| C07 / C08 / C09 | A | C | A / B / C respectively | Known authority with a different unresolved dependency; no PASS from permission alone. |
| C10 / C11 / C12 | B | A | A / B / C respectively | An observed, authority-grounded N/A reason; unavailable outer accounting is excluded from this route. |
| C19 / C20 / C21 | C | A | A / B / C respectively | An actual source can be observed while dependent authority is unresolved, as at Gather/8878. |
| C22 / C23 / C24 | C | B | A / B / C respectively | Waiting for actual authority/effect remains explicit; no favorable ruling inferred. |
| C25 / C26 / C27 | C | C | A / B / C respectively | An unresolved authority dependency remains blocked for dependent use; retain available sources. |

These 21 survivors are conditional analytical forms. Knowledge B has no newly found human candidate in this research; Knowledge C must identify a real material gap, not invent one or label an ordinary future stage a lost contribution. G3-A/B moved out of their pending authority epoch only through actual d642.

**Unexpected survivors:**

- C19: Gather's clause observations remain usable despite its then-unresolved interpretation; d642 resolves the authority without invalidating or rewriting that earlier evidence.
- C04: a valid ruling and retained technical findings coexist with unperformed setup. This explains why a complete research return can precede actual Full Setup without claiming that setup passed.

## Findings

### C1 — Hypotheses survive only within their actual scope

| Hypothesis from Briefing | Challenge result | Evidence and practical limit |
|---|---|---|
| H1: required forms can cite actual init authority and mark inapplicable HL/TS/accounting inputs without omitted sections | **Partially supported as worded; narrowed by d642** | Local HL/TS/ONB absence and every retained section/row are supported. A blanket receiver-accounting N/A interpretation is rejected: real outer accounting remains owed, and only a genuinely inapplicable metric can receive reasoned N/A. Gather G2/G3 and Extract E4 retain this distinction. |
| H2: handover/close rules can preserve technical findings and both limitations without invented human facts, records or acceptance | **Supported for representation** | Existing RF/REVIEW/stage handover, observations/disposition and closure sections carry the material. No new human fact warrants a filler candidate. Actual producer coverage, completed dispositions and independent judgment remain necessary; this is no retention-only or acceptance ruling. |
| H3: unperformed setup/review/close can be represented honestly without runtime or scope expansion | **Supported for representation** | EV statuses and REVIEW §6 retain pending effects and reasons; init/close rules require actual effects before DONE. d642 supplies existing-holder routes and outer governing inputs, not a receiver runtime, new local contract or permission to skip remaining work. |

### C2 — Attacks on false completion

| Analytical attack, not an executed test | Source-specific result |
|---|---|
| Remove accounting rows because this task has no local TS | Rejected by d642 and Gather's required RF §1/E-accounting/V-accounting mapping; outer accounting and all fields remain. |
| Copy the source Candidate SHA and claim accounting verified | Rejected: d642 also requires actual outer Baseline, literal 58-path selector, method and applicable evidence, with the same independent Reviewer. This research has not replayed or enumerated them. |
| Use d642's creation time as if this Researcher already knew it at Gather/8878 | Rejected by the actual epoch: source 13:27:40Z, Researcher post-read observation 13:31:13.2346738Z. Earlier uncertainty remains recorded; a proposal or sent escalation was not the ruling. |
| Treat upstream copied Gather, an empty section or this return as the Reviewer's contribution | Rejected by actual-producing-role handover rules. Copying preserves a source; it neither creates an independent producer nor supplies that producer's judgment. |
| Mark both inherited limitations paid/immaterial because they are disclosed | Rejected: missing auxiliary README targets and helper transition mismatch remain explicit for the same Reviewer's consequence judgment and authorized dispositions. c183's expected-only preflight/real carrier obligations remain actual future work. |
| Count all 27 combinations, prepared setup script or research approvals as a passing init | Rejected: combinations are analysis; the script is reported prepared only; stage rulings authorize continuation. Full Setup, real checks/transition, actual RF/EV, independent review and applicable closure effects remain pending. |
| Use init APPROVE as outer TKL acceptance or REVISE to invent local TS/ONB/state changes | Rejected by d642's exact routes: receiver APPROVE may enter KNW, followed by actual Coordinator closure; REVISE creates no local TS/ONB and no receiver state move. Outer acceptance stays separate. |

No additional unresolved interpretation was found within the authorized source question. This is not verification that the future outer evidence or receiver output is sufficient. Failure to obtain those actual inputs later is an honest dependent gap under the existing route, not a reason to fabricate them or rerun unchanged research.

### C3 — Evidence and material handover

Input is `cad8242c803252113b49815441708ac51af5c7fc`. The scoped Git comparison from Extract shows unchanged receiver/shared sources and unchanged Extract. The authoritative d642 was already read completely and is identified by exact upstream commit/path and read time in Extract E4; c641 expressly adopts it. No broad inventory, outer accounting replay, product trial or Reviewer substitution occurred.

Primary external cross-check: [W3C PROV-DM](https://www.w3.org/TR/prov-dm/), §2.2.2, accessed 2026-09-13, describes inspecting who produced a provenance description and when. Researcher inference: copied evidence and later interpretation must retain their own source/producer/time, which tests the proposed false-independence and backdated-knowledge cases above. This supplies no TFW authority or new implementation requirement.

This stage is the actual material return of Researcher `01a0995f-6132-7c92-86d3-c5388827a8cd` to its sole recipient/direct parent Coordinator `01a09974-6716-7cc0-9916-fd6d04c91481`, principal `robert`, accountable human `saubakirov`. Findings and evaluations originate with Researcher; d642 is LEAD authority, c641 Coordinator continuation. Unchanged acquisition, exposure and inherited limitations remain in [iteration 1 RES](../iter1/RES.md). Technical findings are retained here; no new human fact/private context or independent acceptance was obtained. Actual producing-role and closure obligations remain with their existing owners.

## Checkpoint

| Found | Remaining |
|---|---|
| H1 narrowed; H2/H3 supported as representation claims; d642 scope preserved | Actual governing inputs/accounting/evidence must still be applied and independently assessed |
| All dimension pairs considered; six contradictory single-obligation combinations removed; 21 conditional survivors listed | No executed-test or reliability claim follows |
| Both inherited limitations, original source epochs and pending effects remain visible | Actual setup/review/close and their dispositions are unperformed; RES requires its own ruling |

**Sufficiency:**

- [x] External primary source used.
- [x] Briefing question answered at research level, including H1's rejected broad reading and remaining execution limits.
- [x] Pairwise incompatibility checked and surviving configurations listed.

Decision: carry this bounded evaluation into RES only after the Coordinator's synthesis ruling. No third iteration or scope expansion is proposed. Timing: Extract WAIT 13:34:55Z to approval 13:38:29Z (214 seconds); first continuation observation 13:38:55.0480273Z. Combined bound remains from 12:17:59.851010Z with no deductions; actual commit/readback and next WAIT are returned directly.

Stage complete: YES
→ User decision: return this committed Challenge and STOP/WAIT before RES.
