# Verify - "Are the claims true?"
> **Mindset:** Auditor. The RF is a declaration, not a fact. Open files. Run commands. Compare claims against reality.
> **Test:** "If I removed the RF, would the evidence alone prove the work was done?"
> **Continuation epoch:** `e5a1`, start `2026-09-13T14:26:13.371245Z`, deadline `2026-09-13T15:26:13.371245Z`.
> **Fresh Verify entry:** `2026-09-13T14:32:19.5950797Z`.
> **Verification runs:** `2026-09-13T14:39:51.5418439Z` through `2026-09-13T14:50:15.1502499Z`.
> **Historical-stage boundary:** the late Verify/Judge stored at `30a420de77ffae505bbc677cf561ac812b695ed3` (old hashes `f7fbd6c4...` / `1d297ee6...`) were not used as fresh results.
> **Min verify ratio:** `0.42`.
> **Changed paths in actual init range:** 65 (`0c02af7d...` through RF `0b734d9f...`).
> **Minimum:** ceil(65 x 0.42) = 28. **Actual:** all 65 paths checked for existence/current lineage, with semantic and byte checks for every claimed group.

## Verification Log

### V1: actual research gate and trace
- **RF claim:** two complete Researcher iterations precede setup and RF.
- **Actual:** gate `61043a8c5143b2a25ff9853a74610cdd9cd5d1b7` resolves and is an ancestor of setup `dd12b355...`; each iteration contains `1_briefing.md`, `2_gather.md`, `3_extract.md`, `4_challenge.md`, and `RES.md`; `iterations.yaml` contains two completed iterations.
- **Match:** PASS.

### V2: setup revision and current installed bytes
- **RF claim:** setup `dd12b355558a53286146f920983665f583e67e8c` installed exactly `AGENTS.md` plus eleven Codex skills.
- **Actual:** commit name-status contains exactly those twelve additions. All twelve current SHA-256 values match `07-fullsetup-result.json`; there is one managed block, eleven literal routes, eleven skill directories, and no installed helper/runtime.
- **Match:** PASS.

### V3: clean receiver and same-installation repeat
- **RF claim:** pinned 3.3.0 source, preserved clean state, one human profile, no knowledge-state scaffold, and zero-write repeat.
- **Actual:** `.tfw/VERSION` and config are `3.3.0`; `installed_from` is exact Candidate `27cdb701...`; root purpose/config/clean knowledge entry exist; only `team/saubakirov.md` exists; `.tfw/knowledge_state.yaml` is absent. Receipt reports 12 first-run writes, zero repeat writes, equal raw bytes/path set, and preservation of pre-existing files.
- **Match:** PASS.

### V4: setup-receipt custody
- **RF claim:** `evidence/setup/` contains original assurance receipts and source-bound copies.
- **Actual:** external originals 04-08 are byte-identical to their Git copies and match custody hashes. External originals 01-03 match the custody hashes, but their Git copies were CRLF-normalized and have different hashes/lengths: 01 `d01743.../12312` vs `577fbe.../11997`; 02 `4cc732.../1353` vs `415e10.../1331`; 03 `ceb2d3.../5738` vs `e2f9bb.../5680`. All six versions parse as JSON and the copied semantic values used by this review agree with the originals.
- **Match:** LIMIT. The operational claims remain inspectable, but `source-custody.json` attributes raw-original hashes to three normalized copy paths. This is an evidence-carrier precision discrepancy, not a setup-byte mismatch.

### V5: canonical RES-to-RF transition
- **RF claim:** the Coordinator used c183's receiver-specific precedence, wrote status before event, retained only the known helper error, and claimed no helper PASS.
- **Actual:** current state is RF; `transition.json` records empty `status_errors`, exactly one `event_errors` item (`illegal transition pair: RES -> RF`), status write `14:12:50.253439Z` before event write `14:12:50.260228Z`, matching readback hashes, and `helper_PASS: false`. Candidate helper lacks RES-to-RF while canonical init line 127 requires the init RF transition. The transition event and all refs resolve.
- **Match:** PASS under the narrow c183 authority; the inherited helper mismatch remains real.

### V6: exact outer accounting required by d642
- **RF claim:** approved outer Baseline/Candidate, literal 58-path selector, 53 MODIFY / 4 CREATE / 1 DELETE, and 1159 + 999 = 2158 touched text LOC.
- **Actual:** reran the three recorded NUL-safe argv arrays in `D:/projects/research/steps-framework`. Raw-output SHA-256 values exactly match `b0f9d3f781caa5717a017a2b92838fd78b8108bf88f1883ba4a89daa3b1a8f3a`, `375872084a1dcf0c1211e20962b968acd3dafe7243724c963e2623380bfd5031`, and `f16282b773e2cc679a211cae4dcc82d24f6beba9cc28b5efa270adb069054956`. Correct NUL parsing yields 58 VALUE rows, M53/A4/D1, +1159/-999, 2158 total, zero binary cases; full Candidate range has 84 changed rows. Approved TS blob resolves to `f69fd4099a21a07ae2d17e6b5108b04ac94f107e`.
- **Match:** PASS.

### V7: governing source and citations
- **RF claim:** local HL/TS/ONB are intentionally absent and the copied outer HL/TS/ONB plus 0173/c183/d642 govern under d642.
- **Actual:** all six governing copies match their exact upstream Git-object SHA-256 values; continuation `e5a1` also matches object `1c6a9bd...` at SHA-256 `4322b23f...`. All 7 RF Markdown links and all 18 EV Markdown links resolve. The cited clauses support the bounded uses stated in RF/EV.
- **Match:** PASS.

### V8: declared limitations and pending gates
- **RF claim:** two auxiliary README destinations and the helper transition support remain limited; review/close/adoption/AC-10 are not complete.
- **Actual:** `docs/brand/philosophy.png` and `editions/README.md` are absent while the four required root routes exist; helper mismatch is present; status remained RF at Verify; no DONE, established-adoption, outer verdict, or AC-10 evidence is claimed. One preserved early Coordinator subject (`1304eef...`) omits the full task ID.
- **Match:** PASS.

## Commands Executed

| # | Command/check | Fresh result |
|---|---|---|
| 1 | Resolve `61043a8`, ancestry, iteration-stage inventory | exit 0; exact full gate SHA; two complete five-file stage sets |
| 2 | Diff `0c02af7...` to `0b734d9...`; inspect all current paths | 65 paths; zero missing |
| 3 | Setup commit path list and SHA-256 map | exactly 12 additions; zero mismatches |
| 4 | `git -c core.longpaths=true diff --check dd12b355^ dd12b355` | exit 0 |
| 5 | `git -c core.longpaths=true fsck --no-dangling` | exit 0 |
| 6 | Three exact outer NUL-safe `git diff` argv arrays | exit 0; all raw hashes exact; 58/M53/A4/D1/+1159/-999 |
| 7 | Governing-copy versus upstream-object raw SHA-256 | 7/7 exact, including e5a1 |
| 8 | RF/EV relative-link resolution | 25/25 resolve |
| 9 | External receipt versus Git-copy raw SHA-256 | 5/8 exact; 3/8 normalized; semantic JSON readable |

Two fresh observer attempts failed before producing accounting results: the first used a mistyped full gate SHA; the next two used unavailable PowerShell APIs (`ArgumentList` and static `HashData`). These are Reviewer check-construction errors, not receiver defects. The successful runs above used the resolved gate SHA, `ProcessStartInfo.Arguments`, and `SHA256.Create().ComputeHash`; no failed-attempt output was promoted as evidence.

## Claim & Source Checks

| # | Claim / citation checked | Traces to | Holds? |
|---|---|---|---|
| C1 | exact twelve installed targets and one managed adapter | setup commit, source map, current bytes | PASS |
| C2 | research sufficiency before setup | iterations registry, ten stages, gate ancestry | PASS |
| C3 | zero-write same-installation repeat | setup 07 receipt and current byte map | PASS |
| C4 | receiver-specific RES-to-RF precedence | canonical init, c183, preflight, event/readback | PASS, scoped limitation retained |
| C5 | outer 58-path accounting | approved outer TS blob, literal argv, fresh raw output | PASS |
| C6 | copied-source integrity | external originals, Git copies, custody JSON | LIMIT for normalized 01-03 copy hashes |
| C7 | later gates remain pending | status/RF/EV and 0173 order | PASS |

## Discrepancies Found

1. `evidence/source-custody.json` lists raw external SHA-256 values under three Git-copy paths whose committed CRLF-normalized bytes differ. The JSON content is readable and semantically equal, and the external originals still match the recorded hashes, but the per-path byte attribution is imprecise. Judge must decide whether this harms the bounded init purpose.
2. The two inherited auxiliary destinations, external-helper transition omission, and one early abbreviated commit subject are real and already disclosed by RF; Judge must independently assess their consequence.

## Evidence Verification

| # | RF evidence ref | Artifact exists? | Claim/state independently checked? |
|---|---|---|---|
| E1 | setup 01-04 | yes | yes; custody precision limit recorded |
| E2 | research registry, stages/RES and gates | yes | yes; two complete iterations |
| E3 | setup 05-07 | yes | yes; exact selected hashes and repeat |
| E4 | setup 08 and setup commit | yes | yes; exact staging and Git checks |
| E5 | RF/review/close state | yes | yes; correctly BLOCKED at RF |
| E6 | 0173 adoption/AC-10 order | yes | yes; correctly BLOCKED at RF |
| E-accounting | outer accounting set | yes | yes; fresh byte-for-byte reproduction |

The EV verdict of 5 VERIFIED and 2 BLOCKED accurately describes the RF checkpoint; all seven rows were audited here.

## Knowledge Citations Verified

| Priority | Source consulted | Link/item/meaning/application |
|---|---|---|
| P0 | receiver README plus d642-substituted outer HL/TS/ONB | resolves; bounded clean-init purpose and outer AC-7 use verified |
| P1 | canonical `.tfw/README.md` North Star/methodology/success criteria | resolves; trace/evidence/role-separation application verified |
| P2 | `knowledge/philosophy.md` F1-F47 | exact outer source consulted; no contradiction |
| P3 | `KNOWLEDGE.md` D37/D43/D44/D47/D68/D73/D76/D82-D87 | exact outer decisions consulted; bounded ownership/evidence application verified |
| P4 | conventions HL Contract, Design Rules, Anti-patterns | exact outer sections consulted; no imported local design artifact required |
| P5-P7 | convention F23; process F30/F37/F38/F49; constraint F16; stakeholder F6 | relevant exact sources consulted; no contradictory receiver record |

Receiver `KNOWLEDGE.md` intentionally contains no qualified project facts; no receiver knowledge citation is fabricated.

## Checkpoint

**Self-check:**
- [x] Opened at least ceil(N x ratio) changed files or checked every changed path through complete inventory/hash/semantic group audits?
- [x] Independently established evidence applicability and ran affected checks?
- [x] Claim & Source Checks filled?
- [x] Each RF section 3 checkmark verified against actual files?
- [x] `KNOWLEDGE.md` checked?
- [x] Knowledge Citations verified?
  - Priority layers consulted: P0-P7; unresolved or hallucinated citations: 0.
- [x] Evidence artifacts from RF section 5 verified?
  - Total evidence rows: 7; audited: 7; missing: 0; RF-state distribution confirmed: 5 VERIFIED / 2 BLOCKED.

Stage complete: YES

### Selected knowledge evidence

Researcher `01a0995f-6132-7c92-86d3-c5388827a8cd` produced both preserved RES/stage sets; Coordinator `01a09974-6716-7cc0-9916-fd6d04c91481` produced setup/RF controls; Reviewer `01a09aaf-9af3-7d13-8ef8-59d3bc84d5e7` independently reran the checks above. Technical limitations and the custody precision discrepancy remain review evidence, not accepted project knowledge.
