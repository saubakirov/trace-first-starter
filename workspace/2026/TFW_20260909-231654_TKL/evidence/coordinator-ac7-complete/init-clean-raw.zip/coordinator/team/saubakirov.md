---
handle: saubakirov
name: saubakirov
type: human
since: 2026-09-13
---

**Participant profile.** Declared attribution, not authentication. It grants and verifies
nothing.
