"""Coordinator's disposable host-side setup operation; never a receiver runtime.

Prepared before the research gate. Execution refuses until both actual iterations
are complete. It installs only the 12 selected Codex targets and preserves all
pre-existing receiver files. RF/evidence/transition authorship remains a later act.
"""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

import yaml

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
RECEIVER = ROOT / "coordinator"
TASK = RECEIVER / "workspace/2026/TFW_20260913-172107_INIT"
CANDIDATE = "27cdb701b91c5b45b9f54b3e98c9ad67635b3e30"


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def files():
    return {
        q.relative_to(RECEIVER).as_posix(): digest(q.read_bytes())
        for q in sorted(RECEIVER.rglob("*"))
        if q.is_file() and ".git" not in q.relative_to(RECEIVER).parts
    }


def git(*args):
    r = subprocess.run(
        ["git", "-c", "core.longpaths=true", *args], cwd=RECEIVER,
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    result = {"command": ["git", "-c", "core.longpaths=true", *args],
              "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr,
              "observed_at": now()}
    if r.returncode:
        raise RuntimeError(json.dumps(result))
    return result


def seal(name, data):
    q = ROOT / name
    with q.open("x", encoding="utf-8", newline="\n") as out:
        out.write(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


class UniqueLoader(yaml.SafeLoader):
    pass


def unique_mapping(loader, node, deep=False):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in result:
            raise ValueError("Duplicate YAML key: " + str(key))
        result[key] = loader.construct_object(value_node, deep=deep)
    return result


UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)


def read_yaml(q):
    return yaml.load(q.read_text(encoding="utf-8"), Loader=UniqueLoader)


def main():
    if sys.argv[1:] != ["--execute-after-research"]:
        raise SystemExit("Explicit post-research execution argument required.")
    started = now()
    registry = read_yaml(TASK / "research/iterations.yaml")
    assert registry["task_id"] == TASK.name
    assert registry["min_iterations"] == 2 and registry["max_iterations"] == 2
    assert [r["number"] for r in registry["iterations"]] == [1, 2]
    assert all(r["status"] == "complete" for r in registry["iterations"])
    for row in registry["iterations"]:
        q = (TASK / row["res_file"]).resolve()
        assert q.is_relative_to(TASK.resolve()) and q.is_file()
        assert q.read_bytes()
    state = yaml.load((TASK / "status.md").read_text(encoding="utf-8").split("---", 2)[1], Loader=UniqueLoader)
    assert state["id"] == TASK.name and state["lifecycle"] == "RES"
    assert state["owner"] == "saubakirov" and "outcome" not in state
    assert (TASK / state["authority"]).resolve() == RECEIVER / "README.md"
    assert not git("status", "--porcelain=v1")["stdout"]

    config = read_yaml(RECEIVER / ".tfw/project_config.yaml")
    assert config["tfw"]["installed_from"] == "steps-framework@" + CANDIDATE
    assert config["tfw"]["version"] == (RECEIVER / ".tfw/VERSION").read_text().strip()
    assert config["tfw"]["task_containers"] == ["workspace"]
    assert "historical_containers" not in config["tfw"] and "knowledge" not in config["tfw"]
    assert not (RECEIVER / ".tfw/knowledge_state.yaml").exists()
    source_map = json.loads((ROOT / "05-selected-adapter-source-map.json").read_text(encoding="utf-8"))
    assert source_map["Candidate"] == CANDIDATE
    manifest = read_yaml(RECEIVER / ".tfw/adapters/manifest.yaml")
    assert len(manifest["commands"]) == 11 and len(manifest["adapters"]) == 4
    selected = [source_map["persistent"], *source_map["commands"]]
    target_paths = {r["target"] for r in selected}
    assert len(target_paths) == 12
    for row in selected:
        assert not row["target_present_before_FullSetup"]
        assert digest((RECEIVER / row["source"]).read_bytes()) == row["source_sha256"]
        assert not (RECEIVER / row["target"]).exists()
    before = files()
    assert not (target_paths & before.keys())
    seal("06-fullsetup-before.json", {
        "observed_at": started, "subject": "Actual post-research Full Setup before first target write",
        "Candidate": CANDIDATE, "head": git("rev-parse", "HEAD")["stdout"].strip(),
        "source_map": "05-selected-adapter-source-map.json", "files": before,
        "old_targets": {p: None for p in sorted(target_paths)},
        "authorized_effect": "One managed Codex block plus 11 exact selected command copies",
    })

    def apply_selected():
        writes = []
        for row in selected:
            source = RECEIVER / row["source"]
            target = RECEIVER / row["target"]
            raw = source.read_bytes()
            assert digest(raw) == row["source_sha256"]
            if target.exists():
                assert target.is_file() and target.read_bytes() == raw, "Unexpected target value"
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as out:
                out.write(raw)
            assert target.read_bytes() == raw
            writes.append({"path": row["target"], "sha256": digest(raw), "written_at": now()})
        return writes

    writes = apply_selected()
    after = files()
    assert len(writes) == 12 and after.keys() - before.keys() == target_paths
    assert not (before.keys() - after.keys())
    assert all(after[p] == h for p, h in before.items())
    agents = (RECEIVER / "AGENTS.md").read_text(encoding="utf-8")
    assert agents.count("<!-- TFW:CODEX:START -->") == 1
    assert agents.count("<!-- TFW:CODEX:END -->") == 1
    for row in source_map["commands"]:
        actual = (RECEIVER / row["target"]).read_text(encoding="utf-8")
        assert row["route"] in actual and row["workflow"] in actual
        assert manifest["commands"][row["command"]]["role"] == row["role"]
        assert digest((RECEIVER / row["workflow"]).read_bytes()) == row["workflow_sha256"]
    actual_commands = {q.relative_to(RECEIVER).as_posix() for q in (RECEIVER / ".agents/skills").glob("tfw-*/SKILL.md")}
    assert actual_commands == {r["target"] for r in source_map["commands"]}
    repeat_started = now()
    repeat_writes = apply_selected()
    repeated = files()
    assert not repeat_writes and repeated == after
    checks = [git("diff", "--check"), git("fsck", "--no-dangling")]
    seal("07-fullsetup-result.json", {
        "started_at": started, "observed_at": now(), "Candidate": CANDIDATE,
        "subject": "Actual installed Codex targets and same-installation idempotence",
        "writes": writes, "files_after": after, "all_existing_files_preserved": True,
        "managed_block_count": 1, "exact_command_copies": 11,
        "repeat": {"started_at": repeat_started, "ended_at": now(), "writes": repeat_writes,
                   "same_raw_bytes_and_path_set": repeated == after},
        "checks": checks,
        "limits": ["No foreign AGENTS/skill neighbors existed in this clean receiver.",
                   "Source/copy checks do not prove invocation of all 11 native commands.",
                   "Both inherited README targets remain absent; no all-links PASS.",
                   "RF, actual RES-to-RF preflight/event, independent review and close remain later acts.",
                   "This host-side script is not copied into the receiver or a required runtime."],
    })
    print(json.dumps({"result": "12 targets installed; existing bytes preserved; repeat unchanged",
                      "receipt": str(ROOT / "07-fullsetup-result.json"), "finished_at": now()}))


if __name__ == "__main__":
    main()
