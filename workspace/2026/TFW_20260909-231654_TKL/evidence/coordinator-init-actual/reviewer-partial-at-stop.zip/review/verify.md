# Verify — "Are the claims true?"
> **Mindset:** Auditor. The RF is a declaration, not a fact. Open files. Run commands. Compare claims against reality.
> **Test:** "If I removed the RF, would the evidence alone prove the work was done?"
> Min verify ratio: 0.42
> RF files claimed: 20 (twelve installed targets plus eight grouped control/report artifacts)
> Files to verify: ⌈20 × 0.42⌉ = 9; 20/20 claimed groups/targets were checked.

## Verification Log

### V1: setup revision `dd12b355558a53286146f920983665f583e67e8c`
- **RF claim:** exactly AGENTS.md plus eleven Codex skills were installed.
- **Actual:** commit name-status contains exactly those twelve additions; all twelve current SHA-256 values match `07-fullsetup-result.json`.
- **Match:** ✅

### V2: research and control trace
- **RF claim:** two complete actual iterations precede setup/RF.
- **Actual:** both complete stage/RES sets, `iterations.yaml`, per-stage Coordinator dispatches and sufficiency gate `61043a8` resolve before setup `dd12b35` and RF `0b734d9`.
- **Match:** ✅

### V3: setup/source receipts
- **RF claim:** pinned Candidate, exact selected routes, preservation and zero-write repeat.
- **Actual:** setup 01–08, source custody and 07 path/hash maps resolve; installed hashes match and the receipt records zero repeat writes. Original external receipts remain outside checkout; Git-normalized CRLF copies are not treated as original raw bytes.
- **Match:** ✅

### V4: RF transition
- **RF claim:** canonical RES→RF after the c183 constrained preflight.
- **Actual:** status is RF; `transition.json`, transition event and c183 resolve. Preserved helper output has only the declared illegal-pair error; no helper PASS is claimed.
- **Match:** ✅

### V5: outer accounting
- **RF claim:** exact 58-path Baseline/Candidate output is 1159+999=2158.
- **Actual:** reran all three recorded NUL-safe commands in original upstream Git. SHA-256 values exactly match `b0f9…`, `375872…`, `f16282…`; numstat parsed to 58 rows, 1159 additions, 999 deletions, 2158 total.
- **Match:** ✅

### V6: limitations and pending gates
- **RF claim:** two auxiliary destinations and helper transition support remain limited; review/close/adoption/AC-10 are not complete.
- **Actual:** both auxiliary paths are absent; helper mismatch is present; lifecycle remains RF and no adoption/AC-10 evidence is claimed.
- **Match:** ✅

## Commands Executed

| # | Command | Result |
|---|---------|--------|
| 1 | Three exact recorded outer `git diff ... -z` commands in `D:/projects/research/steps-framework` | exit 0; byte hashes identical; 58 / +1159 −999 |
| 2 | SHA-256 check of all twelve installed targets against setup receipt | 0 mismatches |
| 3 | `git -c core.longpaths=true diff --check dd12b355^ dd12b355` | exit 0 |
| 4 | `git -c core.longpaths=true fsck --no-dangling` | exit 0 |

## Claim & Source Checks

| # | Claim / citation checked | Where it appears | Traces to | Holds? |
|---|--------------------------|------------------|-----------|--------|
| C1 | exact twelve installed targets | RF §1 | setup commit plus 07/08 receipts and current bytes | ✅ |
| C2 | canonical receiver-specific RES→RF precedence | RF §2/§6 | c183, transition event and transition.json | ✅ |
| C3 | outer 58-path accounting | RF accounting | approved outer TS blob and fresh original-Git reproduction | ✅ |

All RF/EV/governing citations resolve. Primary sources were the Git objects, current bytes and original upstream Git, not the RF summary.

## Discrepancies Found

No discrepancy between bounded RF claims and actual evidence. The two inherited limitations are real and explicitly scoped.

## Evidence Verification

| # | RF Evidence ref | Artifact exists? | Matches claim? |
|---|----------------|-----------------|----------------|
| E1 | setup 01–04 | ✅ | ✅ — clean acquisition/Mini-Setup controls |
| E2 | research registry, stages/RES and gates | ✅ | ✅ — two completed iterations |
| E3 | setup 05–07 | ✅ | ✅ — path/source/hash equality and repeat |
| E4 | setup 08 and setup commit | ✅ | ✅ — exact staging and Git checks |
| E5 | current RF state | ✅ | ✅ — independent review/close were pending at RF |
| E6 | governing 0173 | ✅ | ✅ — adoption and AC-10 remain later outer gates |
| E-accounting | outer accounting set | ✅ | ✅ — independently reproduced byte-for-byte |

## Knowledge Citations Verified

| # | Artifact | Priority + exact citation | Link resolves? | Item exists? | Meaning matches? | Relevant to asserted application? |
|---|----------|---------------------------|----------------|--------------|------------------|-----------------------------------|
| 1 | d642 substitution / receiver README | P0 clean isolated receiver purpose | ✅ | ✅ | ✅ | ✅ — forbids importing memory/runtime and requires review |
| 2 | canonical `.tfw/README.md` | P1 methodology/success criteria | ✅ | ✅ | ✅ | ✅ — trace/evidence/role separation |
| 3 | copied outer HL/ONB | P0–P4 governing AC-7/Q2 claims | ✅ | ✅ | ✅ | ✅ — exact init assurance bound |

No receiver knowledge facts contradict the result; `KNOWLEDGE.md` intentionally remains an empty stable entry. P5–P7 contain no applicable receiver records.

## Checkpoint

**Self-check:**
- [x] Opened ≥ ⌈N × ratio⌉ files and recorded findings?
- [x] Independently established evidence applicability and ran necessary affected checks, or named the exact unresolved claim?
- [x] Claim & Source Checks filled?
- [x] Each RF §3 checkmark verified against actual file?
- [x] KNOWLEDGE.md checked?
- [x] Knowledge Citations verified?
  - Total: 3, resolved: 3, semantically verified: 3, irrelevant: 0, hallucinated: 0
- [x] Evidence artifacts from RF §5 verified?
  - Total evidence items: 7, verified: 7, missing: 0

Stage complete: YES

### Selected knowledge evidence

Researcher `01a0995f-6132-7c92-86d3-c5388827a8cd` produced both preserved RES/stage sets; Coordinator `01a09974-6716-7cc0-9916-fd6d04c91481` produced setup/RF controls; Reviewer `01a09aaf-9af3-7d13-8ef8-59d3bc84d5e7` independently checked them. Technical limitations remain scoped evidence, not accepted project knowledge.
