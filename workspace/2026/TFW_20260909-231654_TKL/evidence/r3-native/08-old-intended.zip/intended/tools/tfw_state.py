"""Semantic readers for the upstream TFW repository.

Task-local ``status.md`` and journal files remain authoritative.  This module only reads
their declared carriers and resolves whole task identifiers.  It has no command-line interface,
report presentation, repair, aggregate rendering, shared write, or authority over the files it reads.

The module lives under root ``tools/`` deliberately: it is upstream maintainer support and
is not part of the copied Full payload or the prompt-first Assisted edition.
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta
from pathlib import Path

import yaml

# Project root

#: The marker that identifies a project root. A TFW project is a directory containing this.
ROOT_MARKER = ".tfw"

#: A staging directory `update.md` Step 0 creates by cloning upstream. It contains a complete
#: `.tfw/`, so it satisfies the marker and could capture a semantic read inside the upstream
#: clone instead of the receiver. Skipped by name, never by depth.
STAGING_SEGMENT = ".upstream"


def find_project_root(start: Path | None = None) -> Path:
    """The project root, found by walking upward for a ``.tfw/`` directory.

    Depth arithmetic — ``Path(__file__).parents[2]`` — was the previous answer, and it made
    the tools' own location load-bearing: a project that placed them anywhere else had to
    edit ``.tfw/`` and forfeit clean updates. It was also *silently* wrong rather than
    loudly wrong, because from the former payload location the third parent happened to be the root.

    The search starts at this file's own directory, so it answers for wherever the tools
    were put rather than for wherever they were invoked from. A candidate whose path
    contains ``.upstream`` is skipped: that directory holds a full upstream clone and would
    otherwise capture the search one level early.

    Raises ``SystemExit`` when no root is found. There is no fallback — guessing a root
    means writing files into a directory nobody chose.
    """
    start = (start or Path(__file__)).resolve()
    base = start if start.is_dir() else start.parent
    for candidate in (base, *base.parents):
        if STAGING_SEGMENT in candidate.parts:
            continue
        if (candidate / ROOT_MARKER).is_dir():
            return candidate
    raise SystemExit(
        f"no project root above {base}: no directory contains {ROOT_MARKER}/.\n"
        f"  Pass --root <path> to name it explicitly."
    )


# ---------------------------------------------------------------------------
# Shared task resolver
# ---------------------------------------------------------------------------

#: Clock-derived identifier shipped during the TFW 2.0.0 dirty line. The WHOLE
#: directory name is the identifier: ``YYYYMMDD-HHMMSS__slug``.
#: The timestamp alone is not an identifier — two mutually offline participants can reach
#: the same second, and only the slug distinguishes them. Two who reach the same second AND
#: the same slug created the same task, which is a signal rather than a collision to prevent.
CLOCK_ID = re.compile(r"^(?P<stamp>\d{8}-\d{6})__(?P<slug>.+)$")

#: Current identifier: project, moment, approved subject abbreviation. Single
#: underscores are unambiguous separators because no field may contain one.
CURRENT_ID = re.compile(
    r"^(?P<prefix>[A-Z][A-Z0-9]*)_(?P<stamp>\d{8}-\d{6})_(?P<abbr>[A-Z0-9]+)$"
)

#: A bare timestamp. Never a valid identifier; matched only so consumers can say why.
BARE_STAMP = re.compile(r"^\d{8}-\d{6}$")

#: Legacy identifier grammar: ``{PREFIX}-{seq}``, optionally followed by a slug.
LEGACY_ID = re.compile(r"^(?P<prefix>[A-Z][A-Z0-9]*)-(?P<seq>\d+)(?:__(?P<slug>.+))?$")


class IdentifierCollisionError(ValueError):
    """Two directory occurrences resolve to the same task identifier."""

NEWLINE = chr(10)

#: A leading YAML front-matter block.
FRONT_MATTER = re.compile("^---" + chr(92) + "r?" + chr(92) + "n(.*?)" + chr(92) + "r?" + chr(92) + "n---" + chr(92) + "r?" + chr(92) + "n", re.S)

DEFAULT_CONTAINERS = ["workspace"]

TERMINAL = {"DONE", "REJECTED"}

STATUS_KEYS = {
    "id", "title", "goal", "value", "lifecycle", "lifecycle_verbatim",
    "owner", "authority", "outcome", "created", "updated",
}

REQUIRED_KEYS = ("id", "title", "goal", "value", "lifecycle", "owner", "authority",
                 "created", "updated")

#: Fallback vocabulary when project_config.yaml cannot be read.
DECLARED_LIFECYCLES = ("TODO", "HL_DRAFT", "RES", "PHASES", "TS_DRAFT", "ONB", "RF", "REV",
                       "KNW", "DONE", "BLOCKED", "REJECTED")

# New writes use this graph. Historical events remain readable through ``validate_event`` even
# when an older workflow recorded a no-op or shortcut; immutable history is never normalized.
FORWARD_TRANSITIONS = {
    ("TODO", "HL_DRAFT"),
    ("HL_DRAFT", "RES"), ("HL_DRAFT", "TS_DRAFT"), ("HL_DRAFT", "PHASES"),
    ("RES", "TS_DRAFT"), ("RES", "PHASES"),
    ("PHASES", "KNW"),
    ("TS_DRAFT", "ONB"),
    ("ONB", "RF"),
    ("RF", "REV"), ("RF", "KNW"), ("RF", "ONB"), ("RF", "TS_DRAFT"),
    ("REV", "KNW"), ("REV", "RF"), ("REV", "ONB"), ("REV", "TS_DRAFT"),
    ("KNW", "DONE"),
}

#: Not selectable by a person. Migration writes it when a source held a value the
#: vocabulary does not contain, and keeps that value verbatim beside it.
UNDECLARED = "UNDECLARED"

#: `created` and `updated` carry the same grammar as the identifier: second resolution.
#: A day-resolution stamp on a corpus with several transitions a day reports nothing — the
#: rejected pass shipped TFW-60 with `created` and `updated` identical.
STAMP = re.compile(r"^\d{8}-\d{6}$")

#: What a legacy source that carried only a date migrates to. The zero time is DECLARED, not
#: measured: it says "this day, time unknown" and must never be read as second-accurate.
ZERO_TIME = "000000"


def explain_yaml_error(block: str, exc: yaml.YAMLError) -> str:
    """A parse failure named by the key it happened on, not by the exception's class name.

    ``unparseable front matter: ScannerError`` is what this used to say, and a real person
    hand-writing five state files had to find the cause by inspection. The cause was always
    the same and always mechanical: a value containing ``": "`` ends a YAML plain scalar, so
    ``title: Phase A: portable delivery`` is not a string, it is a syntax error.

    PyYAML gives a line and a column, never a key. The key is recovered from the source
    text at the marked line — which is the only place it exists.
    """
    detail = getattr(exc, "problem", None) or exc.__class__.__name__
    mark = getattr(exc, "problem_mark", None) or getattr(exc, "context_mark", None)
    if mark is not None:
        line_number = mark.line  # 0-based, into the front-matter block
    elif hasattr(exc, "position"):
        # ReaderError stops before tokenization and therefore has no mark. Its absolute
        # character offset is still enough to recover the containing key.
        line_number = block.count("\n", 0, exc.position)
    else:
        return f"unparseable front matter: {detail}"

    lines = block.splitlines()
    # The key is the nearest `key:` at or above the marked line: a broken value can push the
    # reported mark onto the following line.
    key = None
    for index in range(min(line_number, len(lines) - 1), -1, -1):
        head = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*):", lines[index])
        if head:
            key = head.group(1)
            break
    where = f"line {line_number + 1}"
    if key is None:
        return f"unparseable front matter at {where}: {detail}"
    hint = ""
    value = lines[line_number] if line_number < len(lines) else ""
    if ": " in value.split(":", 1)[-1]:
        # ASCII only. This reaches a terminal whose encoding nobody chose, and a hint that
        # renders as replacement characters is worse than no hint.
        hint = (". A value containing \": \" ends a YAML plain scalar, so quote it: "
                f"{key}: \"...\"")
    return f"unparseable front matter: key `{key}` ({where}): {detail}{hint}"


def parse_identifier(text: str) -> tuple[str, str] | None:
    """Classify a task identifier or directory name under one named grammar.

    Accepts what a consumer actually holds — a directory name — and returns
    ``(kind, identifier)``:

    * ``("clock", "20260826-143000__query_redesign")`` — the identifier is the whole name.
    * ``("current", "TFW_20260829-010832_CRSW")`` — project, moment and approved
      abbreviation; the identifier is again the whole name.
    * ``("legacy", "TFW-60")`` — the pre-2.0.0 grammar, where the slug is not part of it.
    * ``None`` — not an identifier. **A bare ``YYYYMMDD-HHMMSS`` lands here on purpose**: it
      is ambiguous between any two tasks created in that second, and no consumer may accept
      one as if it named exactly one task.

    One resolver, used by every consumer. Per-call-site regexes are how the previous board
    parser drifted out of sync with the board it parsed.
    """
    text = text.strip()
    if CURRENT_ID.fullmatch(text):
        return ("current", text)
    if CLOCK_ID.match(text):
        return ("clock", text)
    match = LEGACY_ID.match(text)
    if match:
        return ("legacy", f"{match.group('prefix')}-{match.group('seq')}")
    return None


def sort_key(kind: str, identifier: str) -> tuple:
    """Declared sort key: legacy, dirty-clock, then current; ascending within each.

    Legacy identifiers sort numerically, so ``TFW-9`` precedes ``TFW-10``. Clock
    identifiers sort by timestamp then slug — fixed-width, so lexical order on the stamp is
    chronological, and the slug only breaks a same-second tie. The newest task is last.
    """
    if kind == "legacy":
        m = LEGACY_ID.match(identifier)
        return (0, m.group("prefix"), int(m.group("seq")), "")
    if kind == "clock":
        m = CLOCK_ID.match(identifier)
        return (1, m.group("stamp"), m.group("slug"), "")
    m = CURRENT_ID.match(identifier)
    return (2, m.group("stamp"), m.group("prefix"), m.group("abbr"))


def read_config(root: Path) -> dict:
    """Read the TFW block from ``project_config.yaml``."""
    path = root / ".tfw" / "project_config.yaml"
    if not path.exists():
        return {}
    with open(path, encoding="utf-8") as handle:
        return (yaml.safe_load(handle) or {}).get("tfw", {}) or {}


def task_containers(root: Path) -> list[str]:
    """Active containers: creation uses the first; ordinary discovery searches these only."""
    value = read_config(root).get("task_containers") or DEFAULT_CONTAINERS
    if isinstance(value, str):
        value = [value]
    return [str(item).strip("/") for item in value]


def reference_containers(root: Path) -> list[str]:
    """Ordered active/history union for exact reading and compilation, never gate discovery."""
    history = read_config(root).get("historical_containers", [])
    if not isinstance(history, list):
        raise ValueError("tfw.historical_containers must be a list of relative directory paths")
    for item in history:
        if (not isinstance(item, str) or not item.strip() or "\\" in item
                or Path(item).is_absolute() or ":" in item
                or ".." in Path(item).parts or not Path(item).parts
                or not (root / item).resolve().is_relative_to(root.resolve())):
            raise ValueError(f"invalid historical container path: {item!r}")
    result, seen = [], set()
    for item in [*task_containers(root), *history]:
        resolved = (root / item).resolve()
        if resolved not in seen:
            seen.add(resolved)
            result.append(item)
    return result


def _walk_containers(root: Path, containers: list[str] | None = None
                     ) -> tuple[list[Path], list[Path]]:
    """Every directory the containers hold, split into ``(matched, unmatched)``.

    One walk, two answers. Previously there was one walk and one answer, and a directory
    the identifier grammar did not match was ``continue``d — dropped before any consumer
    could see it. That is how a real external corpus of four tasks was read as two, and how
    two directories holding completed HL, TS and RF traces were then rendered under a
    heading calling them *"ideas, not work in progress"*.

    Dropping silently is bad. Confidently misdescribing is worse, because it reads as a
    finding. So the rejects are returned rather than discarded, and the caller reports them
    as unresolved input.

    A container may hold task directories directly (the legacy layout) or nested under a
    creation-year folder (2.0.0). Both are searched. Matched results are sorted by the
    declared key rather than by whatever order the filesystem offered.
    """
    if containers is None:
        containers = task_containers(root)
    found: list[tuple[tuple, Path]] = []
    unmatched: list[Path] = []
    seen: set[Path] = set()
    for container in containers:
        base = root / container
        if not base.is_dir():
            continue
        # One level of year nesting is expanded; anything deeper is a task's own content.
        pending = sorted((p for p in base.iterdir() if p.is_dir()), key=lambda p: p.name)
        while pending:
            child = pending.pop(0)
            if re.fullmatch(r"\d{4}", child.name) and child.parent == base:
                pending = sorted(
                    (p for p in child.iterdir() if p.is_dir()), key=lambda p: p.name
                ) + pending
                continue
            resolved = child.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            parsed = parse_identifier(child.name)
            if parsed is None:
                unmatched.append(child)
                continue
            found.append((sort_key(*parsed), child))
    by_identifier: dict[str, list[Path]] = {}
    for _, path in found:
        identifier = parse_identifier(path.name)[1]
        by_identifier.setdefault(identifier, []).append(path)
    collisions = {identifier: paths for identifier, paths in by_identifier.items()
                  if len(paths) > 1}
    if collisions:
        details = []
        for identifier, paths in sorted(collisions.items()):
            names = ", ".join(
                path.relative_to(root).as_posix() for path in sorted(paths, key=str))
            details.append(f"{identifier}: {names}")
        raise IdentifierCollisionError(
            "task directory identifier collision; each identifier must resolve exactly once: "
            + "; ".join(details)
        )

    found.sort(key=lambda pair: (pair[0], str(pair[1])))
    unmatched.sort(key=lambda path: str(path))
    return [path for _, path in found], unmatched


def iter_task_dirs(root: Path, containers: list[str] | None = None) -> list[Path]:
    """Every task directory whose name the identifier grammar matches, in declared order."""
    return _walk_containers(root, containers)[0]


def iter_unmatched_task_dirs(root: Path, containers: list[str] | None = None) -> list[Path]:
    """Every container directory the identifier grammar does **not** match.

    An additive sibling rather than a changed return type, because ``iter_task_dirs`` is
    called by ``gen_docs.py``, ``migrate_board.py`` and their tests.

    These are never *matched* into the grammar. Widening ``LEGACY_ID`` to admit the
    single-underscore form would edit an identifier rule, and the identifier rules are not
    under revision. The tool reports; a person may rename the directory to the recognized
    grammar if they want it picked up — the same shape as the ``UNDECLARED`` rule, where
    migration never normalizes and an accountable owner may resolve.
    """
    return _walk_containers(root, containers)[1]


def declared_lifecycles(root: Path) -> list[str]:
    """The lifecycle vocabulary this project declares."""
    entries = read_config(root).get("statuses") or []
    ids = [str(e.get("id")) for e in entries if isinstance(e, dict) and e.get("id")]
    return ids or list(DECLARED_LIFECYCLES)


def read_status(task_dir: Path, declared: list[str] | None = None) -> dict | None:
    """Parse ``status.md`` front matter. Returns ``None`` when the file is absent.

    A file that exists but cannot be parsed, or that breaks any rule of the closed schema,
    returns a dict carrying ``_error``: a malformed input is reported, never dropped and
    never silently repaired.
    """
    path = task_dir / "status.md"
    if not path.exists():
        return None
    text = path.read_text(encoding="utf-8")
    match = re.match(r"^---\r?\n(.*?)\r?\n---\r?\n", text, re.S)
    if not match:
        return {"_error": "no YAML front matter"}
    try:
        data = yaml.safe_load(match.group(1))
    except yaml.YAMLError as exc:
        return {"_error": explain_yaml_error(match.group(1), exc)}
    if not isinstance(data, dict):
        return {"_error": "front matter is not a mapping"}
    problems = validate_status(data, task_dir, declared)
    if problems:
        data["_error"] = "; ".join(problems)
    return data


def validate_status(data: dict, task_dir: Path | None = None,
                    declared: list[str] | None = None) -> list[str]:
    """Every rule the carrier declares, checked. Returns the problems found, in order.

    The key set is closed, so an unknown key is an error rather than an extension: a field
    nothing reads is exactly what the carrier exists to keep out. Conditional keys are
    checked both ways — present when required, and absent when not applicable — because a
    stray ``outcome`` on a live task is a claim that it finished.
    """
    declared = declared or list(DECLARED_LIFECYCLES)
    problems: list[str] = []

    unknown = sorted(set(data) - STATUS_KEYS)
    if unknown:
        problems.append("unknown keys: " + ", ".join(unknown))

    for key in REQUIRED_KEYS:
        if not data.get(key):
            problems.append(f"missing {key}")

    lifecycle = data.get("lifecycle")
    if lifecycle and lifecycle != UNDECLARED and lifecycle not in declared:
        problems.append(
            f"lifecycle '{lifecycle}' is not declared and is not {UNDECLARED}; "
            "an out-of-vocabulary value must be carried as "
            f"{UNDECLARED} plus lifecycle_verbatim, never normalized")

    # Conditional keys, checked in both directions.
    if lifecycle == UNDECLARED and not data.get("lifecycle_verbatim"):
        problems.append(f"lifecycle is {UNDECLARED} but lifecycle_verbatim is absent, "
                        "so the value the source actually carried is lost")
    if lifecycle != UNDECLARED and data.get("lifecycle_verbatim"):
        problems.append("lifecycle_verbatim is only meaningful when lifecycle is "
                        f"{UNDECLARED}")
    if lifecycle in TERMINAL and not data.get("outcome"):
        problems.append(f"lifecycle is terminal ({lifecycle}) but outcome is absent")
    if lifecycle and lifecycle not in TERMINAL and data.get("outcome"):
        problems.append("outcome is set on a task that has not reached a terminal "
                        "lifecycle — it claims a result that has not happened")

    for key in ("created", "updated"):
        value = data.get(key)
        if value is None:
            continue
        text = value.isoformat() if hasattr(value, "isoformat") else str(value)
        if text != "unrecorded" and not STAMP.match(text):
            problems.append(f"{key} is not YYYYMMDD-HHMMSS or 'unrecorded': {text!r}")

    # The identifier must be the one its own directory carries. A state file that names a
    # different task is worse than a missing one: every consumer keys on `id`.
    if task_dir is not None:
        parsed = parse_identifier(task_dir.name)
        if parsed is None:
            problems.append(f"directory name {task_dir.name!r} is not a task identifier")
        elif data.get("id") and str(data["id"]) != parsed[1]:
            problems.append(
                f"id {str(data['id'])!r} disagrees with its directory, which is "
                f"{parsed[1]!r}")

    return problems


PHASE_DIR = re.compile(r"^phase-(?P<letter>[a-z0-9]+)$")


def iter_phase_dirs(task_dir: Path) -> list[Path]:
    """Phase directories inside a task, in declared order.

    A phase carries its own ``status.md`` on the same closed schema, written by that phase's
    owner. Two phases running under two owners are two files, so they never contend.
    """
    return sorted((p for p in task_dir.iterdir() if p.is_dir() and PHASE_DIR.match(p.name)),
                  key=lambda p: p.name)


def read_phase_status(phase_dir: Path, declared: list[str] | None = None) -> dict | None:
    """A phase's own state. Same schema as a task's, minus the directory-identifier check.

    The phase directory is named ``phase-a``, not an identifier, so the ``id`` field carries
    the *task's* identifier and agreement with the directory name is not checked here.
    """
    path = phase_dir / "status.md"
    if not path.exists():
        return None
    text = path.read_text(encoding="utf-8")
    match = FRONT_MATTER.match(text)
    if not match:
        return {"_error": "no YAML front matter"}
    try:
        data = yaml.safe_load(match.group(1))
    except yaml.YAMLError as exc:
        return {"_error": explain_yaml_error(match.group(1), exc)}
    if not isinstance(data, dict):
        return {"_error": "front matter is not a mapping"}
    problems = validate_status(data, None, declared)
    if problems:
        data["_error"] = "; ".join(problems)
    return data


# ---------------------------------------------------------------------------
# Journal events
# ---------------------------------------------------------------------------

#: ``<YYYYMMDD-HHMMSS>__<kind>__<token>.md``.
#:
#: **The third component has exactly one job: two writes in one second cannot share a name.**
#: It is not an identity. It names nobody, requires no profile, and is validated against
#: nothing — there is nothing to validate it against, because uniqueness is the whole of what
#: it does.
#:
#: It used to be the `actor` handle, and that is what went wrong: one component was given two
#: unrelated jobs — say who wrote this, and make the name unique — and the two collided in the
#: field. A distinct writer needs a distinct value; a declared handle needs a profile; so two
#: external projects created a profile per session, and one of them later deleted those
#: profiles and left its build gate permanently red. Events are immutable, profiles are not.
#:
#: A pre-`2.0.0-dirty.3` name carries a handle here and matches this pattern unchanged. That
#: is deliberate and it is why the ruling costs no project any work: the two shapes are
#: **syntactically identical**, so nothing has to tell them apart, and nothing does.
EVENT_NAME = re.compile(
    r"^(?P<stamp>\d{8}-\d{6})__(?P<kind>[a-z_]+)__(?P<token>[a-z0-9][a-z0-9-]*)\.md$")

#: The pre-2.0.0 event name, ``<stamp>__<kind>.md``. Events written under it are immutable
#: like every other event: a correction is a new event, never an edit. They are reported as
#: legacy rather than as defects, exactly as a legacy task identifier is.
LEGACY_EVENT_NAME = re.compile(r"^(?P<stamp>\d{8}-\d{6})__(?P<kind>[a-z_]+)\.md$")

#: Closed vocabulary. ``consolidation`` is reserved for Phases B and C and is not yet valid.
EVENT_KINDS = ("created", "dispatch", "handoff", "transition", "ownership_changed",
               "amendment_escalated")
RESERVED_EVENT_KINDS = ("consolidation",)

#: `actor` stays in the accepted set and is absent from the required one. Every event ever
#: written carries it, and an event is never edited — so tolerating it is not a courtesy, it
#: is the only reading that leaves existing corpora valid. It returns as a required field with
#: TFW-54, which is the task that will finally have a writer worth naming.
EVENT_KEYS = {
    "time", "kind", "writer", "actor", "on_behalf_of", "via", "from", "to", "refs", "summary",
}
EVENT_REQUIRED = ("time", "kind", "on_behalf_of", "refs")

#: `PROVIDER_FAMILIES` was deleted here at `2.0.0-dirty.3`. Its only reader was the gate that
#: refused a provider name in `actor`, and with `actor` no longer an identity the gate has no
#: subject. Keeping the set would leave a list nothing reads — and it was never named in any
#: payload prose, so a project met it only by being refused by it.

ISO_TIME = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:[+-]\d{2}:\d{2}|Z)$")
URI_SCHEME = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*:")


def team_profiles(root: Path) -> dict[str, dict]:
    """Every participant declared in ``team/``, **parsed**, keyed by handle.

    Reading the filename was not enough. Accountability is a claim about a *person*, so the
    rule needs the profile's declared ``type``, and only the file body carries it.

    An empty dict means the project declares nobody — which is a reason to refuse a new
    event, never a reason to skip the check.
    """
    directory = root / "team"
    if not directory.is_dir():
        return {}
    profiles: dict[str, dict] = {}
    for path in sorted(directory.glob("*.md")):
        if path.stem == "README":
            continue
        match = FRONT_MATTER.match(path.read_text(encoding="utf-8"))
        data = {}
        if match:
            try:
                loaded = yaml.safe_load(match.group(1))
                if isinstance(loaded, dict):
                    data = loaded
            except yaml.YAMLError:
                data = {"_error": "unparseable front matter"}
        handle = str(data.get("handle") or path.stem)
        profiles[handle] = data
    return profiles


def team_handles(root: Path) -> set[str]:
    """Declared handles only. Kept for callers that do not need the profile body."""
    return set(team_profiles(root))


def validate_profile(handle: str, profile: dict, profiles: dict[str, dict]) -> list[str]:
    """Validate the durable principal shape used by current optional ``writer`` fields."""
    problems: list[str] = []
    for key in ("handle", "name", "type", "since"):
        if profile.get(key) in (None, ""):
            problems.append(f"profile '{handle}' is missing {key}")
    if str(profile.get("handle", handle)) != handle:
        problems.append(f"profile '{handle}' declares handle {profile.get('handle')!r}")
    kind = profile.get("type")
    if kind not in {"human", "agent"}:
        problems.append(f"profile '{handle}' has unsupported type {kind!r}")
    if kind == "agent":
        accountable = profile.get("accountable_to")
        target = profiles.get(str(accountable)) if accountable else None
        if not accountable:
            problems.append(f"agent profile '{handle}' is missing accountable_to")
        elif target is None or target.get("type") != "human":
            problems.append(
                f"agent profile '{handle}' accountable_to does not name a human profile"
            )
        if not isinstance(profile.get("may_rule_amendments"), bool):
            problems.append(
                f"agent profile '{handle}' may_rule_amendments is not a YAML Boolean"
            )
    return problems


def read_stamp() -> str:
    """One reading of the system clock, at second resolution."""
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def event_token(entropy=os.urandom) -> str:
    """A short opaque token whose only job is that two names in one second differ.

    Four hex characters. Not an identity: it names nobody, needs no profile, is checked
    against nothing, and carries no meaning a reader could act on. If it ever acquires a
    second job, it is the wrong mechanism — that is the defect this replaced.

    ``entropy`` is injectable so a test can pin the value.
    """
    return entropy(2).hex()


def event_filename(kind: str, token=event_token, taken=(), clock=read_stamp,
                   attempts: int = 64) -> str:
    """The filename for one event: ``<stamp>__<kind>__<token>.md``.

    **The clock is read once, and no second is ever invented.** The previous version read the
    clock again on every collision and waited between readings, because the name's uniqueness
    came from the second and the only thing that could change a second was time passing. It
    is worth stating what that machinery was for, since it is now gone: uniqueness comes from
    the token, so a collision is re-drawn rather than waited out.

    The prohibition it was built to enforce survives intact and is stricter than before:
    nothing here adds to, rounds or composes a stamp. There is one reading, and it is used as
    it was read.

    ``attempts`` bounds the draw so exhausted entropy fails visibly instead of looping.
    """
    taken = set(taken)
    stamp = clock()
    drawn: list[str] = []
    for _ in range(attempts):
        value = token() if callable(token) else str(token)
        drawn.append(value)
        candidate = f"{stamp}__{kind}__{value}.md"
        if candidate not in taken:
            return candidate
    raise ValueError(
        f"drew {attempts} tokens at {stamp} and every name was taken "
        f"({drawn[0]} ... {drawn[-1]}). That is an entropy problem, not a naming problem — "
        "no second is invented and no counter is added to get past it")


def validate_event(data: dict, filename: str,
                   profiles: dict[str, dict] | None = None) -> list[str]:
    """Every rule an event declares, checked against one file. Problems, in order.

    ``profiles`` is ``team_profiles(root)`` — the parsed participants. **An empty dict is a
    refusal, not a skip**: if the project declares nobody, a new event has nobody who answers
    for it, and that is precisely the case the rule exists to catch. Passing ``None`` means
    the caller is checking something else and has opted out; every production path supplies
    the dict.
    """
    problems: list[str] = []

    name = EVENT_NAME.match(filename)
    legacy = name is None and LEGACY_EVENT_NAME.match(filename) is not None
    if not name and not legacy:
        problems.append(
            f"filename {filename!r} is not <YYYYMMDD-HHMMSS>__<kind>__<token>.md")

    unknown = sorted(set(data) - EVENT_KEYS)
    if unknown:
        problems.append("unknown keys: " + ", ".join(unknown))

    # A legacy event predates `on_behalf_of` and the three-part filename. Demanding either
    # would demand an edit, and an event is never edited.
    required = EVENT_REQUIRED if not legacy else tuple(
        k for k in EVENT_REQUIRED if k != "on_behalf_of")
    for key in required:
        if not data.get(key):
            problems.append(f"missing {key}")

    if "via" in data and (not isinstance(data["via"], str) or not data["via"].strip()):
        problems.append("via must be non-empty free-form provider/tool text when present")

    kind = data.get("kind")
    if kind in RESERVED_EVENT_KINDS:
        problems.append(f"kind '{kind}' is reserved for a later phase and is not yet valid")
    elif kind and kind not in EVENT_KINDS:
        problems.append(f"kind '{kind}' is outside the closed vocabulary")

    if name and kind and name.group("kind") != kind:
        problems.append(f"filename says kind '{name.group('kind')}', body says '{kind}'")
    # THE FILENAME IS NOT COMPARED TO `actor`, and there is nothing left to compare. The
    # third component is a uniqueness token, not an identity, so it agrees with no field by
    # design. The old check existed because the name carried a handle; the name no longer
    # carries one, so the check has no subject rather than a relaxed one.
    #
    # `actor` ITSELF IS NOT VALIDATED AT ALL: not against `team/`, not against a provider
    # list, not for shape. Every event in every existing corpus carries it, events are
    # immutable, and profiles are not — so any rule about it would either demand an edit or
    # go red when a project tidies `team/`. One consumer's gate is red today for exactly
    # that reason. Tolerated, never required, never rewritten.

    on_behalf_of = data.get("on_behalf_of")

    # The legacy escape is scoped to events identifiable as pre-rule by their own filename
    # shape — a durable property of the event itself, not a convenience for the caller.
    if profiles is not None and not legacy:
        declared = set(profiles)
        if on_behalf_of:
            profile = profiles.get(str(on_behalf_of))
            if profile is None:
                problems.append(
                    f"on_behalf_of '{on_behalf_of}' is not a declared team/ participant "
                    f"({', '.join(sorted(declared)) if declared else 'team/ declares nobody'})")
            elif str(profile.get("type", "")).strip() != "human":
                problems.append(
                    f"on_behalf_of '{on_behalf_of}' is declared as "
                    f"'{profile.get('type') or 'no type'}', not human — accountability "
                    "always resolves to a person")

        writer = data.get("writer")
        if writer:
            profile = profiles.get(str(writer))
            if profile is None:
                problems.append(
                    f"writer '{writer}' is not a declared team/ principal "
                    f"({', '.join(sorted(declared)) if declared else 'team/ declares nobody'})"
                )
            else:
                problems.extend(validate_profile(str(writer), profile, profiles))

    time_value = data.get("time")
    if time_value is not None:
        text = time_value.isoformat() if hasattr(time_value, "isoformat") else str(time_value)
        if not ISO_TIME.match(text):
            problems.append(f"time is not ISO 8601 with an offset: {text!r}")

    refs = data.get("refs")
    if refs is not None and (not isinstance(refs, list) or not refs):
        problems.append("refs must be a non-empty list of paths")

    has_from, has_to = data.get("from") is not None, data.get("to") is not None
    if has_from != has_to:
        problems.append("a state change needs both 'from' and 'to', or neither")

    return problems


def validate_new_event(data: dict, filename: str,
                       profiles: dict[str, dict] | None = None,
                       declared: list[str] | None = None) -> list[str]:
    """Pre-write gate for a current immutable event.

    ``validate_event`` deliberately tolerates historical forms. A writer calls this stricter gate
    before installing new bytes, so a later compatibility rule never makes old events editable.
    """
    problems = validate_event(data, filename, profiles)
    declared_set = set(declared or DECLARED_LIFECYCLES)
    name = EVENT_NAME.match(filename)
    if name and not re.fullmatch(r"[0-9a-f]{4}", name.group("token")):
        problems.append("new event token must be exactly four lowercase hex characters")

    time_value = data.get("time")
    if name and time_value is not None:
        text = time_value.isoformat() if hasattr(time_value, "isoformat") else str(time_value)
        if ISO_TIME.match(text):
            components_valid = True
            offset_match = re.search(r"[+-](?P<hours>\d{2}):(?P<minutes>\d{2})$", text)
            if offset_match:
                hours = int(offset_match.group("hours"))
                minutes = int(offset_match.group("minutes"))
                if minutes >= 60:
                    problems.append("time offset minutes must be between 00 and 59")
                    components_valid = False
                if hours > 14 or (hours == 14 and minutes != 0):
                    problems.append("time offset must be within -14:00 and +14:00")
                    components_valid = False
            if components_valid:
                try:
                    parsed_time = datetime.fromisoformat(text.replace("Z", "+00:00"))
                except ValueError:
                    problems.append("time must be a real calendar timestamp with a valid offset")
                else:
                    offset = parsed_time.utcoffset()
                    if offset is None or abs(offset) > timedelta(hours=14):
                        problems.append("time offset must be within -14:00 and +14:00")
                observed_stamp = re.sub(r"[-:]", "", text[:19]).replace("T", "-")
                if observed_stamp != name.group("stamp"):
                    problems.append("filename stamp and event time must name the same observed second")

    if "summary" in data:
        summary = data["summary"]
        if not isinstance(summary, str):
            problems.append("summary must be a string when present")
        elif "\n" in summary or "\r" in summary:
            problems.append("summary must be one line")

    refs = data.get("refs")
    if isinstance(refs, list):
        if any(not isinstance(ref, str) or not ref.strip() for ref in refs):
            problems.append("refs must contain non-empty relative paths")
        for ref in (item for item in refs if isinstance(item, str) and item.strip()):
            normalized = ref.strip().replace("\\", "/")
            if normalized.startswith("/") or re.match(r"^[A-Za-z]:", normalized):
                problems.append(f"ref must be relative to the task directory: {ref!r}")
                continue
            if URI_SCHEME.match(normalized):
                problems.append(
                    f"ref must be a task-relative filesystem path, not a URI: {ref!r}")
                continue
            depth = 0
            for component in normalized.split("/"):
                if component in ("", "."):
                    continue
                if component == "..":
                    depth -= 1
                    if depth < 0:
                        problems.append(f"ref escapes the task directory: {ref!r}")
                        break
                else:
                    depth += 1

    kind = data.get("kind")
    source, target = data.get("from"), data.get("to")
    if kind == "transition":
        if source is None or target is None:
            problems.append("a new transition event requires both 'from' and 'to'")
        elif source != UNDECLARED and source not in declared_set:
            problems.append(f"transition source '{source}' is not declared")
        elif target not in declared_set:
            problems.append(f"transition target '{target}' is not declared")
        elif source in TERMINAL:
            problems.append(f"terminal lifecycle '{source}' has no outgoing transition")
        elif target == "REJECTED":
            pass
        elif target == "BLOCKED" or source == "BLOCKED":
            if target in TERMINAL or source == target:
                problems.append(f"illegal transition pair: {source} -> {target}")
        elif source == UNDECLARED:
            if target in TERMINAL:
                problems.append(f"illegal transition pair: {source} -> {target}")
        elif (source, target) not in FORWARD_TRANSITIONS:
            problems.append(f"illegal transition pair: {source} -> {target}")
    elif source is not None or target is not None:
        problems.append("only a transition event may carry 'from' and 'to'")
    return problems


def journal_dirs(task_dir: Path) -> list[Path]:
    """Every journal a task holds: its own, and one per phase directory.

    A phase carries its own `journal/` exactly as it carries its own `status.md` — the
    symmetry an external project assumed, correctly, before it was implemented. Two of that
    project's four malformed events sat in `phase-a/journal/` where nothing looked, so the
    gate reported clean over them.
    """
    found = [task_dir / "journal"]
    found += [phase / "journal" for phase in iter_phase_dirs(task_dir)]
    return [d for d in found if d.is_dir()]


def read_journal(task_dir: Path, profiles: dict[str, dict] | None = None
                 ) -> tuple[list[dict], list[str]]:
    """Every event in a task's journals, and every problem found. Nothing is dropped.

    **Every journal**, task-level and per-phase. Reading only the task's own was how a
    consumer's malformed phase events stayed invisible to a gate that reported success.

    Events written before the 2.0.0 grammar are counted and reported once, not corrected:
    the journal is immutable, so a rule introduced later can describe old entries but never
    rewrite them.
    """
    journals = journal_dirs(task_dir)
    if not journals:
        return [], []
    events, problems = [], []
    legacy = 0
    for journal in journals:
        # A phase event is reported by `phase-a/journal/<name>.md`, not by `<name>.md` alone:
        # two phases can hold the same event name, and a bare name would make one report
        # answer for a file the reader cannot find.
        prefix = "" if journal.parent == task_dir else f"{journal.parent.name}/journal/"
        for path in sorted(journal.glob("*.md"), key=lambda p: p.name):
            label = prefix + path.name
            text = path.read_text(encoding="utf-8")
            match = re.match(r"^---\r?\n(.*?)\r?\n---\r?\n", text, re.S)
            if not match:
                problems.append(f"{label}: no YAML front matter")
                continue
            try:
                data = yaml.safe_load(match.group(1))
            except yaml.YAMLError as exc:
                problems.append(f"{label}: unparseable ({exc.__class__.__name__})")
                continue
            if not isinstance(data, dict):
                problems.append(f"{label}: front matter is not a mapping")
                continue
            if EVENT_NAME.match(path.name) is None and LEGACY_EVENT_NAME.match(path.name):
                legacy += 1
            for problem in validate_event(data, path.name, profiles):
                problems.append(f"{label}: {problem}")
            data["_file"] = label
            events.append(data)
    if legacy:
        problems.insert(0, f"{legacy} event(s) predate the 2.0.0 event grammar; immutable "
                            "by rule, so they are recorded as legacy rather than corrected")
    return events, problems


def read_project_config_block(root: Path, block: str) -> dict:
    """Semantically read one top-level project configuration mapping."""
    path = root / ROOT_MARKER / "project_config.yaml"
    if not path.exists():
        return {}
    with open(path, encoding="utf-8") as handle:
        document = yaml.safe_load(handle) or {}
    value = document.get(block) or {}
    if not isinstance(value, dict):
        raise ValueError(f"project_config.yaml `{block}` is not a mapping")
    return value
